# v1.3 Canonical Data, Provider and Automation Contract

## Source-isolation rules (hard constraints)

Each job holds `origin` (`provider` or `direct_employer`), `provider`, `provider_job_id` OR `owner_org_id`+`external_id`, immutable original source URL, canonical application URL, independent provider policy ID, content-use rights, source attribution, imported/updated/first_seen/verified times, eligibility evidence and status. Never merge two sources into one attribution record. Cross-provider duplicates may display one group with both retained URLs/rights. No partner API, CSV export or public developer endpoint may return third-party imported job records unless explicit source licence permits; default deny.

## Canonical JobView — exact field types

`id: opaque string`, `origin: enum(provider,direct_employer)`, `source_name: nonempty string`, `source_url: HTTPS`, `apply_url: HTTPS`, `title: string`, `company_name: string|null`, `work_mode: remote|hybrid|onsite|unknown`, `work_country: ISO2|null`, `employer_country: ISO2|null`, `eligible_from_in: allowed|not_allowed|unknown`, `eligibility_evidence: [{provider_field, fact, observed_at}]`, `time_zone_eligibility: allowed|not_allowed|unknown`, `visa_sponsorship: yes|no|unknown`, `salary_min/max: decimal|null`, `salary_currency: ISO3|null`, `salary_period: hour|day|week|fortnight|month|year|null`, `source_published_at: UTC|null`, `source_updated_at: UTC|null`, `first_seen_at: UTC`, `last_seen_at: UTC`, `last_verified_at: UTC|null`, `valid_through: UTC|null`, `availability: active|closed|stale|unknown`, `display_status: visible|hidden|held`, `rights: {attribution_required,allow_jobposting_schema,allow_resyndication}`, `reason_tags: string[]`. Source-specific fields/metadata stored separately, never invented.

**Timestamp invariants:** UTC ISO 8601 on API/JSON; SQL UTC `DATETIME` with known conversion; explicit `unknown` is not Unix epoch. `source_published_at` never silently set to first seen, source updated, or ingestion time. `new_since_last_visit` uses local first seen relative to browser last-view, not source posting date.

**Origin/status mapping:** Provider imported record = API provider ID + provider lifecycle state; direct employer record = verified org ID + posting review state. A public projection has `visible` only if rights permit, no trust hold, and either active provider evidence or approved nonexpired direct posting. For provider, 410 (Himalayas) means closed; 404 means unknown/pending investigation (not automatically closed); 429/5xx retain cache while respecting freshness. For direct employer, `pending_review`, `rejected`, `suspended`, `closed`, `expired` are hidden regardless of previously published status. All status transitions audited.

## Source-specific adapter mapping

### Himalayas JSON API

Official docs: https://himalayas.app/docs/remote-jobs-api and https://himalayas.app/api (reviewed 2026-11-22; reread live before deployment).

- As documented in the current primary public browse API reference, request `/jobs/api?limit=20&offset=N`; stop when the returned `offset`/`totalCount` and page length prove exhaustion. The search endpoint instead uses page numbers. If a real response documents `nextCursor`, support it as a versioned alternative only after checking actual response structure. Do **not** assume `nextCursor` exists, silently restart page 1, or declare the feed complete when a configured maximum-page sample cap is reached. A partial sample never implies omitted jobs are closed. See https://himalayas.app/docs/remote-jobs-api (rechecked 2026-11-22).
- `guid` → `provider_job_id`; `applicationLink` → exact required apply destination; credit Himalayas; data cannot be redistributed to a third-party job board or included in Google JobPosting markup under source restrictions.
- The provider documentation contains **multiple illustrative country representations**: `locationRestrictions` may contain ISO alpha-2 `string[]` (e.g. `["IN", "US"]`), spelled-out country names (e.g. `["India", "United States"]`), or older illustrated objects with `alpha2` / `name`. The adapter must canonicalise **every supplied entry** using a pinned ISO 3166-1 country dictionary and explicit, tested aliases. If an entry is unknown, or one object has conflicting code/name, the geographic dimension is `unknown`, **not** assumed to exclude India. Empty country array = unrestricted geography; a missing field remains unknown. `timezoneRestrictions` may be numeric UTC-hour offsets `number[]` (e.g. `[5.5]`) or documented UTC-offset strings; all values must parse safely. Empty timezone array = unrestricted offset; missing field stays unknown. Only when **both** geographic and timezone dimensions allow India may `eligible_from_in=allowed`; a known explicit exclusion may return `not_allowed`. Neither condition proves immigration authorisation or employer authenticity. Preserve raw source restriction evidence for transparent Job Decision Cards.
- Per both current official public API references, the job-level `pubDate` is **described as publication date in current summary docs**, but illustrative schema examples and historical references are not fully consistent on its type/semantics; therefore treat this as source-reported, not independently verified original creation date: map valid `pubDate` to `source_published_at`; leave `source_updated_at=null` unless an independently documented job update timestamp exists. The response-level `updatedAt` describes feed-cache refresh and must not be copied to every job as its update or original publish time. `expiryDate` is listing expiry; it may close earlier. Where real upstream semantics diverge from docs, label dates unknown and log a provider-contract conflict instead of inventing a timeline.
- Rate limits and attribution are current-source-dependent; observe `429 Retry-After`, exponential backoff, no hidden/browser-only direct calls.

### Jobicy public feed

Official docs: https://jobicy.com/jobs-rss-feed (reviewed 2026-11-22; verify relevant commercial and attribution terms on activation).

- Free feed is a bounded recent window (official docs report last 7 days), **not** an authoritative all-active-job index. Disappearance from feed alone ≠ closure. Preserve canonical Jobicy/source URL and required credit; do not redirect to arbitrary employer ATS links not licensed by provider.
- Map genuine source publish/updated time when explicitly documented; otherwise keep unknown. `jobGeo="Anywhere"` is described by Jobicy as **no region specified**, not proof of global hiring or timezone acceptance: show `unknown` for confirmed India eligibility unless stronger employer/source evidence exists. A location restriction explicitly excluding India returns `not_allowed`. Source status check only if an authorised endpoint is available; never aggressive scrape third-party destination to prove closure.
- Do not invent affiliate click earnings for these jobs. A separate approved tracked employer-purchase referral program, if any, has independent conditions.

## Safe ingestion transaction

1. Cron lock ensures one provider job at a time; begin `sync_run`. Fetch using server-side requests and active provider policy version; enforce timeout/size/SSL; no source callback injection or arbitrary URL.
2. Validate raw response shape against versioned fixture. Normalise without inventing fields. Scrub HTML. Restrict outbound URLs to provider-specified links. Record source snapshot metadata and source policy ID.
3. Upsert idempotently on `(provider_id,provider_job_id)` only; duplicate grouped at display, not destructive data merger. Mark seen IDs within completed traversal.
4. Only after complete successful traversal evaluate possible missing jobs; absence from Jobicy time-bounded feed is never an automatic close. Authoritative expiry or provider-specific status closes; otherwise mark freshness uncertain and hide when stale threshold reached.
5. Commit transaction and sync_run health. 429/5xx/partial traversal → no deletion and no reset of last-known-good; log error and retry with bounded exponential backoff. Provider policy uncertainty → disable further public use safely.

## Freshness thresholds (project defaults; not upstream guarantees)

- Visible imported job requires successful provider status confirmation where available or a completed recent feed reference under per-source policy. In unverified state use warning rather than claiming “active”. If older than **72h since last successful source verification**, hide by default unless provider-specific documented evidence supports longer; configurable per provider and monitor false removals. Closed/expired authoritative record is hidden immediately. **TTL is an internal conservative safety setting, not proof of vacancy status.**
- Direct employer jobs expire at `valid_through`; notify org beforehand only if approved email delivery exists; no silent extension. Sponsor/eligibility changes must trigger review and revision increment.
- `source_terms_checked_at` more than 30 days old or provider terms materially changed → warn operator, disable affected integration if rights are uncertain. Manual-assisted legal review is honestly not automatic.

## Local browser profile & Radar (no backend-user illusion)

`profile_schema_version=1`, roles[], work_path enum, countries[], last_view_at, seen map, saved jobs, applications, followups, consent settings. Store locally only and validate imported JSON schema with caps (max 2000 saved jobs / 1000 applications and 1 MiB import by default). Use origin-qualified stable job key `provider:<slug>:<id>` or `direct:<org>:<external_id>`; never trust unsanitised imported HTML. Deterministic matching: required path/country gate → role token overlap with simple alias dictionary → date/seen state. No score percentage unless based on explicit defined formula and labelled heuristic. Show exact matched reason and unknown data warnings. Calendar reminder `.ics` only; offline email/push disabled at launch.

## Security operations

Data origin endpoints and webhook URLs never act as general SSRF fetchers. Reject localhost/private IPv4/IPv6, link-local, redirect to another hostname, punycode lookalikes and non-HTTPS schemes in employer apply URL review; do not assume DNS/domain verification alone proves employment or authority. All employer writes require session CSRF or scoped bearer token + per-object tenant checks, rate limits and audit. Store hashed tokens; never output a secret in logs/source/client.

## Bounded maintenance & auto-recovery

- Health cron once daily summarises last successful sync per provider, jobs visible/held, invalid links, failed backups, recent incident reports, API tokens abuse metrics (when active) and broken routes. Self-heal allowed for transient errors; substantive licence questions, company identity and suspected fraud are exceptions requiring trusted human judgement.
- Backups per available hosting, periodic restore drill, two retained restore points, failed-restore alert and reversible migration approach. Backups encrypted/access controlled and excluded from public web root.
- Admin emergency switches: `PROVIDER_JOBICY_ENABLED`, `PROVIDER_HIMALAYAS_ENABLED`, `RECRUITER_LITE_ENABLED`, `PARTNER_POSTING_API_ENABLED`, `ADS_ENABLED`. When off, site renders honest unavailable state, not fake success.
- No monitoring infrastructure should generate unbounded costs, emails or API calls. If email service unavailable use owner/admin dashboard; document that notifications won't be delivered.

## SEO, source rights and privacy

Imported provider-only thin job pages are `noindex` by default; provider-specific licence always wins over SEO wishes. Employer-owned original jobs may use JobPosting schema only when source/Google requirements pass, not for affiliate disguised jobs. Remove expired/closed jobs from job index and schema. Original guidance must have sources and last review timestamps; no mass AI-generated article spam. Ads only after actual account approval. Tracking consent must be applicable to region and vendor; analytics events never include applicant PII.


## Canonical DB reference

`24_DATABASE_SCHEMA_REFERENCE.sql` supplies the unified proposed schema and owner/provider invariants. The old illustrative SQL in `06_ARCHITECTURE_AND_DATABASE.md` is explicitly deprecated. Run schema against the actual available MySQL/MariaDB version in a scratch database, add migrations/rollbacks, and audit SQL constraints/application constraints before creating production tables. Candidate records remain browser-local.

**Country validation:** regex `^[A-Z]{2}$` alone does not make a valid country; validate ISO 3166-1 alpha-2 membership server-side (reject fabricated `ZZ`) on POST, PATCH full-object, source adapters and public filters. `candidate_eligible_countries` must be validated the same way.

## v1.3.3 supporting module/operations contract clarification

- M06: Five substantial original guides must exist as content assets, carry dated source references and a visible `draft_requires_editorial_review|reviewed` state. Do not represent a drafted guide as legally or editorially reviewed; unreviewed content is `noindex` and cannot satisfy the public release gate.
- M07/T06: Application tracker records remain browser-local. Explicit user actions create/update `saved|applied|interview|offer|rejected|closed` states; Apply clicks NEVER infer submission. Versioned JSON and CSV import/export must reject unexpected fields/statuses and spreadsheet formula injection; downloadable `.ics` is not a background notification.
- M10: A user job report enters a private bounded review queue. Actual quarantine requires an authenticated/trusted owner operation; quarantine is maintained separately from provider cache and **cannot be undone by another feed import**. Decisions and explicit reinstatements require audit history. A prototype CLI queue is not a substitute for a production moderator/admin interface, user privacy controls or rate limiting.
- M00/M16: `RELEASE_READY=1` alone MUST NOT make a build indexable. Require actual live hosting/SSL/cron, permission/job-inventory evidence, approved legal/privacy, five reviewed original guides, backup-restore and staging security/accessibility test evidence. No synthetic proof or test-fixture job may satisfy release criteria.

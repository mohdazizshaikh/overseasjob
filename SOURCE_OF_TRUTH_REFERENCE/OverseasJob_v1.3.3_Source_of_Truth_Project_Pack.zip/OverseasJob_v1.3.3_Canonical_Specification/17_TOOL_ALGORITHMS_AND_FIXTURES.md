# v1.3 Deterministic Contracts: All 10 Free Career Tools

Each tool must include: precise fields, units, validation, missing-data policy, sample input/output test, keyboard/mobile layout, local-data warning, reset and usable export/print. `null` means not known; 0 means actually zero. Display money rounded only at UI boundary (calculations use decimal minor units or fixed precision), currency codes not interchangeable; live data is never invented.

## T01 Salary, Living Cost & Savings

Inputs: `salary_value >= 0`, `salary_basis` (`gross|net`), `salary_period` (`monthly|annual`), `deductions_fixed >=0`, `deductions_rate` 0..100 (gross only), each monthly expense >=0, `fx_rate>0` optional with direction clearly labelled, `one_time_costs>=0` separate. Normalise salary to monthly (`annual /12`). If gross: `estimated_take_home = max(0, monthly_gross - deductions_fixed - (monthly_gross * deductions_rate/100))`; if net: `estimated_take_home=monthly_net` and deductions controls disabled (not subtracted). `monthly_expenses=sum(all monthly expenses)`; `monthly_savings = take_home - expenses`; `savings_rate = savings/take_home*100` if take_home>0 else `not_applicable`; `annual_savings=monthly_savings*12` WITHOUT one-time expenses; `first_year_after_move=annual_savings-one_time_costs`. FX converts presentation currency only if user provides explicit one-unit direction; if missing show original currency without misleading INR total. Allow negative savings, reject NaN/Infinity, high rates and negative fields. Golden A: gross 120000/month, 10% deduction, rent 30000+food 15000+transport 5000 => take-home 108000, costs 50000, savings 58000, 48.33%? exact **53.7037%**, annual 696000. Golden B: net 50000, expenses 60000 => savings -10000; negative not an error. Gross example after rate: 120000-12000=108000; 58000/108000=53.7037037.

## T02 Offer Comparison

Per offer inputs: base salary amount, `period=hour|month|year` (for hourly require hours/week and weeks/year), currency, `estimated_deductions`, recurring monthly costs, guaranteed monetary benefits, conditional bonuses, one-time move/visa costs, hours/week, user FX to common display currency. Formula: monthly recurring base: year/12, month as-is, hour*hours_per_week*weeks_per_year/12. Guaranteed recurring compensation added to recurring base only if clearly cash-equivalent; noncash benefits separate. `net_monthly_estimate=gross_monthly+guaranteed_cash_monthly-user_estimated_deductions`; `monthly_savings=net_monthly_estimate-monthly_expenses`; `first_year_savings=monthly_savings*12 - one_time_costs`; optional conditional bonus is not included in guaranteed savings. No tax calculation without user input; FX incomplete = cannot rank monetary offers, show “comparison incomplete”. Higher monetary first-year savings can be displayed as a scenario, not objectively “better” job. Fixture: A monthly net 100000, costs 60000, move 100000 → first-year 380000; B monthly net 80000, costs 30000, move 0 → 600000. B higher first-year by 220000 (same currency only).

## T03 Resume & Cover Letter

Three original content templates with real headings: reverse-chronological, skills-based, concise fresher. All have contact, summary, experience/projects, education, skills and optional evidence links; no auto invented experience. Cover-letter structure: recipient if known, role, two evidence-backed achievement paragraphs, conclusion. Escape all user input; never store server-side by default; export HTML/text and browser print stylesheet for A4/Letter without clipped tables; proof using screenshots/print tests. Fixture: field contains `<script>alert(1)</script>` → printable output displays text, executes zero JS; empty required name triggers validation, never fabricated placeholder.

## T04 Relocation Budget

Explicit one-time categories: travel, documents, visa user-estimate, deposits, setup, arrival transport; recurring monthly categories: rent/food/utilities/transport/insurance; `reserve_months>=0` and `contingency_pct` 0..100. `one_time_total=sum(one_time items)`; `monthly_cost=sum(recurring)`; `reserve=reserve_months*monthly_cost`; `contingency=contingency_pct/100*(one_time_total+reserve)`; `target_cash=one_time_total+reserve+contingency`; display all three separately to avoid double-count. Fixture: one-time 60000, monthly 40000, reserve 3 months, contingency 10% => 60000+120000+18000=198000.

## T05 Time Zone Work Overlap

Input: valid IANA zones (e.g. `Asia/Kolkata`, `Europe/London`), selected calendar date, weekday work intervals in local wall time, optional overnight shift flag, min meeting length (minutes). Use `Intl.DateTimeFormat` with zone, **actual date** and DST; don't hardcode offsets. Compute candidates on UTC timeline in 15-minute steps (or finer for requested precision) and convert each UTC instant to respective wall time + day; compare allowed intervals, handling half-open boundaries; merge adjacent valid points into UTC spans. Display both local times with date and offset, and don't suggest nonexistent DST-gap local times. Fixture: 2026-01-15 UTC 09:00 = London 09:00 and Kolkata 14:30; 2026-07-15 UTC 09:00 = London 10:00 and Kolkata 14:30. Overnight/weekend/DST fold cases required. If device lacks sufficient timezone support show clear unsupported message.

## T06 Application Tracker

Status enum `saved|applied|interview|offer|rejected|closed`; no automatic 'applied' on outbound link click. Each entry contains id, URL (HTTPS if present), company, role, user-chosen applied_at/status, followup_date, notes optional, created_at, updated_at. LocalStorage/IndexedDB with schema version; export UTF-8 JSON and CSV; import validates field allowlist, sizes, date format, statuses and sanitises output (CSV formula injection guard). Duplicate IDs merged only after explicit user choice or stable deterministic new IDs. One-click delete all. `.ics` follow-up optional and exported file is NOT a backend reminder. Fixture: export→erase→import yields same 2 example records and no automatic cloud sync; malicious `javascript:` links rejected.

## T07 Interview Practice

Static original question bank keyed by role and question ID, not live LLM. Each record has prompt, role, objective, rubric, sample structure, source/author. Timer local only, keyboard operable, text mode works without microphone; speech recognition optional browser capability with explicit consent and graceful fallback. No “employer certified” badge or hiring likelihood predictions. Fixture: denying mic results in a working text question and timer with zero paid API calls.

## T08 Country Readiness Checklist

Country + intended visa/work-path categories are selected but no visa eligibility decision. Checklist item holds `title`, `category`, `is_generic`, `source_url`, `reviewed_at`, `expiry_review_at`. When rule-specific item has no current official source or is past review date, label “needs rechecking” rather than publish as current legal requirement; user progress saved local. Fixture: hypothetical requirement expired yesterday → warning, no “verified” claim; clearing storage loses ticks with warning.

## T09 WorkProof Portfolio Generator

Input self-reported project title, description, skills, project links, optional evidence. Output static HTML with escaped text and safe `https` external links, print/PDF and local preview. No online hosting, public profile or verification claim. Limit images or exclude uploads at launch; support up to 10 projects. Fixture: malicious HTML in project description renders inert; user sees “Self-reported” rather than “Verified”.

## T10 Career Roadmap Builder

Start with 3 curated role tracks (IT Support, Customer Support, Junior Web Developer), each with skills prerequisites, role-linked free learning resources, 30/60/90-day practice plan and at least one verifiable deliverable. Adapt weekly time-budget with deterministic distribution without guaranteeing employment; optional user edits and local export. Fixture: 3 hours/week yields 12 hours per 4-week planning block; milestone text is nonempty and does not claim certification. Every external link reviewed and dated.

## Content/readiness evidence gate

A module's algorithm can be specified while its **original templates, questions, sourced country guides or test snapshots still have to be created**. A coding agent should author/review those files and run validation before switching the route to LIVE; no placeholder content or fabricated official sources. Public content refresh remains an ongoing editorial task, not automatically guaranteed by AI.

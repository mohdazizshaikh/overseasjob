#!/usr/bin/env python3
"""Portable contract and documentation smoke checks; does not test deployed product."""
from pathlib import Path
import json, re, sys
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
try:
    import yaml
    from jsonschema import Draft202012Validator, FormatChecker
except ImportError as exc:
    print('Missing free developer test dependency:', exc, '\nInstall in development environment: pip install pyyaml jsonschema')
    sys.exit(2)

ROOT=Path(__file__).resolve().parent
spec=yaml.safe_load((ROOT/'08_PARTNER_JOB_POSTING_API_OPENAPI.yaml').read_text())
checks=[]
def check(name,condition):
    checks.append((name,bool(condition)))
    print(('PASS' if condition else 'FAIL')+'  '+name)

def validator(name):
    return Draft202012Validator({'$ref':f'#/components/schemas/{name}','components':spec['components']},format_checker=FormatChecker())

create=validator('JobCreate'); patch=validator('JobPatch')
fixtures=json.loads((ROOT/'18_TEST_FIXTURES.json').read_text())
check('saved API fixture valid remote',create.is_valid(fixtures['api']['create_valid_remote']))
check('saved API fixture valid onsite',create.is_valid(fixtures['api']['create_valid_onsite']))
sample={
 'external_id':'test-0001','title':'Technical Support Engineer',
 'description':'Provide customer technical support and resolve incidents using documented escalation procedures.',
 'employment_type':'full_time','work_mode':'remote','work_country':None,
 'location_text':'India remote','candidate_eligible_countries':['IN'],
 'apply_url':'https://careers.example.org/jobs/1','valid_through':'2026-12-31T23:59:59Z',
 'consent_to_publish':True,'visa_sponsorship':'unknown','relocation_support':'unknown'
}
for v in ['yes','no','unknown']:
    a=sample|{'visa_sponsorship':v,'relocation_support':v}
    check(f'create sponsorship+relocation enums {v}',create.is_valid(a))
    check(f'patch sponsorship enum {v}',patch.is_valid({'visa_sponsorship':v}))
check('reject boolean sponsorship',not create.is_valid(sample|{'visa_sponsorship':True}))
check('reject onscreen null work country',not create.is_valid(sample|{'work_mode':'onsite','work_country':None}))
check('reject hybrid null work country',not create.is_valid(sample|{'work_mode':'hybrid','work_country':None}))
check('accept onsite ISO country',create.is_valid(sample|{'work_mode':'onsite','work_country':'AE'}))
check('reject short/invalid country',not create.is_valid(sample|{'work_mode':'onsite','work_country':'ZZZ'}))
check('reject unknown example property',not create.is_valid(sample|{'country':'IN'}))
check('accept temporary employment PATCH',patch.is_valid({'employment_type':'temporary'}))
check('accept sample curl fixture',create.is_valid(sample))
# ensure doc curl uses actual fields
recruiter=(ROOT/'07_RECRUITER_LITE_AND_PARTNER_API.md').read_text()
check('curl field names current', '"work_country":null' in recruiter and '"candidate_eligible_countries"' in recruiter and '"remote_eligible_countries"' not in recruiter)
# job source rules fixed and included
source=(ROOT/'16_DATA_AND_OPERATIONS_CONTRACT.md').read_text()
for phrase in ['locationRestrictions','timezoneRestrictions','source_updated_at','Jobicy','source_published_at','first_seen_at','not automatically closed']:
    check('source invariant '+phrase, phrase in source)
# module inventory
modules=(ROOT/'15_CANONICAL_MODULE_REQUIREMENTS.md').read_text()
for i in range(18):
    check(f'module register M{i:02d}',bool(re.search(rf'\| M{i:02d} \|',modules)))
tool=(ROOT/'17_TOOL_ALGORITHMS_AND_FIXTURES.md').read_text()
for i in range(1,11):
    check(f'tool contract T{i:02d}',bool(re.search(rf'^## T{i:02d} ',tool,re.M)))
# deterministic numeric fixture tests (formulas in tool spec)
gross=120000;take=gross-(gross*.10);exp=30000+15000+5000;savings=take-exp
check('T01 take home',take==108000)
check('T01 monthly savings',savings==58000)
check('T01 savings percentage',round(savings/take*100,4)==53.7037)
check('T02 first year A',(100000-60000)*12-100000==380000)
check('T02 first year B',(80000-30000)*12==600000)
check('T04 relocation total',60000+3*40000+0.1*(60000+3*40000)==198000)
from datetime import datetime as dt
winter=dt(2026,1,15,9,0,tzinfo=timezone.utc); summer=dt(2026,7,15,9,0,tzinfo=timezone.utc)
check('T05 London winter DST',winter.astimezone(ZoneInfo('Europe/London')).hour==9)
check('T05 London summer DST',summer.astimezone(ZoneInfo('Europe/London')).hour==10)
check('T05 Kolkata half-hour offset',all(t.astimezone(ZoneInfo('Asia/Kolkata')).strftime('%H:%M')=='14:30' for t in (winter,summer)))
# docs naming/authority
readme=(ROOT/'00_READ_ME_FIRST.md').read_text()
check('readme current version',readme.startswith('# OverseasJob.in — Canonical AI-agent Project Pack v1.3'))
check('readme no old mandatory Phase 0 only', 'Authorise **Phase 0 only**' not in readme)
check('full access documented', 'full technical access' in (ROOT/'19_AGENT_AUTONOMY_AND_DELIVERY.md').read_text())
# ensure all root-specific files present, no absence in manifest
required=['00_READ_ME_FIRST.md','01_COMPLETE_PROJECT_BLUEPRINT.md','02_AI_AGENT_MASTER_PROMPT.md','03_MILESTONE_TASKS.md','04_QA_AND_LAUNCH_CHECKLIST.md','05_SOURCE_POLICY_MATRIX.csv','06_ARCHITECTURE_AND_DATABASE.md','07_RECRUITER_LITE_AND_PARTNER_API.md','08_PARTNER_JOB_POSTING_API_OPENAPI.yaml','10_DECISION_COMPANION_PRODUCT_SPEC.md','15_CANONICAL_MODULE_REQUIREMENTS.md','16_DATA_AND_OPERATIONS_CONTRACT.md','17_TOOL_ALGORITHMS_AND_FIXTURES.md','19_AGENT_AUTONOMY_AND_DELIVERY.md','20_VERIFICATION_LEDGER.md']
check('expected canonical files',all((ROOT/name).exists() for name in required))
# v1.3.2 primary-source contract regressions (documentation, not live API tests)
contract = (ROOT / '16_DATA_AND_OPERATIONS_CONTRACT.md').read_text(encoding='utf-8')
check('Himalayas documented offset pagination', '`offset`' in contract and '`totalCount`' in contract)
check('Himalayas string country and numeric timezone arrays', '`string[]`' in contract and '`number[]`' in contract)
check('Himalayas documented publication and feed updatedAt distinction', '`source_published_at`' in contract and '`updatedAt`' in contract)
check('Himalayas country-name and legacy-object contract', 'spelled-out country names' in contract and 'canonicalise' in contract and '`unknown`' in contract)
check('Full release gate requires evidence and original reviewed guides', '`RELEASE_READY=1` alone' in contract and 'five reviewed' in contract.lower())
check('Jobicy Anywhere not confirmed worldwide', '`jobGeo="Anywhere"`' in contract and 'not proof' in contract)

errors=[n for n,ok in checks if not ok]
print(f'\n{len(checks)-len(errors)}/{len(checks)} checks passed; {len(errors)} failures.')
if errors:sys.exit(1)


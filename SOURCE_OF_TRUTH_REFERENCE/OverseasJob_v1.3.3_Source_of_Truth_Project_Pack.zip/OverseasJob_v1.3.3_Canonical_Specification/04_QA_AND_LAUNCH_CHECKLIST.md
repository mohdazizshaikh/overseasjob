# OverseasJob.in — Quality Assurance & Launch Gate

**Do not approve launch when any critical item is unchecked.**

## Legal/source compliance

- [ ] All job providers have up-to-date terms and dated owner review.
- [ ] Jobicy attribution + canonical source URL are visible and preserved.
- [ ] Himalayas applies via `applicationLink`, not invented/ATS bypass URLs.
- [ ] Himalayas records are never redistributed or marked up with `JobPosting` schema.
- [ ] Partner pages are noindexed where thin and source terms require; no copied content monetisation assumption.
- [ ] No unauthorised LinkedIn/Indeed/Naukri/Apna scraping.
- [ ] No listing falsely labelled India-eligible, sponsored, verified or active.
- [ ] Overseas recruitment regulated activities are not implemented.

## Security/privacy

- [ ] Every provider HTML description sanitized with allowlist.
- [ ] External URLs validated against allowed scheme and source destination.
- [ ] All DB queries prepared/parameterised; no XSS/SQL injection.
- [ ] HTTPS + security headers; admin restricted, keys are server-only.
- [ ] No passport, CV, contact list or payment data collected in MVP.
- [ ] Local tracker export/delete works; browser-clearing warning shown.
- [ ] Privacy/Cookie/Terms/Contact/Safety/report flow is live.
- [ ] Database backup + test restore; rollback instructions exist.

## Decision Companion and Radar (v1.2 core)

- [ ] Real 14-day permitted source sampling report produced for 2–3 roles; India-eligible/ineligible/unknown results separated, not imagined.
- [ ] No-login onboarding: role and remote-vs-relocation path clearly selected and results reached quickly on mobile.
- [ ] A US-only remote role never displays as India-eligible; eligibility unknown never becomes worldwide.
- [ ] Decision Card cites grounded location eligibility, source, independent date fields, salary basis, reasons and permitted Apply target.
- [ ] On-site UAE role does not imply visa sponsorship; missing sponsorship always unknown.
- [ ] Global job refresh works without users; local Radar matches only when user visits, with honest no-offline-alert language.
- [ ] New-to-user versus newly published are distinct; missing from 7-day feed does not count as closed.
- [ ] External Apply never auto-marks Applied; only user-input status exists.
- [ ] Preferences and tracker import/export/delete work, with storage clearing/device-change warning and no PII in analytics.
- [ ] No matching job returns an honest empty state with substantive alternative tool/guide.
- [ ] Fraud/verified-employer badges never inferred from automated feeds.
- [ ] Per-origin rights flags for index/sitemap/schema/export/ads tested with deny-by-default fixtures.

## Job sync

- [ ] Cron successfully runs on actual chosen hosting.
- [ ] Provider rate limits and Retry-After respected.
- [ ] Failure cannot wipe healthy cache.
- [ ] Jobicy 7-day publication window disappearance isn't treated as closure.
- [ ] Himalayas 410 closed jobs hidden; 200 jobs remain available.
- [ ] Malformed jobs quarantined and logged, no fabricated fallback data.
- [ ] Each listing shows provider and last checked.
- [ ] Source outage clearly communicated and tools remain accessible.

## Useful tool behaviour

- [ ] T01 gross/net, deductions, FX, negatives/zeros checked.
- [ ] T02 variable bonuses and different pay periods checked.
- [ ] T03 output print/export works without ads.
- [ ] T04 costs can be user-edited; official fees not invented.
- [ ] T05 daylight-saving transitions tested.
- [ ] T06 local tracker import/export/delete works.
- [ ] T07 text-only interview remains usable without microphone.
- [ ] T08 country checklists cite official sources with review dates.
- [ ] T09 portfolio evidence not falsely verified.
- [ ] T10 roadmap links and timelines are clearly illustrative.
- [ ] Only completed tools shown as available in launch menus.

## SEO/ads/accessibility

- [ ] Original useful pages have proper titles, canonicals and source citations.
- [ ] Imported feed-only job pages noindex by default; filter URLs not mass-indexed.
- [ ] Sitemap contains only legitimate indexable pages.
- [ ] Ads not placed until publisher approval and compliance preflight.
- [ ] No ad overlap with job Apply, calculators or daily game buttons.
- [ ] Keyboard-only navigation and mobile UI tested.
- [ ] Core pages load despite disabled third-party APIs.
- [ ] Basic event measurement works without collecting raw PII.

## Business honesty

- [ ] No claim that free API links generate affiliate commission.
- [ ] ₹50,000/month is stated as an aspiration, never guaranteed outcome.
- [ ] Test fake jobs, fake testimonials and fake earnings not visible publicly.
- [ ] All costs (including hosting renewals) documented for founder.
- [ ] Operator knows how to disable a provider and restore a backup.

## Sample go/no-go report

| Blocker | Status | Evidence / action |
|---|---|---|
| Source terms and attribution | Open | Attach provider documentation links |
| Security tests | Open | Attach test results |
| Tool computations | Open | Attach test cases |
| Cron and backup restoration | Open | Attach logs |
| Privacy, original content, search | Open | Attach reviewed pages |
| AdSense readiness | Pending | No ad code until accepted |


## Founder cost, traffic and operational stop gates

- [ ] Paid services disabled. Existing hosting/cron/storage limits actually checked; no ₹0 guarantee for renewal costs.
- [ ] Founder's weekly incident review budget is measured; disable optional recruiter on unsafe backlog.
- [ ] AdSense and referral revenue attributed to *actual verified* transactions, not assumed outbound clicks.
- [ ] Google Ads are disabled until approved; imported-only pages are not mass-indexed/treated as original AdSense value.
- [ ] Actual first-value completion, India-eligible coverage and 7/30-day returning users monitored without sensitive analytics.

## Optional Recruiter Lite / Partner API (MANDATORY checks if enabled)

- [ ] Recruiter security and completeness requirements in `91_HISTORICAL_V12_TRACEABILITY.md` are separately resolved with tests, not assumed fixed by specification.
- [ ] `RECRUITER_LITE_ENABLED` and `PARTNER_POSTING_API_ENABLED` are `false` until separate release authorisation.
- [ ] Employer email/domain and organisational posting authority confirmed; overseas compliance cases reviewed.
- [ ] First few companies and first jobs are review gated; suspicious jobs quarantined.
- [ ] Every job has HTTPS employer/approved ATS destination, source/origin, eligibility, expiration and report action.
- [ ] Browser recruiter users can see/edit/close only jobs owned by their organisation.
- [ ] API partner tokens are long random secrets, one-time shown, hashed, scoped and revocable/rotatable.
- [ ] API idempotency, bad payloads and `401/403/404/409/422/429` responses contract-tested.
- [ ] Cross-tenant object access denied for GET/PATCH/close; mass-assignment cannot set `published` or `verified`.
- [ ] API listing returns **only the partner's own organisation jobs**, never imported Jobicy/Himalayas/partner feed rows.
- [ ] Imported feed-source restrictions and outbound apply links remain unchanged.
- [ ] Job expiry and immediate employer closure remove active listing and forbidden metadata.
- [ ] Posting throttling, suspicious URL detection, incident kill-switch, backup/restore tested.
- [ ] No unbounded anonymous API signup, no candidate upload/payment or heavy ATS.
- [ ] Current moderation workload fits solo founder; disable onboarding if it does not.
- [ ] Sample OpenAPI integration matches actual implementation; public docs never expose credentials.

---
## v1.3 mandatory reproducible contract checks

- [ ] `python 23_VALIDATE_SPEC.py` passes (API shapes, named module coverage, source semantics and golden calculations).
- [ ] For all M00–M17, `module_status.json` records documented / implemented / tested / deployed / blocked, with evidence.
- [ ] HTTPS employer URL, SSRF/redirect, tenant isolation, revoked tokens and review-state transitions tested before enabling recruiter posting.
- [ ] Provider selection, worldwide+timezone eligibility, JSON `pubDate`, Jobicy time-window absence, source-specific link, Google schema and resyndication prohibition tested.
- [ ] T01–T10 golden fixtures and security edge cases pass before corresponding tool is marked live.
- [ ] No repeated founder technical approval needed for ordinary agent engineering changes; new paid commitments still not allowed.

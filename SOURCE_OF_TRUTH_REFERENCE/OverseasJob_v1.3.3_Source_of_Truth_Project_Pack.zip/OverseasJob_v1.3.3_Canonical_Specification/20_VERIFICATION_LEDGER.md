# v1.3 Verification and Residual-Risk Ledger

**Status date:** 2026-11-22. This ledger distinguishes corrected *documentation* from unproven implementation.

| Item | Documentation check | Deployment/real-world status |
|---|---|---|
| 18 modules M00–M17 named and release-specified | Included in 15 | No code/live inventory reviewed |
| T01–T10 calculation/validation contracts | Included in 17 | No runnable website tests yet |
| Recruiter OpenAPI schema syntax and example | Run 23_VALIDATE_SPEC.py | No deployed endpoint, identity workflow or tenant tests |
| Visa sponsorship `yes/no/unknown` | Fixed in OpenAPI and prose | Need server validation |
| On-site work country non-null | Fixed in create schema; PATCH requires full state validation | Need server tests |
| Himalayas JSON API publication timestamp | v1.3.2 corrected: current official docs identify `pubDate` as publication date; `updatedAt` is feed refresh | Live API behaviour and real adapter output not tested |
| Himalayas geography/timezone array types and eligibility | v1.3.3 reconciles ISO2/name/object variants with pinned country dictionary; local fixtures exercised | Live provider response, volume and employer/geographic accuracy not verified |
| Jobicy bounded feed disappearance ≠ closed and `Anywhere` ≠ confirmed worldwide hiring | v1.3.2 specifies conservative unknown status | Need observed feed reconciliation |
| Source licensing | Current docs consulted; rights matrix retained | Must revalidate before public activation |
| Hiring-side direct employer supply | Optional guarded source | No employers contracted, trust verification unproved |
| Five original public guides | Five substantive original drafts and official reference links authored in local RC v0.3 | Editorial/legal review and source freshness approval still pending; not approved for public indexing |
| Game question bank, resume layouts, role roadmaps | Requirements and fixtures | Original assets MUST be authored |
| Hostinger PHP/cron and backups | Architecture conditional on actual plan | Host inspection REQUIRED |
| Monetisation and ₹50,000/month | Revenue mathematics defined | Actual AdSense/affiliate approval and traffic UNKNOWN |
| Analytics privacy/consent | Behaviour defined | Legal/configuration review REQUIRED |
| Local code and deployed website | Gate 1 RC v0.3 separate artifact contains independently tested PHP/JS modules, including T06 and private moderation queue | Still NOT deployed; real API/Hostinger, production SQL, browser E2E, privacy/restore proofs UNVERIFIED |

**Residual risks not eliminable by more writing:** external provider terms/rate limits may change; daily job count cannot be known without running real samples; on-site overseas-job supply not secured; recruiter verification takes human judgement; Google traffic/AdSense approval and income are not guaranteed. The agent must measure and report, not silently fill assumptions.

**Docs check result:** passing automatic document/schema checks only means files and selected contracts are internally consistent; it does NOT prove all conceivable logic bugs have been excluded. New contract changes require extending test fixtures and report.

**Out-of-scope certification:** Documentation syntax/fixture passes do not certify legal immigration claims, actual employer identities, paid API availability, live source permissions, every JavaScript calculation or production migrations. Agents need implementation-based evidence per module.

**v1.3.3 release blocker evidence:** The local app intentionally rejects `RELEASE_READY=1` without source-rights/live-data proof, reviewed content and real staging/privacy/backup evidence. Browser automation from this runtime is blocked by localhost administrator network policy; local HTTP and JS tests are not browser E2E.

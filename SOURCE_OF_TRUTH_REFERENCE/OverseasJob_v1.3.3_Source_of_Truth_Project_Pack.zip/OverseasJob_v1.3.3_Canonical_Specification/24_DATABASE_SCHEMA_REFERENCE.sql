-- OverseasJob.in v1.3 proposed canonical DB structure. DOCUMENTATION REFERENCE, NOT A LIVE MIGRATION.
-- Target MySQL 8 / MariaDB 10.6+ style InnoDB; agent must check actual hosting and test migration on backup/staging.
-- Explicitly NEVER import on production without tested backup/rollback; compatible changes are agent-authorised.
-- Set session time_zone='+00:00'; PHP adapter converts DB DATETIME in UTC to ISO-8601 on wire.

CREATE TABLE source_policies (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 slug VARCHAR(64) NOT NULL UNIQUE,
 policy_url VARCHAR(1000) NOT NULL,
 terms_reviewed_at DATETIME NULL,
 enabled TINYINT(1) NOT NULL DEFAULT 0,
 apply_field VARCHAR(64) NOT NULL,
 requires_attribution TINYINT(1) NOT NULL DEFAULT 1,
 allow_jobposting_schema TINYINT(1) NOT NULL DEFAULT 0,
 allow_resyndication TINYINT(1) NOT NULL DEFAULT 0,
 restrictions_json JSON NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE employer_orgs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(255) NOT NULL,
 website_https VARCHAR(1500) NULL,
 verified_domain VARCHAR(255) NULL,
 status ENUM('unverified','pending_review','approved','suspended','closed') NOT NULL DEFAULT 'unverified',
 identity_reviewed_at DATETIME NULL,
 identity_reviewed_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 INDEX idx_org_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE employer_users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 org_id BIGINT UNSIGNED NOT NULL,
 email VARCHAR(320) NOT NULL,
 password_hash VARCHAR(255) NULL,
 email_verified_at DATETIME NULL,
 role ENUM('org_admin','org_editor','org_reader') NOT NULL DEFAULT 'org_reader',
 disabled_at DATETIME NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 UNIQUE KEY uq_org_email (org_id,email),
 FOREIGN KEY (org_id) REFERENCES employer_orgs(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE employer_verification_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 org_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 verification_kind ENUM('email','domain','business_identity','representative_authority') NOT NULL,
 evidence_reference VARCHAR(1024) NULL, -- safe pointer only, never raw passport docs
 outcome ENUM('pending','approved','rejected','expired') NOT NULL DEFAULT 'pending',
 reviewed_at DATETIME NULL,
 reviewed_by BIGINT UNSIGNED NULL,
 created_at DATETIME NOT NULL,
 expires_at DATETIME NULL,
 FOREIGN KEY(org_id) REFERENCES employer_orgs(id),
 FOREIGN KEY(user_id) REFERENCES employer_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE jobs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 origin ENUM('provider','direct_employer') NOT NULL,
 source_policy_id BIGINT UNSIGNED NULL,
 provider_job_id VARCHAR(300) NULL,
 owner_org_id BIGINT UNSIGNED NULL,
 external_id VARCHAR(160) NULL,
 title VARCHAR(250) NOT NULL,
 company_name VARCHAR(255) NOT NULL,
 description_sanitized MEDIUMTEXT NULL,
 employment_type VARCHAR(48) NULL,
 work_mode ENUM('remote','hybrid','onsite','unknown') NOT NULL DEFAULT 'unknown',
 work_country CHAR(2) NULL,
 employer_country CHAR(2) NULL,
 location_text VARCHAR(255) NULL,
 candidate_eligible_countries_json JSON NULL,
 eligibility_evidence_json JSON NULL,
 india_eligibility_state ENUM('allowed','not_allowed','unknown') NOT NULL DEFAULT 'unknown',
 timezone_eligibility_state ENUM('allowed','not_allowed','unknown') NOT NULL DEFAULT 'unknown',
 visa_sponsorship ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
 relocation_support ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
 salary_min DECIMAL(18,2) NULL,
 salary_max DECIMAL(18,2) NULL,
 salary_currency CHAR(3) NULL,
 salary_period ENUM('hour','day','week','fortnight','month','year') NULL,
 source_url VARCHAR(1800) NOT NULL,
 apply_url VARCHAR(1800) NOT NULL,
 source_published_at DATETIME NULL,
 source_updated_at DATETIME NULL,
 first_seen_at DATETIME NOT NULL,
 last_seen_at DATETIME NOT NULL,
 last_verified_at DATETIME NULL,
 valid_through DATETIME NULL,
 availability ENUM('active','closed','stale','unknown') NOT NULL DEFAULT 'unknown',
 direct_post_status ENUM('draft','pending_review','published','closed','expired','rejected','suspended') NULL,
 revision INT UNSIGNED NOT NULL DEFAULT 1,
 content_hash CHAR(64) NULL,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 UNIQUE KEY uq_source_job (source_policy_id, provider_job_id),
 UNIQUE KEY uq_org_external_job (owner_org_id, external_id),
 INDEX idx_job_filter (origin,availability,india_eligibility_state,work_mode),
 INDEX idx_job_live (direct_post_status,valid_through),
 INDEX idx_job_fresh (last_verified_at),
 FOREIGN KEY (source_policy_id) REFERENCES source_policies(id),
 FOREIGN KEY (owner_org_id) REFERENCES employer_orgs(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- APPLICATION invariant: origin='provider' means source_policy_id and provider_job_id nonnull, owner_org_id/external_id null;
-- direct_employer means owner_org_id/external_id nonnull, source_policy_id/provider_job_id null; request must not update owner/origin.
-- APPLICATION invariant: onsite|hybrid requires nonnull work_country. Null is valid for remote only.
-- APPLICATION invariant: published direct post requires approved org, consent, current valid_through and review audit.

CREATE TABLE job_publication_consents (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 org_id BIGINT UNSIGNED NOT NULL,
 actor_user_id BIGINT UNSIGNED NOT NULL,
 terms_version VARCHAR(64) NOT NULL,
 allow_publish TINYINT(1) NOT NULL,
 allow_redistribute TINYINT(1) NOT NULL DEFAULT 0,
 recorded_at DATETIME NOT NULL,
 source_request_id VARCHAR(128) NULL,
 FOREIGN KEY (job_id) REFERENCES jobs(id),
 FOREIGN KEY (org_id) REFERENCES employer_orgs(id),
 FOREIGN KEY (actor_user_id) REFERENCES employer_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE job_status_audit (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 from_status VARCHAR(32) NULL,
 to_status VARCHAR(32) NOT NULL,
 actor_type ENUM('cron','org_user','api_client','admin','provider') NOT NULL,
 actor_ref VARCHAR(128) NULL,
 reason_code VARCHAR(64) NOT NULL,
 occurred_at DATETIME NOT NULL,
 FOREIGN KEY (job_id) REFERENCES jobs(id),
 INDEX idx_job_audit (job_id,occurred_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE partner_tokens (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 org_id BIGINT UNSIGNED NOT NULL,
 token_prefix CHAR(12) NOT NULL,
 secret_hash CHAR(64) NOT NULL,
 scope_json JSON NOT NULL,
 expires_at DATETIME NULL,
 revoked_at DATETIME NULL,
 created_at DATETIME NOT NULL,
 last_used_at DATETIME NULL,
 FOREIGN KEY (org_id) REFERENCES employer_orgs(id),
 UNIQUE KEY uq_token_prefix (token_prefix)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE api_idempotency (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 org_id BIGINT UNSIGNED NOT NULL,
 idempotency_key VARCHAR(128) NOT NULL,
 request_hash CHAR(64) NOT NULL,
 response_code SMALLINT UNSIGNED NOT NULL,
 response_body_json JSON NOT NULL,
 expires_at DATETIME NOT NULL,
 created_at DATETIME NOT NULL,
 UNIQUE KEY uq_org_idempotency (org_id,idempotency_key),
 FOREIGN KEY (org_id) REFERENCES employer_orgs(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE sync_runs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 source_policy_id BIGINT UNSIGNED NOT NULL,
 started_at DATETIME NOT NULL,
 completed_at DATETIME NULL,
 outcome ENUM('running','completed','partial','failed') NOT NULL,
 cursor_checkpoint VARCHAR(2000) NULL,
 fetched_count INT UNSIGNED NOT NULL DEFAULT 0,
 inserted_count INT UNSIGNED NOT NULL DEFAULT 0,
 updated_count INT UNSIGNED NOT NULL DEFAULT 0,
 error_code VARCHAR(64) NULL,
 FOREIGN KEY (source_policy_id) REFERENCES source_policies(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE job_reports (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_id BIGINT UNSIGNED NOT NULL,
 report_type ENUM('closed','scam','wrong_eligibility','broken_link','other') NOT NULL,
 detail_sanitized VARCHAR(1500) NULL,
 status ENUM('new','triage','resolved','dismissed') NOT NULL DEFAULT 'new',
 created_at DATETIME NOT NULL,
 resolved_at DATETIME NULL,
 FOREIGN KEY (job_id) REFERENCES jobs(id),
 INDEX idx_reports_queue(status,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE daily_job_aggregates (
 job_id BIGINT UNSIGNED NOT NULL,
 day_utc DATE NOT NULL,
 page_views BIGINT UNSIGNED NOT NULL DEFAULT 0,
 outbound_clicks BIGINT UNSIGNED NOT NULL DEFAULT 0,
 PRIMARY KEY(job_id,day_utc),
 FOREIGN KEY (job_id) REFERENCES jobs(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- No candidate accounts, resumes, passwords or passports are stored in this database in MVP.
-- Production implementation must include tested safe migrations, rollbacks, auth sessions/recovery and data retention.

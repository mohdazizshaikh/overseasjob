## v1.3.3 — 22 November 2026 (country normalization + Gate 1 implementation alignment)

- Reconciled divergent Himalayas official examples: canonicalise ISO2 codes, recognised country names, and legacy `{alpha2,name}` objects; invalid/mismatched evidence => unknown. Preserve explicit timezone gate.
- Documented source-published date as a source statement (not independently proven job creation) and retained upstream data-contract uncertainty where documented examples diverge.
- Added implementation contracts for original unreviewed guide assets, local-only application tracker T06, persistent administrator quarantine and evidence-based release gating.
- An isolated **local RC v0.3** implements/test-drives these submodules; the *canonical pack remains requirements*, not certification of production deployment or live provider results. No new paid API, candidate accounts, recruitment payments, or automatic applications.

## v1.3.2 — 22 November 2026 (source-adapter contract correction)

- Rechecked primary Jobicy and Himalayas source documentation. Corrected Himalayas browse pagination from presumed `nextCursor` to documented `offset/limit/totalCount`, with cursor supported only if actually returned.
- Corrected upstream `locationRestrictions` to `string[]` and `timezoneRestrictions` to numeric UTC-hour `number[]`; empty means unrestricted in that dimension.
- Corrected Himalayas job-level `pubDate` to documented publication date; response `updatedAt` is feed refresh, not job update. Unknown/unverified dates stay unknown.
- Clarified Jobicy `Anywhere` as unspecified geography, not automatically confirmed India eligibility; absent timezone proof stays unknown.
- Aligned README read order with `00_SOURCE_OF_TRUTH.md`. No new product modules or launch claims.
- Actual live provider response, host infrastructure, original five guides and production deployment remain UNVERIFIED.

## v1.3.1 — 22 November 2026 (governance only)

- Added `00_SOURCE_OF_TRUTH.md` as authority/register and conflict-resolution index. No functional requirements or API schemas changed.
- README starts from that register. Historical audits and generated Word/Markdown exports remain non-authoritative.
- Verification status unchanged: this package is documentation, not a live website.

# OverseasJob.in — Blueprint Change Log

## v1.1 — 22 November 2026 — Verified employer posting and Partner API

### Added
- Recruiter Lite: verified employer onboarding, job submission/edit/close, basic analytics and company profiles.
- Separate **inbound** REST Job Posting API for approved organisations / ATS integration; versioned endpoints, draft OpenAPI 3.1 schema, authentication and idempotency.
- New company and API security model: organisation tenancy, scope-limited tokens, employer-domain checks, content restrictions, expiry, rate limits, incident kill switches and manual exception review.
- Source-rights boundary: partner API never redistributes imported third-party job feed data.
- Dedicated employer data model examples, QA tests, milestone gates and master agent instructions.

### Retained / unchanged
- Initial public MVP: automated permitted job discovery, anonymous browsing and core free career utilities.
- ₹0 additional paid-API subscription constraint; actual existing hosting and security capabilities must be verified.
- Ads-first monetisation hypothesis; no guaranteed income, fake vacancies, candidate fees, paid job applications or uncontrolled ATS workload.

### Scope and rollout
- **Phase 2B (conditional):** Recruiter Lite verified small pilot.
- **Phase 3B (conditional):** API keys/inbound posting integration for trusted ATS/employers.
- Both remain **disabled** if the founder lacks safe verification/moderation capacity. No production API exists as a result of these documents alone.


## v1.2 — 22 November 2026 — Decision Companion + Pipeline Risk Remediation (DOCUMENTATION ONLY)

### Added
- Job Decision Cards with evidence-labelled India eligibility, source-aware freshness, work mode/visa separation and next actions.
- Browser-local Opportunity Radar and career follow-ups; honest on-visit matching vs offsite alerts.
- 14-day real feed coverage/sample gate; no assumption of India-eligible supply.
- Source-policy rendering/index/schema/ads/export deny flags and explicit canonical public JobView.
- Candidate flow metrics and financial stop rules; recruited employer demand and operational caps as gates.
- `10_DECISION_COMPANION_PRODUCT_SPEC.md` and `91_HISTORICAL_V12_TRACEABILITY.md`.

### Resolved in documentation, NOT implementation
- Clarified job status/ownership source separation, recruiter authentication decision, posting state/consent, idempotency, revision conflict, date fields, privacy/backups/retention and no resyndication.
- Reordered milestones; deleted `overeseasjob/` typo and redundant no-account line.

### Still unverified
- Live Hostinger configuration, 14-day API results, permission enforcement in deployed code, real users, SEO traffic, partner approval, AdSense revenue, employer pilot operations and actual tests.


## v1.3 (2026-11-22) — full-access autonomy and contract hardening

Corrected partner API sponsor enum (`yes|no|unknown`), on-site nonnull country and recruiter curl naming; added patch parity, contract fixture tests, readable canonical README, 18-module register, source/date/eligibility pipeline, exact tools formula fixtures, browser-local Radar status and founder full-access AI agent autonomy. Introduced v1.3 SQL reference and validation ledger. Archived non-normative previous findings under 90–92. **No working website or verified production implementation is claimed.**

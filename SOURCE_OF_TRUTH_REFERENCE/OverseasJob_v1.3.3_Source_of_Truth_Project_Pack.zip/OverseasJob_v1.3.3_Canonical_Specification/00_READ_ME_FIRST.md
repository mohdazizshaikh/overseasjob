# OverseasJob.in — Canonical AI-agent Project Pack v1.3.3

**Prepared:** 22 November 2026  
**Authority:** `00_SOURCE_OF_TRUTH.md` defines the normative owner for every requirement. Version 1.3.3 preserves v1.3.1 governance and v1.3.2 pagination/date safeguards; it also requires consistent ISO/name/object country normalisation, local-first application tracking, persistent moderation holds and documented release verification. The Source of Truth remains a specification, not a live implementation.  
**State:** DOCUMENTATION / IMPLEMENTATION SPECIFICATION ONLY. No working product or deployment is asserted.

## Start in this order

0. **`00_SOURCE_OF_TRUTH.md` — authoritative file ownership, conflict precedence, full agent autonomy and versioning.**
1. `01_COMPLETE_PROJECT_BLUEPRINT.md` — business purpose, user promises and scope.
2. `15_CANONICAL_MODULE_REQUIREMENTS.md` — every module, complete user workflows, edge cases and release gates.
3. `16_DATA_AND_OPERATIONS_CONTRACT.md` — provenance, legal/source rules, matching, status, automation, recovery.
4. `17_TOOL_ALGORITHMS_AND_FIXTURES.md` — deterministic formula/validation/test cases for ten utilities.
5. `08_PARTNER_JOB_POSTING_API_OPENAPI.yaml` — canonical inbound partner HTTP contract; **not yet deployed**.
6. `07_RECRUITER_LITE_AND_PARTNER_API.md` — recruiter workflow, trust and API restrictions.
7. `19_AGENT_AUTONOMY_AND_DELIVERY.md` — full technical autonomy.
8. `18_TEST_FIXTURES.json`, `23_VALIDATE_SPEC.py` and `24_DATABASE_SCHEMA_REFERENCE.sql` — executable document/contract tests.
9. `20_VERIFICATION_LEDGER.md` — what was actually checked.
10. `02_AI_AGENT_MASTER_PROMPT.md` — supplemental execution context.
11. `03_MILESTONE_TASKS.md`, `04_QA_AND_LAUNCH_CHECKLIST.md`, `05_SOURCE_POLICY_MATRIX.csv`, `06_ARCHITECTURE_AND_DATABASE.md`, `10_DECISION_COMPANION_PRODUCT_SPEC.md` — supporting references.
12. `90_*`, `91_*`, `92_*` — historical only; not active instructions.

**Precedence:** Refer first to `00_SOURCE_OF_TRUTH.md` for the full cross-module authority map. Partner HTTP request/response shape: OpenAPI > other prose. User/business behaviour: `15_*` > historical prose. Source status, eligibility, operations: `16_*`. Tool mathematics: `17_*`. Historical audits are evidence, not build instructions. If a contradiction exists, repair current documents/tests automatically and log it; no silent invention.

## What the founder authorises

The founder is nontechnical and gives the coding agent full technical access to existing authorised infrastructure. Do not demand approval for each command, file edit, technical choice or normal deployment step. Be self-directed: inspect → implement → test → fix → deploy safely if environment authorises → verify → document. Make backups and use rollback. Do not incur new paid commitments, misrepresent live features, enable unsafe public recruiter onboarding, or violate third-party licences. For unknown external credentials, law, terms or hosting limits, record a precise blocker and complete independent work.

## Product promise

Remote work and overseas career *decision support* for India-based users, with source-backed job discovery, honest eligibility, Job Decision Cards, no-login Opportunity Radar, 10 genuinely functioning free utilities, original guidance and optional simple Daily Arena. Recruiter Lite / inbound API are designed but gated; candidate ATS, placement service, auto-apply and resyndication of imported jobs are excluded.

## Execution

Run `python 23_VALIDATE_SPEC.py` before code generation and after any contract edit. Create test evidence from **actual implementation**, not merely from documents. Deploy no paid external systems. Core gate order: source-coverage proof → source-backed jobs/Decision Cards/first 3 tools → local Radar/tracker → remaining utilities/game → recruiter pilot/partner API only if safety and capacity allow. The agent can progress autonomously through stages if automated gates pass, without asking for a technical review from the non-developer founder.

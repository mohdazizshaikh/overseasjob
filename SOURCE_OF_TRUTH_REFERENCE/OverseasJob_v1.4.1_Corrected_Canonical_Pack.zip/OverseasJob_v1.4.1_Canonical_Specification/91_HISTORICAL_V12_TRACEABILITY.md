# v1.2 Traceability and Documentation Decision Log

**Date:** 2026-11-22 | **Status:** DOCUMENTATION UPDATED; IMPLEMENTATION NOT INSPECTED.

Canonical product decisions are in `01_COMPLETE_PROJECT_BLUEPRINT.md`, operational contract in `10_DECISION_COMPANION_PRODUCT_SPEC.md`, source law in `05_SOURCE_POLICY_MATRIX.csv`, optional employer API in `07_*` and `08_*`.

## Scope / gate order

`Gate 0 supply+hosting → Gate 1 Decision Cards and 3 utilities → Gate 2 local Radar/tracker → Gate 3 retention test`. Optional independent branch `Gate 2B Recruiter Lite → Gate 3B inbound job posting API`, approved only if there is real partner demand and sustainable moderation. Every optional module is feature-flagged OFF. No cloud candidate account/email alerts and no automatic application status.

## Duplicate / source-of-truth policy

- Canonical editable master document: `01_COMPLETE_PROJECT_BLUEPRINT.md`. Word and root Markdown copies are GENERATED exports, not separate sources of truth.
- Source API terms and government policy are not frozen guarantees; verify again before deployment and material changes.
- Status categories: `Specified in docs` is NOT `Implemented`; code evidence and passing tests are still missing.
- Do not pretend the v1.1 static audit items are remediated in production by a document update.

## Product risk mapping (v1.2 review)

| Risk IDs | v1.2 requirement / evidence still missing | Status |
|---|---|---|
| P01,P06,P19 | Remote-vs-overseas distinction, explicit eligibility evidence, official country guide dates | Specified; live job coverage/guide review pending |
| P02,P07,P08,P22 | 14-day sample, date/closure/staleness logic and honest no-results | Specified; live feed sampling and cron tests pending |
| P03,P09,P10 | Job Decision Cards, explainability and no-login first run | Specified; usability validation pending |
| P04,P11,P12 | Local Radar, manual application tracking, JSON import/export; offline alert excluded | Specified; browser tests pending |
| P05,P13,P18,P20,P21 | Budget/SEO/ads funnel, three tools first, one optional game, no ToolBoxGalaxy duplication | Specified; financial performance unknown |
| P14,P15,P16,P17,P23 | Source rights + verified employer pilot; Partner API fully gated | Specified; recruiter verification/release evidence pending |

## v1.1 technical audit—every finding remains release-gated until code-tested

| Audit ID | Issue | Documentation fix specification | Implementation status |
|---|---|---|---|
| C01 | Job provenance + tenant ownership ka single enforceable data model nahi | 06_ARCHITECTURE_AND_DATABASE.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| C02 | Employer identity verification / human login end-to-end unspecified | 07_RECRUITER_LITE_AND_PARTNER_API.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| C03 | Company verification + URL validation ko testable trust workflow nahi diya | 07_RECRUITER_LITE_AND_PARTNER_API.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| C04 | Solo founder ke liye moderation operational limit defined nahi | 07_RECRUITER_LITE_AND_PARTNER_API.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| C05 | Production-readiness evidence absent — specification != implementation | 07_RECRUITER_LITE_AND_PARTNER_API.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H01 | ATS integration mein external_id based reconciliation incomplete | 06_ARCHITECTURE_AND_DATABASE.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H02 | JobResponse insufficient for a real partner sync | 08_PARTNER_JOB_POSTING_API_OPENAPI.yaml; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H03 | 201 pending_review status promise schema mein locked nahi | 08_PARTNER_JOB_POSTING_API_OPENAPI.yaml; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H04 | Publication consent and verification evidence not persisted in example DB | 06_ARCHITECTURE_AND_DATABASE.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H05 | Remote vs relocation location semantics ambiguous | 06_ARCHITECTURE_AND_DATABASE.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H06 | API schema business validation underdefined | 08_PARTNER_JOB_POSTING_API_OPENAPI.yaml; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H07 | Job state machine and concurrent edits not fully specified | 06_ARCHITECTURE_AND_DATABASE.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H08 | Recruiter analytics promised, underlying event model missing | 06_ARCHITECTURE_AND_DATABASE.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H09 | Job freshness/expiry confidence has no quantified TTL policy | 06_ARCHITECTURE_AND_DATABASE.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H10 | Idempotency retention & atomicity not specified | 06_ARCHITECTURE_AND_DATABASE.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H11 | UTC timestamps vs SQL DATETIME conversion lacks contract | 06_ARCHITECTURE_AND_DATABASE.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H12 | Data deletion, retention and employer offboarding not complete | 06_ARCHITECTURE_AND_DATABASE.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H13 | Google SEO/indexing matrix for every job origin not an executable policy | 06_ARCHITECTURE_AND_DATABASE.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| H14 | ₹50K/month monetisation model ka measurable feasibility gate missing | 01_COMPLETE_PROJECT_BLUEPRINT.md / milestones / QA; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| M01 | Phase 2B/3 ordering differs across roadmap files | 01_COMPLETE_PROJECT_BLUEPRINT.md / milestones / QA; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| M02 | Planned original guides and country content are not actually authored | 01_COMPLETE_PROJECT_BLUEPRINT.md / milestones / QA; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| M03 | Tool functional examples and expected results are not provided | 01_COMPLETE_PROJECT_BLUEPRINT.md / milestones / QA; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| M04 | Documented accessibility and performance targets lack actual test harness | 01_COMPLETE_PROJECT_BLUEPRINT.md / milestones / QA; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| M05 | OpenAPI has no realistic examples, SDK/retry policy or changelog mapping | 08_PARTNER_JOB_POSTING_API_OPENAPI.yaml; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| M06 | Site/company profile promise lacks a public profile storage contract | 07_RECRUITER_LITE_AND_PARTNER_API.md; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| M07 | Overseas branding vs remote-only initial inventory needs stronger page messaging | 01_COMPLETE_PROJECT_BLUEPRINT.md / milestones / QA; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| M08 | Complete user support/reporting workflow is only described at headline level | 01_COMPLETE_PROJECT_BLUEPRINT.md / milestones / QA; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| L01 | Duplicate sentences in the main blueprint | 01_COMPLETE_PROJECT_BLUEPRINT.md / milestones / QA; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| L02 | Word + Markdown aliases are byte-identical copies | 01_COMPLETE_PROJECT_BLUEPRINT.md / milestones / QA; see v1.1 audit's original required acceptance test | Not implemented / test pending |
| L03 | Typo in proposed repository directory name | 01_COMPLETE_PROJECT_BLUEPRINT.md / milestones / QA; see v1.1 audit's original required acceptance test | Not implemented / test pending |

## Evidence needed for actual engineering close-out

Attach actual repository diff, migration files, source API test fixtures, generated OpenAPI validation report, external URL/SSR F threat tests, company verification records, posting state transitions, security test logs, hosting/cron proof, backups/restore, and a signed deploy-gate checklist. Those artefacts do not yet exist here.

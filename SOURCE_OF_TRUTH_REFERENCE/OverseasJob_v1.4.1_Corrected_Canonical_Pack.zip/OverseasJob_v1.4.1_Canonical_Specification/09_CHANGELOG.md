## 2026-11-23 — v1.4.1 corrective reconciliation (official API compatibility)

- Fixed v1.4 Himalayas pagination `nextCursor` error: official browse is offset/limit (max 20)/totalCount.
- Corrected `pubDate` from alleged update to provider-documented original publication UTC Unix milliseconds; feed `updatedAt` stays feed metadata.
- Corrected `locationRestrictions` to country objects and `timezoneRestrictions` to UTC offset strings, with deterministic country+timezone eligibility fixtures.
- Removed claims of undocumented public per-job Himalayas status/410 URL.
- Replaced unverified Jobicy 7-day/cursor claims with current bounded latest-results behavior; absence never equals closure.
- Recorded existing GitHub implementation and important repo/test compatibility gap without claiming deployment; replaced inaccurate code-not-found assumption.
- Preserved all M00–M17, T01–T10, employer API contract, privacy/gates and existing source policies.

## 2026-11-23 — v1.4.0 canonical authority and execution-readiness pass

- Merged `00_SOURCE_OF_TRUTH.md` into the ZIP as first-class authority; regenerated editable manifest and Word/Markdown exports.
- Repaired conflicting older AI-agent approval instructions and `/arena` vs `/daily` route ownership.
- Normalised persisted eligibility states; updated numeric Himalayas offset fixtures and expanded adversarial cases.
- Corrected T01 numerical typo and nullable source-company SQL reference.
- Added honest initial status inventory for M00–M17, founder handoff, audit ledger and expanded documentation validation.
- No working website, host inspection, live source sampling, employer approval or ads income is represented as completed.

# OverseasJob.in — Blueprint Change Log

## v1.1 — 22 November 2026 — Verified employer posting and Partner API

### Added
- Recruiter Lite: verified employer onboarding, job submission/edit/close, basic analytics and company profiles.
- Separate **inbound** REST Job Posting API for approved organisations / ATS integration; versioned endpoints, draft OpenAPI 3.1 schema, authentication and idempotency.
- New company and API security model: organisation tenancy, scope-limited tokens, employer-domain checks, content restrictions, expiry, rate limits, incident kill switches and manual exception review.
- Source-rights boundary: partner API never redistributes imported third-party job feed data.
- Dedicated employer data model examples, QA tests, milestone gates and master agent instructions.

### Retained / unchanged
- Initial public MVP: automated permitted job discovery, anonymous browsing and core free career utilities.
- ₹0 additional paid-API subscription constraint; actual existing hosting and security capabilities must be verified.
- Ads-first monetisation hypothesis; no guaranteed income, fake vacancies, candidate fees, paid job applications or uncontrolled ATS workload.

### Scope and rollout
- **Phase 2B (conditional):** Recruiter Lite verified small pilot.
- **Phase 3B (conditional):** API keys/inbound posting integration for trusted ATS/employers.
- Both remain **disabled** if the founder lacks safe verification/moderation capacity. No production API exists as a result of these documents alone.


## v1.2 — 22 November 2026 — Decision Companion + Pipeline Risk Remediation (DOCUMENTATION ONLY)

### Added
- Job Decision Cards with evidence-labelled India eligibility, source-aware freshness, work mode/visa separation and next actions.
- Browser-local Opportunity Radar and career follow-ups; honest on-visit matching vs offsite alerts.
- 14-day real feed coverage/sample gate; no assumption of India-eligible supply.
- Source-policy rendering/index/schema/ads/export deny flags and explicit canonical public JobView.
- Candidate flow metrics and financial stop rules; recruited employer demand and operational caps as gates.
- `10_DECISION_COMPANION_PRODUCT_SPEC.md` and `91_HISTORICAL_V12_TRACEABILITY.md`.

### Resolved in documentation, NOT implementation
- Clarified job status/ownership source separation, recruiter authentication decision, posting state/consent, idempotency, revision conflict, date fields, privacy/backups/retention and no resyndication.
- Reordered milestones; deleted `overeseasjob/` typo and redundant no-account line.

### Still unverified
- Live Hostinger configuration, 14-day API results, permission enforcement in deployed code, real users, SEO traffic, partner approval, AdSense revenue, employer pilot operations and actual tests.


## v1.3 (2026-11-22) — full-access autonomy and contract hardening

Corrected partner API sponsor enum (`yes|no|unknown`), on-site nonnull country and recruiter curl naming; added patch parity, contract fixture tests, readable canonical README, 18-module register, source/date/eligibility pipeline, exact tools formula fixtures, browser-local Radar status and founder full-access AI agent autonomy. Introduced v1.3 SQL reference and validation ledger. Archived non-normative previous findings under 90–92. **No working website or verified production implementation is claimed.**

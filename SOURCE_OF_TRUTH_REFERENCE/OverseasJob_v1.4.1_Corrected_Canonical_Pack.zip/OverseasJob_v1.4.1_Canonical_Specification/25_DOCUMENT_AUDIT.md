# v1.4.1 canonical documentation audit / residual-risk report

**Run date:** 2026-11-23. **Scope:** offline canonical documentation, API schema and golden fixtures; selected public provider documentation checked. No active hosting, source sample data, website repository or deployment in this pack.

## Corrections in this release

- Merged the previously standalone `00_SOURCE_OF_TRUTH.md` (v1.3.1) *into* the ZIP and its hashed manifest, eliminating missing top-level authority.
- Removed contradictory Phase 0 / Phase 1 technical founder approval language in `02_*`; retained business, paid, identity and compliance gates.
- Standardised optional Daily Arena route to `/arena`; `/daily` is at most a redirect, not a second experience.
- Standardised eligibility persisted states to `allowed|not_allowed|unknown`; `explicitly_*` remains UX wording only.
- Fixed misleading T01 fixture typo: 58000/108000 is 53.7037%, not 48.33%.
- v1.4 numeric timezone fixture was itself incorrect against official OpenAPI: replaced it with official string UTC offsets and location objects; added unknown, invalid and allowed truth-table cases.
- Corrected SQL reference `company_name` nullability to preserve unknown source information; actual migration still untested.
- Initialised truthful machine-readable `module_status.json` (all specified; no invented implementation).
- Expanded document validator to examine extra fixtures, negative API cases, authoritative file order, module statuses and manifest integrity.
- Rebuilt derived human-readable exports and SHA-256 release manifest; historical v1.1/v1.2 materials remain separate and non-normative.

## Public provider documentation context checked 23 November 2026

- Himalayas docs https://himalayas.app/docs/remote-jobs-api and https://himalayas.app/terms describe required exact `applicationLink`, visible attribution and no downstream redistribution/Google Jobs/JobPosting; OpenAPI `pubDate` means publication in Unix milliseconds; `timezoneRestrictions` is string[] and `locationRestrictions` is object[].
- Current Jobicy documentation https://jobicy.com/jobs-rss-feed documents at most 100 latest JSON results with count/geo/industry/tag filters; it does not document cursor pagination or guarantee a universal 7-day window. Disappearance alone does not prove closure.
- These page reads DO NOT verify a complete live API traversal, real eligibility counts, contract suitability for *every* planned use, hosting operational limits or future terms. Recheck at source activation.

## Critical remaining release blockers / evidence owners

| Area | Evidence still required | Owner | Production-safe fallback |
|---|---|---|---|
| Hosting/Gate 0 | Hostinger actual PHP, DB, cron, SSL, backups and authorised repo snapshot | AI coding agent from real environment | No public deployment |
| Source feed/Gate 0 | 14 actual sampling days in priority roles, pagination, quotas, country/timezone fields, status verification | Agent + provider terms | Do not claim India-eligible daily supply; tools still work |
| Content/Gate 1 | Five original reviewed guides, policies and official-source dates | Agent prepares; trusted review needed on sensitive rules | Do not publish unverified legal guidance |
| Runtime/Gate 1 | Functional system tests, source license checks, security scans, A11y, real backup/restore, production smoke | Agent with real code/host | Not live |
| Employer trust/Gates 2B–3B | Real verified organisations, capacity for human review, tenant isolation, token tests and moderation | Authorised human trust reviewer + agent | Disable recruiter/API flags |
| Ads/revenue | Actual Google AdSense approval, lawful consent configuration, traffic and RPM | Publisher account owner | ADS_ENABLED=false; ₹0 assumed |

## Quality boundary

A green documentation validator is *not* functional website testing. The initial external checks were a reading of official webpages, not a complete live feed experiment or a legal opinion. No promise of 100% bug-free code or guaranteed revenue is justified.

## Source-of-truth correction added 2026-11-23 (v1.4.1)

The earlier **138/138 green contract checks did not validate the upstream API field contracts**. Current official Himalayas OpenAPI specifies `GET /jobs/api` offset/limit/totalCount; `pubDate`/`expiryDate` integer Unix ms; `locationRestrictions` country objects with `alpha2`; `timezoneRestrictions` string UTC offsets; only browse/search routes, no public per-job 410 checker. v1.4 had contradictory authoritative prose and numeric fixtures. This update corrects those declarations, includes explicit regression fixtures, and records the discovered existing GitHub PHP code. Do not deploy until repo-specific integration and actual private/host evidence are established.

# HISTORICAL v1.1 AUDIT — NOT CURRENT SPECIFICATION

All technical issues remain release-gated until their v1.2 requirements are implemented and tested. See `11_V12_TRACEABILITY_AND_DECISIONS.md`.

---

# OverseasJob.in — v1.1 Documentation, API & Architecture Audit

**Report date:** 22 November 2026  
**Audit type:** Static cross-document review + packaging checks + draft OpenAPI schema/ref validation + official source-policy spot checks.  
**Scope:** v1.1 ten-file project pack, root Markdown and Word blueprints (25 rendered pages).  
**Not in scope:** running source code, live website, hosting, real employer accounts, production API, secrets, SEO/AdSense dashboards. No implementation was supplied in the pack.

## Executive decision

**Do not hand the entire pack to an AI coding agent with a “build everything now” instruction.** Main automated job-discovery MVP can proceed after Phase 0. Recruiter Lite and inbound API remain gated until identity, schema, moderation, consent and sync semantics have been concretely specified and tested. This is a good **draft specification**, not a production-ready design or live app.

**Findings:** 5 Critical, 14 High, 8 Medium, 3 Low = **30 items**. Critical findings apply to *affected* release gates, especially recruiter/API features, and do not automatically block the anonymous job-tools MVP.

## Checks that passed

- ZIP archive `OverseasJob_AI_Agent_Project_Pack_v1.1.zip`: testzip PASS; all **10 entries** match disk copies byte for byte.
- Main project Markdown and `01_COMPLETE_PROJECT_BLUEPRINT.md`: exactly identical. Both DOCX filenames: identical bytes. These are not logical duplicates or errors.
- OpenAPI file: parses as YAML, declares **OpenAPI 3.1.0**, contains **6 HTTP operations on 4 paths**, all **36 internal `$ref` occurrences resolve**, and all **5 reusable JSON schemas** pass Draft 2020-12 standalone structural schema checks. **Not** a full OpenAPI validator/security audit.
- Data-source distinction between third-party imported jobs and first-party employer jobs is conceptually correct.
- Core product does not require candidate login, payment gateway or paid AI inference.
- Source terms verified against current official Jobicy, Himalayas and Google JobPosting guidance (linked below).

## 1. Full finding register

### Critical — 5 findings

#### C01. Job provenance + tenant ownership ka single enforceable data model nahi

**Category:** Schema / source-rights mismatch  
**Where:** `01 blueprint §4B, §10.2 (lines 216–242, 482–498); 07 §2 (lines 21–28); 06 §3/§9 (lines 78–148, 230–315)`  
**Evidence:** 07 says every job record must include origin_type, owner_org_id, publish_consent, distribution_consent, verification_status, moderation_status and source_policy_id. Feed jobs have jobs(provider_id/status=active); first-party jobs are in employer_jobs(org_id/moderation_status=published), without most of the named common fields. The merge is described but no canonical view, mapping, permission policy or migration exists.

**Impact:** A coder could accidentally publish pending jobs, return third-party feed jobs through partner API, or confuse active/published and licence flags.

**Required correction:** Define canonical JobView DTO with origin=provider|direct_employer|licensed_partner, owner_org_id (nullable), source_policy_id, publish_rights, partner_export_allowed=false by default, public_status, apply_url, attribution. Define explicit mapping from each table to public search, sitemap, partner API and audit; keep imported feed rows impossible to export by query design.

**Acceptance test:** Automated tests: pending/expired employer jobs never appear; provider jobs never appear in API /jobs; own-org only; distribution consent cannot override source licence.

#### C02. Employer identity verification / human login end-to-end unspecified

**Category:** Authentication blocker  
**Where:** `07 §3–4 (lines 29–52); 06 §9 SQL (lines 235–267); 02 prompt (lines 21–38)`  
**Evidence:** org_members.password_hash is nullable; plan requires email confirmation, organisation/domain control and account recovery, but no chosen sign-in mechanism, session store, reset flow, email delivery method or org representative evidence/role matrix is specified.

**Impact:** A secure implementation cannot be approved from a list of principles; impersonated employer accounts could submit fraudulent jobs.

**Required correction:** Write auth ADR: session-cookie login or trusted available identity provider, verified sender mail and recovery, session revocation, credential hashing, brute-force throttling, invite process, org membership approval and concrete owner/editor/viewer permission matrix. If free email + verification cannot work, keep Recruiter Lite disabled.

**Acceptance test:** E2E register→confirm→org verify→login→edit own job→logout/reset; malicious or unapproved employer gets no posting permission.

#### C03. Company verification + URL validation ko testable trust workflow nahi diya

**Category:** Trust / scam blocker  
**Where:** `07 §§3,5,8 (lines 29–39,54–64,128–138); 04 QA lines 83–99`  
**Evidence:** Independent company identity checks, validated apply destination and high-risk overseas jobs are required, but what evidence is accepted, who reviews, when approval expires, and how redirects after allowed ATS links are handled is not formalised.

**Impact:** Phishing or overseas employment scam postings may slip through or genuine employers be wrongly accepted.

**Required correction:** Create verification checklist and evidence table, re-verification cadence, ATS tenant ownership rules, redirect-chain checks (including DNS rebinding/SSRF protection), and human review queue for first/suspicious posts. Do not auto-award verified badges.

**Acceptance test:** Test lookalike domains, URL shorteners, redirect chains, private IP resolution, changed ATS tenant, and invalid foreign recruiter claims.

#### C04. Solo founder ke liye moderation operational limit defined nahi

**Category:** Business/operations conflict  
**Where:** `01 §§1,4A,13 (lines 20–43,189–214,597–605); 07 §§1,8 (lines 8–19,128–138)`  
**Evidence:** Model promises minimal manual work but employer pilot adds company approval, first-job review, reports, phishing exceptions and possible legal verification. Daily digest exists, but queue size, turnaround, escalation and pause thresholds are not quantified.

**Impact:** If employer submissions grow, one person becomes the moderation department; zero-manual-work goal breaks.

**Required correction:** Pilot invite-only. Cap active organisations and new posts; define safe auto-reject, review-required and quarantine rules, maximum daily review budget, response SLA and backlog kill-switch. Allow entire recruiter phase to be skipped without impacting core jobs/tools.

**Acceptance test:** Exercise 100 spam jobs and an alert backlog scenario; ensure rate caps, quarantine and feature-off controls function without a human monitoring continuously.

#### C05. Production-readiness evidence absent — specification != implementation

**Category:** Release blocker (not a document contradiction)  
**Where:** `00 README lines 5–7; 01 blueprint lines 5–8; 06 lines 1–5; 08 header lines 1–13`  
**Evidence:** All files explicitly state proposed future implementation. This ZIP contains Markdown, CSV and YAML; it has no runnable website, migrations, CI fixtures, hosting inventory, deployed API, test output or observability proof.

**Impact:** A coding agent must not treat valid documentation as a finished platform, or claim security/launch readiness.

**Required correction:** Execute Phase 0 first: inspect hosting and repository, choose runtime, write reviewed migrations, implement small MVP, run test and backup/restore evidence. Never publish employer posting API based on the draft alone.

**Acceptance test:** Release gated on real application smoke tests, security tests, real API response tests, source legal review, live cron and DB restore logs.

### High — 14 findings

#### H01. ATS integration mein external_id based reconciliation incomplete

**Category:** Functional API gap  
**Where:** `07 §6 (lines 66–90); 08 OpenAPI paths lines 18–149`  
**Evidence:** POST requires external_id, but GET/PATCH/close operate on internal job_id. There is no GET by external_id, upsert definition or guidance if an ATS loses the returned internal ID. Retrying same external_id with a NEW idempotency key has no unambiguous contract.

**Impact:** External ATS synchronisation may create conflicts or need an expensive full-list scan to find job_id.

**Required correction:** Define a clear 409 duplicate-and-lookup flow with GET ?external_id= or add PUT /jobs/by-external-id/{external_id}. Specify create vs update vs close semantics and retry recovery.

**Acceptance test:** Create twice with same/different keys; recover an existing job after losing local ID; close it using stable external_id.

#### H02. JobResponse insufficient for a real partner sync

**Category:** API completeness  
**Where:** `08 OpenAPI JobResponse lines 248–257; 07 §6 lines 66–90`  
**Evidence:** GET returns only id, external_id, status, public_url, created_at and optional updated_at, with no title, current apply_url, valid_through, eligibility or last moderation reason.

**Impact:** Partner cannot reconcile whether an externally managed job is current, corrected or about to expire.

**Required correction:** Introduce JobDetailResponse with source-safe employer-owned fields, current status, valid_through, last_verified_at, rejection_code and revision. Keep candidate PII absent.

**Acceptance test:** GET response contract matches stored owned job and includes current expiry; no other organisation data appears.

#### H03. 201 pending_review status promise schema mein locked nahi

**Category:** API contract inconsistency  
**Where:** `07 §6 lines 79–90; 08 OpenAPI POST lines 18–54, JobResponse lines 248–256`  
**Evidence:** Narrative explicitly says POST 201 is pending_review. The schema reuses broad JobStatus enum, which also accepts published, closed, rejected etc as a 201 response.

**Impact:** Generated client/test tooling cannot detect accidental auto-publication or incorrect first-create response.

**Required correction:** For POST 201 use a dedicated response status const=pending_review or clearly document conditional trust states if intentional. Add response examples.

**Acceptance test:** Contract test rejects POST 201 published for new unapproved employer.

#### H04. Publication consent and verification evidence not persisted in example DB

**Category:** Data protection / compliance gap  
**Where:** `07 §2 (line 27), §5 (lines 54–66); 08 JobCreate lines 179–219; 06 employer_jobs SQL lines 269–290`  
**Evidence:** API requires consent_to_publish=true and narrative says publish_consent, verification_status and source_policy_id per record. employer_jobs SQL only stores distribution_consent and moderation_status; no publication consent timestamp/version/actor or posting-authority evidence columns are shown.

**Impact:** Later disputes cannot be resolved with reliable proof of who authorised a listing and under which terms.

**Required correction:** Add versioned job publication consent + actor/time/evidence references and employer verification history; no sensitive identity scans unless necessary and lawful. Define retention/deletion.

**Acceptance test:** Audit entry and consent version are saved on create and remain traceable after close/delete.

#### H05. Remote vs relocation location semantics ambiguous

**Category:** Data/UX gap  
**Where:** `01 §2/§4.3, §4A; 07 §5 lines 54–60; 08 JobCreate lines 179–212`  
**Evidence:** API mandates country as a physical job country, even for fully worldwide-remote jobs; remote_eligible_countries is optional. Country=IN can be misread as located in India rather than candidates eligible from India.

**Impact:** Overseas/remote users may be incorrectly filtered or shown false eligibility/sponsorship.

**Required correction:** Separate employer_country, physical_job_country (nullable for remote), work_mode, candidate_eligible_countries and eligibility_unknown. For remote, define what worldwide and [] mean; do not infer India eligibility from country alone.

**Acceptance test:** Test worldwide, India-only, US-only remote, hybrid UAE and relocation Germany; labels and filters stay correct.

#### H06. API schema business validation underdefined

**Category:** Contract/validation gap  
**Where:** `07 §5 lines 54–65; 08 JobCreate/JobPatch lines 179–247`  
**Evidence:** 1–60 day expiry is prose only; max/min salary and currency can be supplied independently or in contradictory order; country regex accepts invalid codes; date-time comparison with now not expressible in basic schema. PATCH can clear required combinations.

**Impact:** Invalid compensation, expiry and geography may be accepted unless programmer invents validation rules.

**Required correction:** Write a deterministic validation specification with error codes and conditional rules. JSON Schema where possible; server checks for valid ISO country/currency, salary_min<=max, salary currency-period pairing, validThrough range, and PATCH resulting object validity.

**Acceptance test:** Table-driven positive/negative cases generate 422 errors with stable field paths and messages.

#### H07. Job state machine and concurrent edits not fully specified

**Category:** Lifecycle gap  
**Where:** `01 §4A lines 195–214; 07 §6/§8 lines 79–90,128–138; 06 employer_jobs moderation_status lines 269–291`  
**Evidence:** There is a status enum but no allowed transition matrix per role, revision/concurrency strategy, who can publish/reopen, whether a material edit unpublishes instantly, or whether an expired job can be extended after closure.

**Impact:** Race between edit, moderation and expiry cron can silently republish outdated jobs.

**Required correction:** Define actor/state transition table; optimistic revision or If-Match for updates; atomic publish/close; expiry priority; no implicit reopen or approvals.

**Acceptance test:** Concurrent PATCH vs CLOSE vs cron test; published job never reappears without a valid controlled transition.

#### H08. Recruiter analytics promised, underlying event model missing

**Category:** Feature/data mismatch  
**Where:** `01 §4A line 203; 07 §4 lines 39–52; 06 §9 SQL lines 235–311`  
**Evidence:** Recruiter dashboard promises views and outbound apply clicks, but sample tables contain only employer_audit_events (admin actions) and no privacy-conscious job-view/apply event aggregation schema, time-window definition or bot filtering.

**Impact:** Dashboard cannot truthfully show those metrics from the proposed database.

**Required correction:** Define aggregated daily job_metrics with counting policy, bot exclusion, privacy retention and no employee/candidate PII. Or remove analytics from pilot scope.

**Acceptance test:** Synthetic visits/clicks yield correct aggregate counters without personal identifiers or affiliate-click manipulation.

#### H09. Job freshness/expiry confidence has no quantified TTL policy

**Category:** Source reliability gap  
**Where:** `01 §§4.2–4.4 and §10.5 (lines 148–185,516–532); 06 §5 lines 176–200; 05 source matrix`  
**Evidence:** Docs say hide jobs if too stale, but no source-wise cutoff thresholds and UI difference between last imported, last provider checked and actually confirmed open. Jobicy 7-day publication window does not establish expiry.

**Impact:** Expired or unverified jobs may remain visible too long, or valid jobs may be wrongly deleted.

**Required correction:** For each feed specify verified-open TTL, unknown-state grace period, 410/404 semantics, link failures, result pagination completeness, provider outages and safe display fallback. Provide Last checked vs Open verified labels.

**Acceptance test:** Simulate no feed refresh for 1/3/7/14 days and closure results; expected visibility is deterministic.

#### H10. Idempotency retention & atomicity not specified

**Category:** Storage/API gap  
**Where:** `07 §6 lines 79–87; 06 posting_idempotency SQL lines 292–302; 08 POST contract lines 18–54`  
**Evidence:** Table stores payload_hash and response_json but no retention/cleanup policy, collision scope across routes, transaction boundary with job creation, nor behaviour after key expiry. external_id duplicates across retries remain ambiguous.

**Impact:** Retries around server crashes can result in mismatched job and idempotency ledger states.

**Required correction:** Store idempotency and job creation in one transaction; define key scope, 24h–7d retention based on real need, identical retries, changed payload 409 and clean-up job.

**Acceptance test:** Inject failure before/after commit; repeated same request creates exactly one employer job.

#### H11. UTC timestamps vs SQL DATETIME conversion lacks contract

**Category:** Time correctness  
**Where:** `07 §6 line 79; 08 timestamps lines 198–208, 248–257; 06 SQL DATETIME columns lines 269–310`  
**Evidence:** Public API expects RFC3339 UTC but MySQL examples use timezone-less DATETIME. No specification of input offsets, application DB timezone or DST conversion.

**Impact:** Jobs can expire early/late and jobs in other countries can display the wrong deadline.

**Required correction:** Normalize all API datetimes to UTC at write, configure DB session UTC, emit Z on read, store employer time-zone label separately if shown; cron operates UTC.

**Acceptance test:** Test 2026-12-15T23:59:59Z and +05:30 equivalent; same stored instant and expiration behaviour.

#### H12. Data deletion, retention and employer offboarding not complete

**Category:** Privacy/ops gap  
**Where:** `01 §10.3 lines 498–508; 06 §9 SQL; 07 §3–4`  
**Evidence:** The documentation calls for privacy and audit logs but does not define how verified companies delete accounts, how keys revoke automatically, what is kept after job deletion, or exact limits for logs, moderation reports and verification records.

**Impact:** Retention costs and privacy/compliance obligations can grow unnoticed.

**Required correction:** Write retention schedule per data class and org deletion/disable workflow; protect security evidence and remove public pages promptly; design privacy request handling.

**Acceptance test:** Deactivate org test removes all public jobs and tokens immediately and applies documented retention policy.

#### H13. Google SEO/indexing matrix for every job origin not an executable policy

**Category:** SEO/licensing gap  
**Where:** `01 §§4A,9,10; 05 policy matrix; 07 §9 lines 138–145`  
**Evidence:** There are several prose rules: imported thin jobs noindex, Himalayas no Google Jobs syndication, employer jobs conditionally eligible for JobPosting. The source matrix does not define a consolidated render/noindex/schema/sitemap/export decision table with exact precedence across all job origins.

**Impact:** One generic job template or sitemap export can violate provider terms or trigger Google JobPosting problems.

**Required correction:** Create machine-readable source and job-origin policy with explicit allow_render, allow_index, allow_jobposting_schema, allow_sitemap, allow_export, apply_link_mode. Deny by default, test every combination.

**Acceptance test:** Snapshot HTML tests confirm Himalayas never emits JobPosting, API exports never include provider records, and expired pages remove metadata. See official Google rules.

#### H14. ₹50K/month monetisation model ka measurable feasibility gate missing

**Category:** Business gap  
**Where:** `01 §8, §12–13, §19; 02 founder constraints; 03 Phase 2`  
**Evidence:** Blueprint includes ad revenue aspirations and KPIs but no concrete funnel model to decide whether AdSense vs affiliate has enough real audience, what acquisition effort is acceptable, or when to stop spending development time.

**Impact:** Solo founder can keep building features indefinitely with no evidence of possible earnings.

**Required correction:** Add monthly pageview×actual RPM scenarios, traffic source mix, Search Console baselines, ad approval state, affiliate program acceptance and weekly review effort. Set explicit continue/pivot criteria after 60/90 days without promising earnings.

**Acceptance test:** Dashboard demonstrates real traffic, page RPM, revenue and operator hours; hypothetical values visibly separated.

### Medium — 8 findings

#### M01. Phase 2B/3 ordering differs across roadmap files

**Category:** Editorial execution ambiguity  
**Where:** `01 §13 lines 589–623; 03 milestone lines 49–83`  
**Evidence:** Blueprint orders Phase 2B before Phase 3, but milestone document lists Phase 3 before Phase 2B. Both describe optional gating, so this is sequencing ambiguity rather than factual conflict.

**Impact:** AI agent may implement features in unintended order.

**Required correction:** Use one dependency graph: core Phase0→1A/1B→2; optional branch 2B→3B; utility branch Phase3 independent. Align headings across every file.

**Acceptance test:** One canonical milestone dependency table; no contradictory ordered lists.

#### M02. Planned original guides and country content are not actually authored

**Category:** Content completeness  
**Where:** `01 §§6,9,13 (lines 363–376,427–461,580–596)`  
**Evidence:** Guide templates, source policy and topic outlines exist but not the five reviewed full articles/country notes needed for a public launch.

**Impact:** Product could become only thin imported job listings and struggle with user value/ads approval.

**Required correction:** Create separate reviewed content inventory with owner, official links, fact-check date, source excerpt, next review date and published draft. Do not mass-generate unverified content.

**Acceptance test:** At least 5 actual reviewed guides complete prelaunch, with substantive user utility.

#### M03. Tool functional examples and expected results are not provided

**Category:** QA precision  
**Where:** `01 T01–T10 (lines 243–357); 04 tools QA lines 38–52`  
**Evidence:** Tool inputs/outputs are described, but there are no executable golden fixtures for currency rounding, savings after deductions, offer comparison, DST, CSV import, PDF print, date edge cases.

**Impact:** Coding agents may implement plausible but inconsistent formulas.

**Required correction:** Add fixtures with inputs, numeric expected values and rounding; cross-tool financial terms and time zone semantics; international number/currency formats.

**Acceptance test:** Each calculator has automated examples; export/import and DST transitions pass.

#### M04. Documented accessibility and performance targets lack actual test harness

**Category:** Test implementation gap  
**Where:** `01 §10.4 and §15; 03 Gate 1B; 04 SEO/ads checklist`  
**Evidence:** Performance goals and keyboard navigation appear, but no concrete Lighthouse/axe/manual browser matrix or mobile test baseline is shipped.

**Impact:** Agent may mark accessibility done without evidence.

**Required correction:** Define repeatable Lighthouse CI or local browser run, WCAG-focused keyboard audit, screen reader checks, tested devices, failure thresholds and artifacts.

**Acceptance test:** Test output files generated and reviewed, not only unchecked text checklist.

#### M05. OpenAPI has no realistic examples, SDK/retry policy or changelog mapping

**Category:** Developer experience gap  
**Where:** `08 OpenAPI 283 lines; 07 §7 example; 09 changelog`  
**Evidence:** One CURL request and generic response shown, but no sample GET/list/PATCH/close, pagination cursor lifecycle, 409/422/429 error examples, API deprecation or backward compatibility rules.

**Impact:** Third-party ATS implementers must guess error recovery.

**Required correction:** Add contract examples per operation, partner onboarding checklist, test-mode sample keys (never real), error taxonomy and API version/release policy.

**Acceptance test:** Independent integration test client completes create→read→patch→close and handles errors.

#### M06. Site/company profile promise lacks a public profile storage contract

**Category:** Feature completeness  
**Where:** `01 §4A line 203; 07 §4 routes lines 39–52; 06 organizations SQL lines 235–245`  
**Evidence:** Company profile page is promised, but organization SQL offers only name/domain/verification state with no public slug, description, logo link permissions, listing page route or verification disclosure.

**Impact:** Recruiter/company profile may be stubbed or inaccessible.

**Required correction:** Either explicitly defer profiles or define public org slug, approved display name, trusted business URL, public job count, branding constraints and visibility rules.

**Acceptance test:** Published org page shows only approved fields and its own active jobs.

#### M07. Overseas branding vs remote-only initial inventory needs stronger page messaging

**Category:** Product positioning gap  
**Where:** `01 §2, §4.1; 00 README scope; 05 policy matrix`  
**Evidence:** The main feed sources largely cover remote jobs. Website domain implies overseas employment/relocation; documents warn against conflation but give no separate acceptance/test criteria for candidate expectations.

**Impact:** Users may expect visa-sponsored jobs and feel misled.

**Required correction:** Label primary categories exactly: Remote work available from India, Worldwide remote, Relocation/On-site (only when verified). No default or fabricated sponsorship badge.

**Acceptance test:** Usability test asks 5 visitors to distinguish remote from relocation and unknown eligibility correctly.

#### M08. Complete user support/reporting workflow is only described at headline level

**Category:** Operational completeness  
**Where:** `01 §§6,10.2,11; 04 QA; 07 §8`  
**Evidence:** Report-job form, abuse complaint queue, automatic quarantine and error summary are mentioned, but no stored schema for reports/retention, escalation path, response template, false-positive recovery or audit disposition is delivered.

**Impact:** Bad listings may remain active or valid jobs be suspended without appeal policy.

**Required correction:** Define report categories, rate limits, safe evidence handling, triage thresholds, retention and reporting disclosure. For MVP, a minimal low-volume channel can suffice.

**Acceptance test:** Report a phishing job→hide/quarantine where justified→owner resolves or rejects with audit trace.

### Low — 3 findings

#### L01. Duplicate sentences in the main blueprint

**Category:** Editorial duplicate  
**Where:** `01 §10.2 lines 494 and 496`  
**Evidence:** Two consecutive paragraphs both say no accounts table is needed in first MVP.

**Impact:** Harmless but redundant.

**Required correction:** Merge into one paragraph that distinguishes candidate no-login from future recruiter accounts.

**Acceptance test:** One canonical clear statement remains.

#### L02. Word + Markdown aliases are byte-identical copies

**Category:** Intentional duplicate / naming hygiene  
**Where:** `Root /OverseasJob_Complete_Blueprint.docx vs /OverseasJob_Complete_Blueprint_v1.1.docx; root Markdown vs 01_COMPLETE_PROJECT_BLUEPRINT.md`  
**Evidence:** SHA-256 comparison confirms Word variants equal, Markdown variants equal and ZIP content matches folder. This is packaging duplication, not contradictory text.

**Impact:** Founder may hand different filenames to agents and later edit only one copy.

**Required correction:** Keep one canonical editable source and generate a versioned export on release; document the other file as an alias or remove duplicates in future pack.

**Acceptance test:** Build script regenerates ZIP and Word from canonical Markdown; hashes recorded.

#### L03. Typo in proposed repository directory name

**Category:** Editorial error  
**Where:** `06 §2 line 33`  
**Evidence:** Suggested structure starts with `overeseasjob/` and comment asks to rename to `overseasjob`.

**Impact:** Copy-paste scaffolding could start with wrong folder name.

**Required correction:** Correct top folder to `overseasjob/` once and remove corrective comment.

**Acceptance test:** Scaffold root consistently named overseasjob.

## 2. Conflict/duplicate classification

| Item | Finding | Classification |
|---|---|---|
| Recruiter record mandatory `origin_type`/`publish_consent` vs split example SQL | C01/C04 | **Substantive schema mismatch** |
| `201 pending_review` narration vs wide JobStatus schema | H03 | **Contract under-specification** |
| Recruiter analytics promised vs no metrics table | H08 | **Missing implementation specification** |
| Phase 2B placed before Phase 3 in blueprint, after Phase 3 in milestone document | M01 | **Order ambiguity**; not a security flaw |
| No accounts table statement repeated twice | L01 | **Editorial duplicate** |
| Root Word and Markdown copies | L02 | **Intentional byte-identical duplicates**; no conflicting content |
| v1.1 product documents vs API v1.0.0-draft | — | **Not a version conflict**: document and API version are separate; document this explicitly |
| Database SQL and endpoints described as examples, not deployed | C05 | **Deliberate scope, not hidden implementation completion** |


## 3. Recommended fix sequence — maintain zero new paid API cost

**Release Gate A — Anonymous job-tools MVP (first):** verify actual Hostinger runtime and backups; current Jobicy/Himalayas permissions; release source-policy-aware sync and externally linked job search; launch 3 finished calculators plus 5 human-reviewed guides; verify original user value, noindex/source attribution, accessibility and failure-safe cron. **No recruiter accounts or API required.**

**Release Gate B — Recruiter pilot (only if feasible):** resolve C01–C04, H04–H08, H11–H13 and M06/M08 before enabling it; limit initial employer pilot, verify identities, measure moderation queue, add logout/recovery and evidence retention; disable if maintenance exceeds founder capacity.

**Release Gate C — ATS posting API:** resolve H01–H03, H06–H07, H10 plus complete auth and independent contract tests. Inbound-only; no redistribution of restricted third-party feed jobs.

**Business Gate D — monetisation:** calculate actual pageview × actual RPM; apply for AdSense only after sufficient original content; test partner affiliate income only after explicit approval; stop features that add maintenance without measured user value.


## 4. Documents to add or change (proposed, not performed)

| Proposed artifact | Contents | Owner/gate |
|---|---|---|
| `10_CANONICAL_JOB_MODEL_AND_RIGHTS.md` | Cross-origin DTO, source rights policy, status mapping and search/sitemap/export policy | Before core model merged with employers |
| `11_RECRUITER_AUTH_AND_TRUST_ADR.md` | Login, verification, email/recovery, RBAC and suspicious job review | Before Phase 2B |
| `12_API_BEHAVIOUR_AND_ERROR_CASES.md` | External ID reconciliation, idempotency, concurrency, 409/422/429, examples | Before Phase 3B |
| `13_DATA_PRIVACY_RETENTION.md` | Consent version, source-of-authority proof, audit retention and offboarding | Before Phase 2B |
| `14_TEST_FIXTURES_AND_CONTRACT_TESTS/` | Valid/invalid API JSON, lifecycle tests, calculator golden data, source-rights snapshots | Before phase deployments |
| `15_MONETISATION_VALIDATION.md` | Real AdSense RPM/pageview scenarios, target metrics, cost and stop/go rules | Before heavy feature work |
| `16_OPERATIONS_RUNBOOK.md` | Cron failures, scams, disable switch, backup restore, weekly founder review | Before launch |


## 5. Fix-priority matrix for the founder

| Requirement | Can launch now from docs alone? | Next decision |
|---|---|---|
| Public job search via permitted feeds | No implementation yet | Agent Phase 0 then Phase 1 |
| 3 free browser-side tools | No implementation yet | Define golden fixtures, then implement |
| Remaining 7 tools + daily game | Not needed for MVP | Only after usage feedback |
| Recruiter self-serve posting | **Not safe to enable yet** | Resolve C01–C04 and high trust gaps |
| Partner job posting API | **Not safe to enable yet** | Resolve contract and identity gaps |
| Affiliate income | Not assured | Partner approval, actual eligible traffic |
| ₹50k/month ads | Not assured | Real analytics and AdSense approval |


## 6. Official verification references (source terms can change)

- Jobicy public jobs API: https://jobicy.com/jobs-rss-feed — commercial job board use allowed with original Jobicy credit and public API links.
- Himalayas public API: https://himalayas.app/api — job board display allowed with unchanged `applicationLink` and source attribution; **no onward syndication/Google Jobs**.
- Google JobPosting: https://developers.google.com/search/docs/appearance/structured-data/job-posting — real job, apply and expiry policies; markup only on eligible individual jobs.
- OWASP API Security Top 10: https://api-security.owasp.org/editions/2023/en/0x00-header/ — object-level authorization, resource consumption and SSRF considerations.

This report is a static audit of the provided planning documents; no live services were accessed from the user's accounts. Revalidate provider terms before implementation.


## 7. Final verdict

**Keep the current business strategy. Fix the specification before the recruiter/API branch.** A small automated job discovery + real career utility MVP fits the solo-founder, ₹0-new-subscription constraint. Direct employer job posting and inbound API may be valuable later, but they introduce ongoing trust/moderation work and are **not** zero-maintenance features. Avoid spending effort on a large recruiter integration before real candidate traffic and a small verified pilot. The next safe engineering action is still Phase 0, with a documentation-remediation branch for the high-risk modules.


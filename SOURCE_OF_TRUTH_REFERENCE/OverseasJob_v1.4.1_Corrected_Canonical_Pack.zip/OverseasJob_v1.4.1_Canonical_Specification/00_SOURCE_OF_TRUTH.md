# OVERSEASJOB.IN — SOURCE OF TRUTH & AUTHORITY REGISTER

**Release:** v1.4.1 (authority reconciliation, deterministic fixtures and release audit)  
**Date:** 23 November 2026  
**Status:** CANONICAL DOCUMENTATION; NOT A WORKING OR DEPLOYED PRODUCT  
**Scope:** The complete OverseasJob.in product, modules M00–M17, utilities T01–T10, optional Recruiter Lite and inbound Partner API.

## 1. What is the single source of truth?

**The canonical source of truth is THIS VERSIONED PROJECT PACK, not any one Word document.**
This file is its **authority/index**, not a replacement specification. The requirement owner for each topic is shown below. Do not duplicate detailed business logic, types, formulas or request schemas here.

**Canonical editable location:** the Markdown, YAML, JSON, CSV, SQL and validation files inside this package.
**Human-readable exports:** `OverseasJob_Complete_Blueprint_v1.4.1.docx` and root Markdown copies are snapshots. If an export differs from the canonical files, the canonical files win. Regenerate exports after changes; do not separately edit their content.
**Prior releases:** Any v1.1/v1.2 ZIPs, Word files and `90_`–`92_` audit archives are historical evidence, NOT current implementation commands.

## 2. Exact authority map (one owner per type of requirement)

| Domain / decision | Normative authority | Supporting references (not overriding) |
|---|---|---|
| Business purpose, target audience, boundaries, monetisation intent | `01_COMPLETE_PROJECT_BLUEPRINT.md` | `10_DECISION_COMPANION_PRODUCT_SPEC.md` |
| All modules M00–M17, release gate, workflows, UI states, acceptance meaning | `15_CANONICAL_MODULE_REQUIREMENTS.md` | `01_*`, `03_MILESTONE_TASKS.md`, `04_QA_AND_LAUNCH_CHECKLIST.md` |
| JobView, eligibility, source provenance, date semantics, job state and automation lifecycle | `16_DATA_AND_OPERATIONS_CONTRACT.md` | `06_ARCHITECTURE_AND_DATABASE.md`, `10_*` |
| Free career utilities T01–T10: calculations, input validation, fixtures | `17_TOOL_ALGORITHMS_AND_FIXTURES.md` | `18_TEST_FIXTURES.json`, `15_*` |
| Inbound employer/ATS HTTP field names, types, paths, status codes | `08_PARTNER_JOB_POSTING_API_OPENAPI.yaml` | `07_RECRUITER_LITE_AND_PARTNER_API.md` |
| Database physical table/column/index reference | `24_DATABASE_SCHEMA_REFERENCE.sql` | `16_*` determines the required data semantics; implement DB changes so the two agree |
| Recruiter verification, posting workflow, employer trust and operational gates | `07_RECRUITER_LITE_AND_PARTNER_API.md` | `15_*`, `08_*`, `16_*` |
| Provider-specific licences, attribution, indexing/export/JobPosting restrictions | `05_SOURCE_POLICY_MATRIX.csv` together with `16_*` | The **actual current written provider terms/permissions** override every local summary |
| Privacy, user consent and security rules | `15_*`, `16_*`, `07_*` as applicable | Applicable law overrides any incorrect or obsolete local instruction |
| Technical stack and hosting adaptation | `06_ARCHITECTURE_AND_DATABASE.md` | Actual verified hosting capabilities and zero-new-paid-cost constraint |
| Opportunity Guardian, Job Decision Cards, no-login Radar | `15_*`, `16_*` | `10_DECISION_COMPANION_PRODUCT_SPEC.md` for supplemental UX detail |
| Autonomous AI-agent delivery and boundaries | `19_AGENT_AUTONOMY_AND_DELIVERY.md` | `02_AI_AGENT_MASTER_PROMPT.md` |
| Phase ordering, work packages | `03_MILESTONE_TASKS.md` | Gate ownership in `15_*` is definitive |
| Required QA, reproducible contract checks and verification claims | `04_QA_AND_LAUNCH_CHECKLIST.md`, `18_TEST_FIXTURES.json`, `23_VALIDATE_SPEC.py` | `20_VERIFICATION_LEDGER.md` records evidence, not unrun claims |
| What has actually been checked vs only documented | `20_VERIFICATION_LEDGER.md` | Real implementation test logs and deployed module status, once available |

**Safety and factual truth trump document order:** Applicable law, explicitly authorised source rights, actual provider API contract/response and verified infrastructure facts are not optional assumptions. If they conflict with written plans, preserve the safer truthful behaviour and reconcile documentation and tests. Never invent employer verification, sponsorship, job inventory, affiliate payments or advertising approval.

## 3. Conflict-resolution procedure for an autonomous coding agent

1. Locate the owner file in the table above; follow its contract instead of older descriptive examples.
2. Verify external facts against source terms and real APIs before enabling that integration.
3. If two *current* authorities conflict: reproduce with the smallest relevant test; apply the most restrictive **non-fabricating, privacy-preserving** interpretation temporarily; update both authoritative files, tests and changelog to one consistent decision.
4. If the conflict changes a genuine **business choice** (pricing, whether to act as a recruitment agent, legal representation, making a paid commitment) and there is no documented answer, keep only the affected feature **not live**. Continue other fully specified work autonomously.
5. Never treat a passing documentation validator as proof of deployed code, legal compliance, live employers or revenue.

Examples:
- Unconfirmed India eligibility → show `unknown`; not “India eligible.”
- Provider job disappears from seven-day discovery feed → **not** automatically `closed`.
- Source forbids downstream redistribution → exclude the imported records from partner APIs/exports.
- Recruiter claims verification without evidence → posting remains held; no verified badge.
- One API sample contradicts OpenAPI → fix sample to conform to `08_*`; do not silently change the API interface.

## 4. Mandatory machine-checkable module register

The platform is specified through **18 modules M00–M17** in `15_*`; utilities T01–T10 belong to M05. Each implementation must maintain `module_status.json` with `module_id`, `spec_version`, `implementation_status`, `tests`, `routes`, `dependencies`, `evidence_paths`, `blocker_reason`, and `last_verified_at`.

Allowed statuses: `specified`, `implemented`, `tested`, `deployed`, `blocked_with_reason`. Do not mark work `tested` or `deployed` on the strength of documentation alone. Future-gated Recruiter Lite and API modules still belong to the module inventory; **specified is not live**.

## 5. Agent autonomy: FULL ACCESS, NO TECHNICAL MICRO-APPROVALS

The authorised AI coding agent may inspect hosting, choose implementation details within written constraints, create/edit code, install free dependencies, migrate with backups, test, repair, deploy and roll back through the existing authorised environment. The founder is not required to review code, YAML, SQL or approve each technical operation. Record decisions and produce a plain-language report. Never create an unapproved paid recurring commitment, destroy unrelated projects, breach third-party rights or fabricate legal/job claims.

## 6. Change management — keep one truth

1. Modify the **owner contract** first; revise dependent examples, fixtures, SQL and tests.
2. Change module IDs/status only if the actual scope changes; preserve existing identifiers.
3. For any normative behaviour/interface change, update `09_CHANGELOG.md` and bump release version; for a governance-only edit, patch version is enough.
4. Run `python 23_VALIDATE_SPEC.py` from this folder; add tests for new claims; preserve failed cases until fixed.
5. Regenerate `13_RELEASE_MANIFEST.json` with SHA-256 of canonical files, and generate new export ZIP/documents. Never independently edit an old export and call it authoritative.
6. Record real test evidence in `20_VERIFICATION_LEDGER.md` and the implemented project's test reports. Keep historical audits archived, not competing instructions.
7. If a file only repeats rules already owned elsewhere, replace duplicated normative prose with a reference to its owner.

## 7. Release truth boundary

This v1.4.1 package reconciles binding specifications, agent instructions and automated document checks; it is not an implementation. It does **not** change jobs, tools, employer/API business scope, add live features, verify job supply, prove hosting support, or guarantee AdSense/affiliate revenue. The actual code, deployment, external integrations and monitoring require independent evidence. The source-of-truth pack is the contract used to build and test them.

**Read order:** `00_SOURCE_OF_TRUTH.md` → `00_READ_ME_FIRST.md` → `01_*` → `15_*` → `16_*` → `17_*` → relevant owner contract → `19_*` → fixtures/validator → verification ledger.

## v1.4.1 current external API correctness override

When a local provider contract contradicts the provider's currently published OpenAPI, treat official provider specs as external authority. For Himalayas browse use offset/limit/totalCount, UTC offset strings, country objects, pubDate publication milliseconds, and **no invented per-job status route**. For Jobicy use the current documented count-limited latest API; do not assume cursor pagination or 7-day guarantees. See `16_DATA_AND_OPERATIONS_CONTRACT.md` and `27_GITHUB_IMPLEMENTATION_RECONCILIATION.md`.

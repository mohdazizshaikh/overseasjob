# OverseasJob.in — Canonical AI-agent Project Pack v1.4.1.1

**Prepared:** 23 November 2026  
**State:** DOCUMENTATION / IMPLEMENTATION SPECIFICATION ONLY. No working product or deployment is asserted.

## Start in this order

0. `00_SOURCE_OF_TRUTH.md` — the canonical authority map, conflict rules and agent autonomy.
1. `01_COMPLETE_PROJECT_BLUEPRINT.md` — business purpose, user promises and scope.
2. `15_CANONICAL_MODULE_REQUIREMENTS.md` — every module, complete user workflows, edge cases and release gates.
3. `16_DATA_AND_OPERATIONS_CONTRACT.md` — provenance, legal/source rules, matching, status, automation, recovery.
4. `17_TOOL_ALGORITHMS_AND_FIXTURES.md` — deterministic formula/validation/test cases for ten utilities.
5. `08_PARTNER_JOB_POSTING_API_OPENAPI.yaml` — canonical inbound partner HTTP contract; **not yet deployed**.
6. `07_RECRUITER_LITE_AND_PARTNER_API.md` — recruiter workflow, trust and API restrictions.
7. `18_TEST_FIXTURES.json`, `23_VALIDATE_SPEC.py` and `24_DATABASE_SCHEMA_REFERENCE.sql` — executable document/contract tests.
8. `19_AGENT_AUTONOMY_AND_DELIVERY.md` — full-access agent authority, autonomous workflow and evidence-based final handoff.
9. `20_VERIFICATION_LEDGER.md` — honest statement of what was checked and still needs live evidence.
10. `02_AI_AGENT_MASTER_PROMPT.md`, `03_MILESTONE_TASKS.md`, `04_QA_AND_LAUNCH_CHECKLIST.md`, `05_SOURCE_POLICY_MATRIX.csv`, `06_ARCHITECTURE_AND_DATABASE.md`, `10_DECISION_COMPANION_PRODUCT_SPEC.md` — detailed supporting context.
11. `90_HISTORICAL_V11_AUDIT_ARCHIVE.md`, `91_HISTORICAL_V12_TRACEABILITY.md`, and `92_HISTORICAL_V12_GAP_REVIEW.md` — historical only; **not current instructions**.

**Precedence:** See `00_SOURCE_OF_TRUTH.md` for the full authority matrix. Partner HTTP request/response shape: OpenAPI > other prose. User/business behaviour: `15_*` > historical prose. Source status, eligibility, operations: `16_*`. Tool mathematics: `17_*`. Historical audits are evidence, not build instructions. If a contradiction exists, repair current documents/tests automatically and log it; no silent invention.

## What the founder authorises

The founder is nontechnical and gives the coding agent full technical access to existing authorised infrastructure. Do not demand approval for each command, file edit, technical choice or normal deployment step. Be self-directed: inspect → implement → test → fix → deploy safely if environment authorises → verify → document. Make backups and use rollback. Do not incur new paid commitments, misrepresent live features, enable unsafe public recruiter onboarding, or violate third-party licences. For unknown external credentials, law, terms or hosting limits, record a precise blocker and complete independent work.

## Product promise

Remote work and overseas career *decision support* for India-based users, with source-backed job discovery, honest eligibility, Job Decision Cards, no-login Opportunity Radar, 10 genuinely functioning free utilities, original guidance and optional simple Daily Arena. Recruiter Lite / inbound API are designed but gated; candidate ATS, placement service, auto-apply and resyndication of imported jobs are excluded.

## Execution

Run `python 23_VALIDATE_SPEC.py` before code generation and after any contract edit. Create test evidence from **actual implementation**, not merely from documents. Deploy no paid external systems. Core gate order: source-coverage proof → source-backed jobs/Decision Cards/first 3 tools → local Radar/tracker → remaining utilities/game → recruiter pilot/partner API only if safety and capacity allow. The agent can progress autonomously through stages if automated gates pass, without asking for a technical review from the non-developer founder.

## Release artifacts and truthful status

`module_status.json` starts at `specified` for all 18 modules. This is a documentation package, not source code, a deployment, a live API connection or a 14-day supply audit. `21_FOUNDER_HANDOFF.md` states what an authorised coding agent must verify next. `25_DOCUMENT_AUDIT.md` records this release's corrections and external blockers. `13_RELEASE_MANIFEST.json` hashes the editable canonical documents and tests. Never claim a verified production result from a sample or contract check.

## Critical v1.4.1 correction and existing repository

A functioning *development repository* was discovered at `https://github.com/mohdazizshaikh/overseasjob`; never replace its code with this spec-only pack. The v1.4 source-specific pagination, timezone, location and `pubDate` assumptions were corrected here against the provider OpenAPI. Read `27_GITHUB_IMPLEMENTATION_RECONCILIATION.md` and run targeted tests against the existing repo before merging documentation. Hostinger deployment and live provider activation remain separate blocked work.

# OverseasJob.in — Founder handoff (v1.4.1, 23 November 2026)

## What is ready now

A single editable source-of-truth pack with 18 mapped platform modules M00–M17, 10 tool contracts, partner API OpenAPI, database reference, job licensing restrictions, full-access coding-agent operating rules, improved test fixtures, canonical authority register, and SHA-256 release manifest. Documentation is not a completed working application.

## What is NOT ready / must not be represented as live

Read-only inspection located https://github.com/mohdazizshaikh/overseasjob containing an existing PHP application and development tests, but we did not execute its code locally; no hosting connection/configuration, HTTPS, live database migration, 14-day job supply study, paid feature, verified recruiter organisation, live APIs, public guides, resume layouts, daily puzzle bank, app-level security testing, AdSense permission, backup restore rehearsal, or production deployment has been evidenced. Do not claim these happened.

## Exact next safe handoff to an AI coding agent

1. Unzip canonical v1.4.1 pack; start from `00_SOURCE_OF_TRUTH.md`, then `00_READ_ME_FIRST.md`. Do not treat the Word export as a more authoritative file.
2. Start by preserving and testing the discovered `mohdazizshaikh/overseasjob` main branch, then inspect the authorised Hostinger environment. **Do not overwrite the working repository with a specification ZIP.** Back up before changing anything; do not touch other hosted websites.
3. Run `python 23_VALIDATE_SPEC.py` and inspect the report. Carry out Gate 0 source licence checks and 14 days of real permitted source sampling (never fabricate a historical dataset).
4. Implement Gate 1 with working code, end-to-end tests, reviewed original content, consent/privacy, verified source links and safe rollback. Continue independently to Gate 2/3 features while holding unsafe modules off; no founder code approvals per command.
5. Keep Recruiter Lite, inbound partner API and ads disabled until *their own* legal/trust/security/approval gates are actually met.
6. Replace the starter `module_status.json` with genuine `implemented/tested/deployed/blocked_with_reason` evidence from the real repo. Deliver a short plain-language report with active URLs, tests, risks, blockers, extra recurring spend (must remain ₹0 without owner approval), and restore steps.

## External inputs that cannot be created by documentation

Existing hosting/repository access and plan limits; actual permitted job feeds and measured eligible roles; business/legal review for overseas recruiting and employer identity; reviewed factual country guidance; any AdSense or affiliate approval. Business/product design is already specified. The agent must proceed without requiring the nontechnical founder to review code, but must never invent the external facts.

## Immediate priority after this source check

The existing repository has later corrected Himalayas pagination/pubDate semantics than the earlier v1.4 ZIP, but some timezone/location fixture assumptions differ from official provider OpenAPI. Run targeted tests against OpenAPI-format fixtures before enabling live API; do not regress offset+limit or invent a 410 status route. See `27_GITHUB_IMPLEMENTATION_RECONCILIATION.md`. No GitHub code or Hostinger production change is implied by this ZIP.

# v1.4.1 Canonical Data, Provider and Automation Contract

## Source-isolation rules (hard constraints)

Each job holds `origin` (`provider` or `direct_employer`), `provider`, `provider_job_id` OR `owner_org_id`+`external_id`, immutable original source URL, canonical application URL, independent provider policy ID, content-use rights, source attribution, imported/updated/first_seen/verified times, eligibility evidence and status. Never merge two sources into one attribution record. Cross-provider duplicates may display one group with both retained URLs/rights. No partner API, CSV export or public developer endpoint may return third-party imported job records unless explicit source licence permits; default deny.

## Canonical JobView — exact field types

`id: opaque string`, `origin: enum(provider,direct_employer)`, `source_name: nonempty string`, `source_url: HTTPS`, `apply_url: HTTPS`, `title: string`, `company_name: string|null`, `work_mode: remote|hybrid|onsite|unknown`, `work_country: ISO2|null`, `employer_country: ISO2|null`, `eligible_from_in: allowed|not_allowed|unknown`, `eligibility_evidence: [{provider_field, fact, observed_at}]`, `time_zone_eligibility: allowed|not_allowed|unknown`, `visa_sponsorship: yes|no|unknown`, `salary_min/max: decimal|null`, `salary_currency: ISO3|null`, `salary_period: hour|day|week|fortnight|month|year|null`, `source_published_at: UTC|null`, `source_updated_at: UTC|null`, `first_seen_at: UTC`, `last_seen_at: UTC`, `last_verified_at: UTC|null`, `valid_through: UTC|null`, `availability: active|closed|stale|unknown`, `display_status: visible|hidden|held`, `rights: {attribution_required,allow_jobposting_schema,allow_resyndication}`, `reason_tags: string[]`. Source-specific fields/metadata stored separately, never invented.

**Timestamp invariants:** UTC ISO 8601 on API/JSON; SQL UTC `DATETIME` with known conversion; explicit `unknown` is not Unix epoch. `source_published_at` never silently set to first seen, source updated, or ingestion time. `new_since_last_visit` uses local first seen relative to browser last-view, not source posting date.

**Origin/status mapping:** Provider imported record = API provider ID + provider lifecycle state; direct employer record = verified org ID + posting review state. A public projection has `visible` only if rights permit, no trust hold, and either active provider evidence or approved nonexpired direct posting. For Himalayas, there is no documented public per-job status/410 endpoint: never call an invented per-job URL. Use the official browse/search responses and documented `expiryDate` conservatively; 429/5xx/partial retrieval retain the last known-good cache subject to freshness. An absent job alone is not an authoritative closure signal. It is **not automatically closed** simply because it is absent from discovery results. For direct employer, `pending_review`, `rejected`, `suspended`, `closed`, `expired` are hidden regardless of previously published status. All status transitions audited.

## Source-specific adapter mapping

### Himalayas JSON API

**Official authority:** https://himalayas.app/docs/openapi.json (OpenAPI 3.1, checked 2026-11-23), together with https://himalayas.app/docs/remote-jobs-api and https://himalayas.app/api. The provider's current contract overrides conflicting earlier v1.4 prose. Recheck before enabling live integration.

- **Exactly two documented public JSON endpoints:** `GET /jobs/api` and `GET /jobs/api/search`. The browse endpoint pages by `offset` (starting 0), `limit` (maximum 20), and the response `totalCount`, `jobs`. There is **no documented `nextCursor`**. Search uses `page` and filters; do not conflate the two.
- `guid` is an opaque ID, not necessarily a job URL. Preserve `guid` and a stable internal route key; **do not invent** a per-job Himalayas link. Display visible Himalayas credit with an actual known Himalayas destination. Preserve the exact provider-supplied HTTPS `applicationLink`, which may point to an employer/ATS site. Keep source attribution separate from Apply.
- `locationRestrictions`: **array of objects** with `alpha2`, `name`, `slug`; empty `[]` means worldwide geographic coverage. Validate `alpha2` against real ISO alpha-2 membership. Missing/null/malformed yields `unknown`. Do not mistake string-only legacy fixtures for current officially specified job response objects.
- `timezoneRestrictions`: **array of strings** such as `UTC-5`, `UTC+5:30`; empty `[]` means no timezone restriction. Parse explicit UTC signs/offsets and compare to India's UTC+05:30; missing/null/malformed values are `unknown`. Bare numeric `5.5` is **not** a valid current OpenAPI JSON field value. A timezone or geographic exclusion yields `not_allowed`; both evidenced permissions yield `allowed`; otherwise `unknown`.
- `pubDate` is **publication time in Unix milliseconds** and maps to `source_published_at` after UTC conversion, not `source_updated_at`. `expiryDate` is expiration time in Unix milliseconds. Response-level `updatedAt` is feed refresh metadata and is not a per-job update timestamp. Never fabricate original publication or a job update from ingestion time.
- There is **no documented per-job REST status URL**, nor an official 410/404 job status protocol in these public docs. Do not call one or treat simulated 410 tests as real endpoint evidence. A completed feed and documented expiry help assess freshness; partial traversal, provider error or absence alone must not mass-close jobs. If conservative freshness fails, hide with an honest stale/unknown label, without falsely marking employer closure.
- Data is cached/refreshed approximately daily according to public documentation. Respect 429 and backoff. Use backend-only requests, no client direct API, no unapproved redistribution or Google JobPosting markup. A policy-disabled provider remains disabled until actual rights/host/response checks pass.

### Jobicy public feed

Official docs: https://jobicy.com/jobs-rss-feed (reviewed 2026-11-22; verify relevant commercial and attribution terms on activation).

- Free JSON endpoint returns latest available matches (bounded to at most 100 per call according to current public docs); it is **not** an authoritative all-active-job index, and its current docs do not guarantee a universal seven-day window. Disappearance from its results alone ≠ closure. Preserve canonical Jobicy/source URL and required credit; do not redirect to arbitrary employer ATS links not licensed by provider.
- Map genuine source publish/updated time when explicitly documented; otherwise keep unknown. Source status check only if an authorised endpoint is available; never aggressive scrape third-party destination to prove closure.
- Do not invent affiliate click earnings for these jobs. A separate approved tracked employer-purchase referral program, if any, has independent conditions.

## Safe ingestion transaction

1. Cron lock ensures one provider job at a time; begin `sync_run`. Fetch using server-side requests and active provider policy version; enforce timeout/size/SSL; no source callback injection or arbitrary URL.
2. Validate raw response shape against versioned fixture. Normalise without inventing fields. Scrub HTML. Restrict outbound URLs to provider-specified links. Record source snapshot metadata and source policy ID.
3. Upsert idempotently on `(provider_id,provider_job_id)` only; duplicate grouped at display, not destructive data merger. Mark seen IDs within completed traversal.
4. Only after complete successful traversal evaluate possible missing jobs; absence from Jobicy time-bounded feed is never an automatic close. Authoritative expiry or provider-specific status closes; otherwise mark freshness uncertain and hide when stale threshold reached.
5. Commit transaction and sync_run health. 429/5xx/partial traversal → no deletion and no reset of last-known-good; log error and retry with bounded exponential backoff. Provider policy uncertainty → disable further public use safely.

## Freshness thresholds (project defaults; not upstream guarantees)

- Visible imported job requires successful provider status confirmation where available or a completed recent feed reference under per-source policy. In unverified state use warning rather than claiming “active”. If older than **72h since last successful source verification**, hide by default unless provider-specific documented evidence supports longer; configurable per provider and monitor false removals. Closed/expired authoritative record is hidden immediately. **TTL is an internal conservative safety setting, not proof of vacancy status.**
- Direct employer jobs expire at `valid_through`; notify org beforehand only if approved email delivery exists; no silent extension. Sponsor/eligibility changes must trigger review and revision increment.
- `source_terms_checked_at` more than 30 days old or provider terms materially changed → warn operator, disable affected integration if rights are uncertain. Manual-assisted legal review is honestly not automatic.

## Local browser profile & Radar (no backend-user illusion)

`profile_schema_version=1`, roles[], work_path enum, countries[], last_view_at, seen map, saved jobs, applications, followups, consent settings. Store locally only and validate imported JSON schema with caps (max 2000 saved jobs / 1000 applications and 1 MiB import by default). Use origin-qualified stable job key `provider:<slug>:<id>` or `direct:<org>:<external_id>`; never trust unsanitised imported HTML. Deterministic matching: required path/country gate → role token overlap with simple alias dictionary → date/seen state. No score percentage unless based on explicit defined formula and labelled heuristic. Show exact matched reason and unknown data warnings. Calendar reminder `.ics` only; offline email/push disabled at launch.

## Security operations

Data origin endpoints and webhook URLs never act as general SSRF fetchers. Reject localhost/private IPv4/IPv6, link-local, redirect to another hostname, punycode lookalikes and non-HTTPS schemes in employer apply URL review; do not assume DNS/domain verification alone proves employment or authority. All employer writes require session CSRF or scoped bearer token + per-object tenant checks, rate limits and audit. Store hashed tokens; never output a secret in logs/source/client.

## Bounded maintenance & auto-recovery

- Health cron once daily summarises last successful sync per provider, jobs visible/held, invalid links, failed backups, recent incident reports, API tokens abuse metrics (when active) and broken routes. Self-heal allowed for transient errors; substantive licence questions, company identity and suspected fraud are exceptions requiring trusted human judgement.
- Backups per available hosting, periodic restore drill, two retained restore points, failed-restore alert and reversible migration approach. Backups encrypted/access controlled and excluded from public web root.
- Admin emergency switches: `PROVIDER_JOBICY_ENABLED`, `PROVIDER_HIMALAYAS_ENABLED`, `RECRUITER_LITE_ENABLED`, `PARTNER_POSTING_API_ENABLED`, `ADS_ENABLED`. When off, site renders honest unavailable state, not fake success.
- No monitoring infrastructure should generate unbounded costs, emails or API calls. If email service unavailable use owner/admin dashboard; document that notifications won't be delivered.

## SEO, source rights and privacy

Imported provider-only thin job pages are `noindex` by default; provider-specific licence always wins over SEO wishes. Employer-owned original jobs may use JobPosting schema only when source/Google requirements pass, not for affiliate disguised jobs. Remove expired/closed jobs from job index and schema. Original guidance must have sources and last review timestamps; no mass AI-generated article spam. Ads only after actual account approval. Tracking consent must be applicable to region and vendor; analytics events never include applicant PII.


## Canonical DB reference

`24_DATABASE_SCHEMA_REFERENCE.sql` supplies the unified proposed schema and owner/provider invariants. The old illustrative SQL in `06_ARCHITECTURE_AND_DATABASE.md` is explicitly deprecated. Run schema against the actual available MySQL/MariaDB version in a scratch database, add migrations/rollbacks, and audit SQL constraints/application constraints before creating production tables. Candidate records remain browser-local.

**Country validation:** regex `^[A-Z]{2}$` alone does not make a valid country; validate ISO 3166-1 alpha-2 membership server-side (reject fabricated `ZZ`) on POST, PATCH full-object, source adapters and public filters. `candidate_eligible_countries` must be validated the same way.

## v1.4.1 provider-input type invariants

Current authoritative source object: `locationRestrictions: [{"alpha2":"IN","name":"India","slug":"india"}]`, `timezoneRestrictions: ["UTC+5:30"]`. For India, require both geography and UTC+05:30 timezone permission, or explicit empty-array unrestricted dimensions. Treat missing fields, nulls, unsupported types, invalid ISO membership and inconsistent restrictions as `unknown`; explicit valid geographic/time exclusion is `not_allowed`. Normalize only documented UTC string formats; do not assume the current JSON field is numeric. Independently test unknown, exclusion, empty arrays, malformed mixed arrays, and proven allowed. **Legacy source fixtures may be handled for migration, never as proof of current provider format.**

Source docs checked 2026-11-23: https://himalayas.app/docs/openapi.json. Repo v0.9.15 code must be assessed against this exact field contract before enabling live providers; docs checking is not live feed sampling.

# OverseasJob.in — 360° Product, Automation, Pipeline & Revenue Gap Review

**Assessment date:** 22 November 2026  
**Status:** v1.2 documentation-integrated gap register. All findings mapped to updated product/architecture/QA specifications; real deployment, live API sampling, economics and security tests remain unverified.  
**Inputs:** v1.1 10-file pack and static audit; v1.2 integrated blueprint, Decision Companion spec, updated API contract, policy matrix, traceability and authoritative source references.  
**Still not inspected:** Live website/repository, Analytics/Search Console, actual Hostinger plan, affiliate accounts, real API job coverage over 14 days, deployed API implementation or real user conversion data. DOCUMENTS ARE NOT WORKING CODE.  
**Founder constraints:** solo non-developer, AI-agent implementation, zero new paid API/subscription budget, minimum ongoing human operation, aspirational ₹50,000/month from ads/approved referral revenue.

## A. Executive answer

The earlier proposed platform was **not sufficiently differentiated**, even with Opportunity Guardian alone. Jobs, daily alerts, trackers, resume tools, games and AI recommendations are common. Do **not** compete on the total number of listings or features.

**Better positioning to test:** “OverseasJob.in — India-to-global Career Decision Companion.” For a specific job, explain (1) whether eligibility is explicitly confirmed/ruled out/unknown, (2) where the opportunity came from and whether it is recently verified, (3) whether compensation and costs could make financial sense *under user-entered assumptions*, and (4) the user’s next practical action. Support remote-from-India and physical relocation as **different** pathways.

The competitive advantage, if proven, is a coherent low-friction **decision workflow**, not a proprietary job database or an AI buzzword. “Verified employer”, “visa eligible”, “sponsorship confirmed”, “job is safe”, or “guaranteed saving” must never be inferred from missing data.

**Documented release order in v1.2:** Gate 0 measure supply and source rights; Gate 1 source-linked Decision Cards + three practical tools + no-login preference selection; Gate 2 browser-local Opportunity Radar + manual tracker/export; Gate 3 optional single daily mission and remaining tools based on actual demand; optional separate Gate 2B Recruiter Lite → Gate 3B inbound API after explicit verification/operations gates. Don't build email monitoring, cloud accounts, automatic applications, recruiter marketplace, video interview AI, or hundreds of SEO pages until demand and operating capacity are proven.

## B. What is not unique (competitor reality)

- LinkedIn already offers preference-based job recommendations and daily/weekly job alerts.
- Himalayas already offers free remote job browsing, AI recommendations, application tracking and weekly alerts.
- Jobicy already operates a remote jobs ecosystem plus career tools and public API.
- Therefore, the **whole pipeline must deliver better decisions for a narrow audience**, not merely another alert or 'AI score'.

Official references: https://www.linkedin.com/help/linkedin/answer/a511279/job-alerts-on-linkedin ; https://himalayas.app/pricing ; https://jobicy.com/ .

## C. Product/pipeline gaps reconciled in v1.2 specs (implementation evidence still pending)

| ID | Severity | Gap / failure mode | User or business impact | Exact correction / validation |
|---|---|---|---|---|
| P01 | Critical | **Supply–audience mismatch:** free sources mainly list remote jobs, whereas site promises overseas relocation/visa jobs | A person wanting physical overseas relocation finds misleading/no opportunities | Separate `remote_from_india`, `remote_region_restricted`, `onsite_abroad`, `unknown`; **never** promise sponsorship inventory until independently verified, authorised supply exists. Measure real India-eligible jobs by role and week. |
| P02 | Critical | **No proof of job coverage:** feed availability is mistaken for available suitable jobs | Daily Guardian may show zero relevant jobs for most profiles | Run 14-day source sampling with real API data, category/location eligibility tests; add a no-results honest fallback; stop if coverage fails. |
| P03 | Critical | **No true differentiation:** matching, alerts, tools and tracker are already sold/free elsewhere | No compelling switch or repeat-usage reason | Lead with `Job Decision Card`: explicit eligibility evidence + confidence labels + assumptions-based savings + source freshness + action; test against original job site on a small user panel. |
| P04 | Critical | **Background automation promise incompatible with local-only preferences** | 'Works for you while offline' is false for per-user alerts if all preferences stay in browser | Global cron can refresh the public job database. Per-user matching happens locally when browser next opens; email/push digests require opt-in server-side account, verified delivery, limits and privacy controls. Say this clearly on site. |
| P05 | Critical | **Traffic and monetisation gap:** published jobs ≠ organic reach ≠ AdSense revenue | Years of zero-income feature building possible | Set a business validation funnel with measurable impressions, engaged visitors, tool completion, return rate, AdSense status, actual RPM; no sales estimates based on unavailable CPCs. |
| P06 | High | Eligibility inference from 'remote' or geographic words | India users waste applications; possible discrimination/error | Confidence states: `explicitly_allowed`, `explicitly_not_allowed`, `unknown`, plus line/source that supports claim. Unknown never counts as match proven. |
| P07 | High | 'Latest' vs 'last fetched' vs 'last verified' conflation | Old or closed jobs look new | Store `published_at`, `first_seen_at`, `last_seen_at`, `last_checked_at`, `status_checked_at`; do not reset original published date on reimport. |
| P08 | High | Feed disappears after source window, not necessarily a closure | Silent deletion or false expired badge | Per-source status endpoints where allowed; distinguish 'not returned today' from 'closed'; controlled stale states; cron must not wipe cache after partial sync. |
| P09 | High | No explainable matching or negative-filter reasons | User does not trust ranking | Display 'why shown', 'unknown', 'why hidden'; exact filters vs helpful soft ranking; avoid arbitrary '92% fit' or fake verified badges. |
| P10 | High | No first-run onboarding that works anonymously | User cannot experience value within 30 seconds | One-screen 'Role → Work from India/Move Abroad → Country → Experience' selector; see first results immediately; prompt to save locally only after value delivered. |
| P11 | High | Action pipeline incomplete after outbound apply | Site claims applied/rejected states it cannot know | After external redirect, ask user to mark 'Applied' manually; never auto-mark applied. Offer .ics reminders/local export with opt-in; status remains user-entered. |
| P12 | High | Indefinite browser data not portable | Privacy-friendly local-only users lose everything on new device or browser reset | Visible export/import JSON/CSV; test round-trip; sensitive information not in query strings or analytics; clear delete-all. |
| P13 | High | Broad 10-tool suite competes with completion quality | Many incomplete tools/no engagement | Build 3 decision-oriented tools deeply; measure completion; ship remaining 7 only on proven demand. |
| P14 | High | Recruiter API creates fraud and moderation workload | Solo founder overloaded or fake jobs published | Invite-only, verified, limited recruiter pilot; feature flag and kill switch; postpone until traffic + moderation budget proven. No direct public registration to live posting. |
| P15 | High | Source licence and indexing/monetisation rights conflated | API permitted but onward redistribution or AdSense denied | Per-provider rights matrix with job page/index/schema/API-export/affiliate flags; source-specific test fixtures; no JobPosting markup for Himalayas; no generic API redistribution. |
| P16 | High | Safety and 'verified' claim unsupported | Risky applicants, reputation, liability | 'Source linked' != 'employer verified'. Use red flags, official references and reports; never algorithmically claim safety or visa entitlement. |
| P17 | High | No trustworthy buyer/recruiter demand validation | Optional posting API may never attract partners | No posting API work until 3–5 genuine pilot organisations request a concrete integration; document their ATS needs and desired field mapping. |
| P18 | Medium | Daily games have weak correlation to career outcomes or ad revenue | Users play but revenue/conversion stays flat | One original game only; measure return and assisted tool/job usage, not only streaks; don't force ad clicks or social invites. |
| P19 | Medium | Official country/visa information ages quickly | Bad migration decisions | Source+review dates; limit to 1–2 country guides; stale flag and no automated legal conclusions. |
| P20 | Medium | 'Zero cost' overlooks delivery/operations | Email, backups, hosting quotas and support add real cost | Written zero-*additional-recurring*-cost budget envelope; stop/disable on quota exhaustion; weekly 10–20 min owner review as planning assumption, not guarantee. |
| P21 | Medium | Multi-domain duplication with ToolBoxGalaxy | Duplicate content competes with existing website | OverseasJob only career-specific calculators and job decisions; generic converters/tools stay on ToolBoxGalaxy. Cross-link only when genuinely useful. |
| P22 | Medium | No honest empty-state or outage experience | User distrust on days with no jobs | 'No matching verified opportunities today' + edit preferences + suitable preparation actions; show last sync and incident status. |
| P23 | Medium | Employer/public job data ownership model inconsistent with earlier audit | API security and provenance leaks | Resolve prior v1.1 issues C01-C05/H01-H14 in separate technical correction before recruiter/API launch. |

### Additional technical findings inherited from v1.1 audit

The previous report enumerated 5 critical, 14 high, 8 medium and 3 low findings (30 total). In particular, fix canonical job model/provenance, company auth/verification, recruiter moderation capacity, API external-ID reconciliation, DTO/API response completeness, audit/consent persistence, status state transitions, UTC timestamps, idempotency, analytics and retention. **Do not add the 23 new product gaps to the earlier 30 and claim 53 independent defects** without deduplication; there is overlap.

## D. v1.2 required user-facing product: Job Decision Card

For each listing, display:

1. **What this opportunity actually is:** Remote work permitted from India / remote restricted / physical relocation / unknown; separate visa sponsorship evidence.
2. **Why it matched:** 2–3 source-supported factors (role category, location eligibility, experience when stated).
3. **What is unknown:** eligibility not stated, salary undisclosed, employment/contractor classification not given, sponsorship not disclosed.
4. **Source and timing:** provenance label, actual source apply destination, published date if supplied, last provider/status check.
5. **Financial comparison:** Launch user-entered assumptions; don't fetch unverified cost/tax/FX estimates or assert take-home savings.
6. **Next action:** source Apply, Save, Compare Offer, Prepare, Report Issue; after outbound click offer user-invoked 'Mark Applied' rather than pretending application success.

**No false labels:** Never call an imported third-party role 'verified employer' or score visa success likelihood. Where there is not enough information, show 'Unknown — verify with employer.'

## E. Two separate automation pipelines, not one magic 'AI agent'

### Shared/public backend pipeline (works unattended if hosting cron stays operational)

```
Provider licensed API
   -> schedule + rate limits + error/backoff
   -> parse and validate fields/URLs
   -> source-policy gate + provenance
   -> standardize location/eligibility with explicit unknowns
   -> source-specific deduplication
   -> status/expiry sync + stale-state rules
   -> local jobs database/cache
   -> searchable public pages and API responses to same website
   -> health/error counters and privacy-safe aggregated analytics
```

### Private/user-specific on-device pipeline (works when the user opens site)

```
User preferences saved on this device
   -> fetch current site search results
   -> local match + explain why/unknown
   -> compare new with last-seen records
   -> saved jobs / manual application status
   -> local reminder calendar export + career actions
```

This does **not** send per-user notifications while their device/browser is offline. Offer server-side personalised background notifications only later, with separate opt-in account, email delivery and privacy requirements.

### Recruiter intake (late optional, never mixed into public imported-job pipeline)

```
Invite and company verification
   -> authenticated dashboard / scoped inbound posting API
   -> entity ownership + proof of source
   -> content and URL validation + spam review
   -> `pending_review` until approved
   -> published first-party job in public search
   -> expiry/close/kill switch
```

No candidate CV collection or full ATS at launch. The inbound API is NOT a resale endpoint for Jobicy/Himalayas/other provider jobs.

## F. Source economics and policy corrections (checked 22 November 2026)

**Jobicy**: Public Jobs API permits commercial integrations with attribution, returns recent jobs (published in last seven days); keep free apply links pointing to Jobicy. Direct ATS URL access is part of a separate commercial API/wallet. Jobicy's referral program is a *different business*: eligible **employer job-posting purchases**, not automatic jobseeker-click or job-application CPC, generate commission after approved affiliate attribution. Don't represent free feed clicks as paid.

**Himalayas**: Jobs API permits own-site listings with unchanged `applicationLink` and visible attribution, but prohibits passing jobs to other boards, aggregators or Google Jobs via feeds or `JobPosting` markup; expired jobs must be removed.

**Google**: Republished job content without substantive original value can violate AdSense replicated-content policy. Mass-produced thin pages can run afoul of search spam rules. `JobPosting` structured data has specific eligibility and expiry requirements. **A provider's data licence does not grant SEO ranking or AdSense approval.**

Official references:
- https://jobicy.com/jobs-rss-feed
- https://jobicy.com/affiliates
- https://himalayas.app/api
- https://support.google.com/publisherpolicies/answer/11190248?hl=en
- https://developers.google.com/search/docs/appearance/structured-data/job-posting
- https://developers.google.com/search/docs/essentials/spam-policies

## G. Minimal product and measurable go/no-go gates

### Gate 0 — Feasibility, **before coding 10 tools**

- Verify actual Hostinger PHP/cron/database/backups capabilities and existing costs.
- Verify provider API real data in a small batch and its rights; use 14-day sampled coverage for 2–3 roles chosen for India-based audience.
- Explicitly report `total fetched`, `India explicitly eligible`, `India explicitly ineligible`, `unknown`, `closed`, `duplicates` across role categories.
- If India-eligible opportunities are negligible, **don't market as a comprehensive India-eligible job engine**. Reposition honestly as a global career utility and defer job-centric personalised promise.

### Gate 1 — First useful public experience

- Homepage: simple select role + country/work arrangement; no login.
- Curated source-linked job directory, honest eligibility labels, dedup, freshness, manual report.
- Decision cards + salary-savings, offer comparison and timezone overlap calculators.
- Five original well-sourced guides; privacy, terms, contacts, reporting and clear source policy.
- No paid APIs, no forced applications, no imported thin pages mass-indexed.

### Gate 2 — On-device opportunity companion

- Browser-local preferences, returning user sees changes since last visit and no-results state.
- Save jobs, manual tracker, export/import, reminders via downloadable calendar event.
- Show explainable reasons and unknowns; don't promise offline personalized processing.
- Measure activation and repeat usage for actual users, not synthetic visits.

### Gate 3 — Retention experiment

- One original weekly/daily role-based mission or puzzle (not 20 games).
- Check whether game users also use opportunities/tools and voluntarily return.
- Stop game expansion if there is no material lift in meaningful usage.

### Gate 4 — Optional recruiter/API only if explicitly justified

- Real partner demand, moderation capacity, auth & security fixed; 3–5 invite-only companies.
- No direct public posting API until role policy, verified identity, abuse controls and functional tests pass.

## H. KPI definitions and stop rules

Avoid rigid industry 'benchmarks' with no evidence. Instead instrument:

| Funnel stage | Event / definition | Interpretation |
|---|---|---|
| Acquisition | Search impressions and organic clicks per original page | Did users find you at all? |
| First value | Visitor completes 1 meaningful action: job relevance review, calculator, saved comparison | Does homepage solve a problem quickly? |
| Match quality | % of shown jobs with explicit location eligibility and live source | Is the job database useful? |
| Job action | Eligible, source-linked Apply clicks / relevant job views | Are users finding useful opportunities? |
| Return | 7-day and 30-day return cohorts (privacy-conscious) | Any natural habit? |
| Content quality | Search Console page coverage, indexing errors, original landing-page conversions | Does SEO produce real value? |
| Reliability | Sync success, job age, expired-job leakage, inbound/redirect failures | Is automatic operation trustworthy? |
| Revenue | AdSense approval, actual page RPM, attributable partner sales (if approved) | Is there actual money? |

**Illustrative business equation:** at ₹100 Page RPM, ₹50,000/month requires 500,000 monthly pageviews = about 16,667 daily pageviews on a 30-day month. This is NOT a forecast, and a small daily game audience alone is insufficient.

**Pause/trim rules:** stop optional features if moderation incidents/owner time exceed capacity; pause a provider on material terms uncertainty; do not pay for AI/API until earned revenue justifies it; stop mass-content expansion if indexation fails or users do not finish tasks; review positioning if coverage pilot finds almost no explicitly India-eligible jobs.

## I. AI-agent acceptance tests that should be added to existing v1.1 documentation

1. Given a remote job explicitly restricted to US residents, an India-based user never sees 'India eligible'.
2. Given a job that simply says 'remote' with no country, display 'Eligibility unknown', not 'Worldwide'.
3. Given an on-site job in UAE with no visa disclosure, show relocation role, sponsorship unknown.
4. Given a feed sync failure, don't delete prior cache or declare every job closed; show last check.
5. Given a Jobicy job from 8 days ago absent in the 7-day discovery feed, do not automatically mark closed without status evidence.
6. Given a Himalayas listing, use unchanged `applicationLink`, visible credit, and no `JobPosting` markup or outbound resyndication.
7. Given Jobicy free feed, preserve Jobicy apply page; do not claim the direct ATS link is a free entitlement.
8. Given identical jobs across sources, preserve original provenance and allowed URLs; never convert restricted jobs into first-party owned jobs.
9. Given user opens an external Apply link, do not automatically change application status to 'Applied'.
10. Given local device storage loss, user was warned and had working JSON/CSV export/import.
11. Given user is offline and has no account, do not imply server-based personalized monitoring or email delivery.
12. Given a salary whose gross/net basis is unknown, no automatic net pay or guaranteed savings number.
13. Given no new eligible jobs, show honest empty state and a useful alternative career action.
14. Given a new unverified recruiter submits a job, never publish it publicly without verification/review.
15. Given provider jobs are queried from partner posting API, reject/return no data even when requester is another tenant admin.
16. Given an advertised tool is not built, show it as 'planned' or hide; never return a broken or fake result.
17. Given SEO page is built only from a feed snippet, exclude it from ad-oriented/indexable original-content inventory unless it provides substantive useful value.
18. Given affiliate link click, never record income without an actual verified eligible paid conversion.

## J. Product-development decision

**Pursue:** A small, private, clear decision companion for Indian professionals exploring remote global work.  
**Do not pursue now:** giant 'AI career agent' claims, 10 half-finished tools, complete recruiter ATS, public unsupervised job posting, massive thin-job SEO, unattended visa/legal advice, fraudulent paid jobs, automatic third-party applications, and fantasy CPC income projections.

**Current status:** All changes were transferred to v1.2 documentation. No code, live job coverage, actual analytics, real affiliate payouts or hosting integration was tested. Conduct Gate 0 and then Gate 1 before green-lighting the broader roadmap.


---

## K. v1.2 resolution mapping: where each recommendation now lives

**Important classification:** “Specified” means a requirement now exists in a project document, NOT that the platform is implemented, verified, monetised or safe to deploy.

| Gap group | Main v1.2 source of truth | Current evidence status |
|---|---|---|
| P01–P02, P06–P08, P22 (inventory, eligibility, freshness, empty results) | `01_COMPLETE_PROJECT_BLUEPRINT.md` §4C and `10_DECISION_COMPANION_PRODUCT_SPEC.md` §3, §5, §9 | Specified; 14-day real feed data pending |
| P03, P09–P13 (decision UX, first-use, tracking and local state) | `10_DECISION_COMPANION_PRODUCT_SPEC.md` §2, §4, §6, §11 | Specified; user testing/device/browser QA pending |
| P04 (true offline personal alerts) | `01_COMPLETE_PROJECT_BLUEPRINT.md` v1.2 release decision; `10_*` §4 | Resolved as scope boundary; no offline personal alert implemented |
| P05, P18–P21 (ROI, tools, games, domain overlap, founder cost) | `10_*` §8–§10 and `03_MILESTONE_TASKS.md` Gates 2–3 | Metrics defined; traffic/revenue unknown |
| P14–P17, P23 (partner jobs, trust, rights and employer burden) | `06_ARCHITECTURE_AND_DATABASE.md` §§10–12, `07_*` §11, `08_*` API contract | Specified; pilot, security and legal release evidence pending |
| v1.1 audit C01–C05/H01–H14 | `11_V12_TRACEABILITY_AND_DECISIONS.md`, `04_QA_AND_LAUNCH_CHECKLIST.md` | Not code-verified; still block affected releases |

### Canonical release path and conditions

- **Gate 0 — Validate:** actual hosting and licenses, 14 days API samples, role/eligibility coverage, source rights. No development claims from documentation.
- **Gate 1 — First useful action:** source-correct job discovery, decision cards with confirmed/unknown evidence, no-login selector, 3 tested career tools and 5 substantive guides.
- **Gate 2 — Returning value:** on-device Radar, new-to-you comparison, manual application status, follow-up calendar export, state backup/delete. No offline email or automatic application status.
- **Gate 3 — Optional retention:** one original game/mission if user value justifies it. Do not expand 10 tools as a box-ticking exercise.
- **Gate 2B/3B — Optional employers:** gated verified pilot and inbound API only if 3–5 legitimate demand partners exist, founder moderation capacity sustainable and v1.1 audit critical/high controls proven by tests.

### Additional contract correction from v1.1 technical audit

The Partner API draft has been updated in v1.2 to describe: `201` always `pending_review`, expanded employer-owned JobResponse, `GET /jobs?external_id=` lookup for retry reconciliation, `If-Match` optimistic concurrency, explicit `work_country` vs `employer_country` vs eligible countries, idempotency, consent evidence and server-side role verification. **This YAML is still a design artifact, not a running API.** Before production, implement actual reviewed migrations, backend validation and full OWASP API tests.

### Remaining blockers after this documentation update

- Actual 14-day India-eligible job inventory, including role relevance and source restrictions: **not measured**.
- Source terms recheck on the actual deployment date, plus legal/compliance review for any overseas recruitment activity: **required**.
- Hosting plan/runtime/cron/mail capability and backup-restore test: **not verified**.
- Deployed privacy-safe analytics, genuine user growth, AdSense approval, actual page RPM, eligible affiliate earnings: **not established**.
- Employer onboarding, identity evidence, moderator capacity, data retention policy, tested API implementation: **not established**; optional features remain OFF.

**Documentation update ≠ release approval**. A production-ready verdict can only follow code, infrastructure, security and actual-user tests.

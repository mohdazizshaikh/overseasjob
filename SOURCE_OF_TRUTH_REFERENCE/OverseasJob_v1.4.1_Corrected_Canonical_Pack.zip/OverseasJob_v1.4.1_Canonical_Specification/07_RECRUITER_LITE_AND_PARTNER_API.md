# OverseasJob.in — Recruiter Lite + Partner Job Posting API (v1.2 specification)

**Status:** v1.3 proposed future-phase specification; not implemented, deployed, or enabled.
**Prepared:** 22 November 2026.
**Purpose:** Let legitimate employers post jobs directly, and allow approved employer/ATS integrations to create, update, and close their **own** job listings using a secure API. This is **not** a recruitment/placement agency or candidate ATS.
**Constraints:** Solo founder; ₹0 new paid services/APIs; minimal human attention; original core website remains useful without employer participation.

## 1. Scope and launch sequence

| Capability | Proposed milestone | Cost/operations principle |
|---|---|---|
| Manual employer job submission | Phase 2B **opt-in pilot** after public site works | Reuse existing PHP/MySQL; do not turn on before abuse protection exists |
| Recruiter dashboard to edit, close, renew | Same employer pilot | Simple server-rendered UI; no chats, applicant database, CV storage |
| Partner REST API v1 (inbound posting) | Phase 3B, after 3–5 verified employer pilot accounts | Invite-only issuance; disable API globally by feature flag |
| OpenAPI description, usage metrics and API key rotation | Alongside API v1 | Public documentation but private authorisation |
| Public read-only export of *consenting first-party* employer jobs | **Optional Phase 4**, not required | Only direct employer-owned postings with explicit distribution permission |
| Webhooks, ATS connectors, bulk feeds, OAuth app marketplace | Future, **not** v1 | Avoid expensive background infrastructure and moderation |

**Go/no-go:** The feature remains **disabled** if HTTPS, persistent accounts, email verification, domain/employer checks, safe logs, rate limits, backups, or abuse queue cannot be supported by actual hosting. Agent must not represent disabled features as live.

## 2. Key distinction: three different job origins

1. **Third-party provider feed** — Jobicy/Himalayas/etc: display only within source licence; preserve mandated apply link and attribution; **never expose to partner distribution/export APIs** by default.
2. **First-party employer-owned submission** — Directly registered employer posts a job with a genuine employer/approved ATS application URL; the employer attests they can publish it and that it is real.
3. **Approved recruiting-agent submission** — Only after legitimacy, authorisation and applicable overseas recruitment compliance are independently reviewed; do not treat agencies as verified simply because they own a domain.

Records must carry `origin_type`, `owner_org_id` (for owned submissions), `publish_consent`, `distribution_consent`, `verification_status`, `moderation_status`, `source_policy_id`, and `apply_url`. Database and API queries must be **tenant-scoped** and source-rights aware. No fallback that exports all `jobs` rows.

## 3. Who can use it and how trust works

- **Visitor/candidate:** No login to browse jobs or use free career utilities; external Apply opens the employer/source URL.
- **Recruiter / employer member:** Needs account, verified email, organisation affiliation, and permission `org_jobs_manage` to submit their company's jobs.
- **Organisation administrator:** Manages authorised team, job ownership, and company profile. First pilot can be one trusted org admin only.
- **API partner service account:** A **verified** organisation's server-to-server integration with scoped credentials. Not a public anonymous jobs-post endpoint.
- **Platform owner (founder):** Exception-only moderation, account suspension, API token revoke, source rules, audit and health overview.

Minimum identity verification: email confirmation, employer domain ownership/control (DNS TXT or controlled email/domain plus independent checks), real company identity check as appropriate, representative authorisation, and manual approval for early pilot and overseas postings. Do not show a misleading 'government verified' or 'trusted' badge. Where a recruiter/agency is placing people abroad, apply the relevant MEA/eMigrate registration and foreign-employer rules before enabling the affected workflow; get professional legal review. This project does **not** conduct recruitment/placement or collect applicant passports.

## 4. Recruiter Lite screens (proposed routes)

| Path | Purpose | Access |
|---|---|---|
| `/employers` | Employer benefits, free posting entry point, FAQ and public rules | Public |
| `/employers/register` | Employer onboarding and verification workflow | Prospective employer |
| `/employers/dashboard` | Counts by status, upcoming expiry, source of applications, basic clicks | Authenticated org member |
| `/employers/jobs/new` | Structured job submission with draft preview | Verified org member |
| `/employers/jobs/{id}/edit` | Update only employer-owned jobs | Verified org member |
| `/employers/settings/api` | Issue/revoke API token, inspect scope/last-used, one-time reveal | Verified org admin; Phase 3B |
| `/developers` | API docs, restrictions, OpenAPI and versioning guide | Public documentation |
| `/admin/moderation` | Review suspicious employer jobs and reports; minimal audit trail | Platform owner only |

Public `/jobs` unifies imported and direct jobs but visually identifies source ("Direct employer listing" vs "Partner job feed"). Do not imply verified company status unless checks are complete and documented.

## 5. Job submission fields and validations

**Required:** `external_id` (stable per organisation), `title`, `description` (plain text or sanitized allowlisted markup), `employment_type`, `work_mode` (`remote`, `hybrid`, `onsite`), `country` (ISO 3166-1 alpha-2 for physical job location), `location_text`, `apply_url` (`https`), `valid_through` (`RFC3339`, in future), and `consent_to_publish`.

**Optional but accurately represented:** `city`, `candidate_eligible_countries`, `salary_min`, `salary_max`, `salary_currency` (ISO 4217), `salary_period`, `visa_sponsorship` (`yes/no/unknown`), `relocation_support`, `benefits`, `company_logo` (later and subject to verified ownership). Salary bands must be valid and consistent. 'Visa sponsorship' must be explicitly provided and attested; **unknown** is default.

**Prohibited:** Candidate fees/deposit requests, unverifiable money-making schemes, fake visa guarantees, passport or identity-document upload instructions, deceptive redirects, generic lead-generation pages masquerading as jobs, misleading employers, and jobs posted by organisations without publication rights.

URL policy: allow only `https` links; require destination hostname to be verified company domain or specifically allowlisted ATS domain/tenant; block known shorteners and risky domains. Redirects and domain changes require revalidation, not an automatic trust assumption. Reject internal IPs and local hostnames if fetching URLs; prefer not to fetch arbitrary URLs from the API server. Escaping/HTML sanitization required.

Reasonable initial expiry policy: user chooses expiration 1–60 days ahead; automated close at `valid_through`, reminder before closure, no silent auto-renew. Reopening requires re-attestation; bulk unattended renewal is prohibited until verified.

## 6. Partner REST API v1 — inbound only

**Base:** `https://overseasjob.in/api/v1/partner`

| Method and route | Purpose | Scope |
|---|---|---|
| `POST /jobs` | Create job or retry with idempotency key | `jobs:write` |
| `GET /jobs` | Paginated listing of caller organisation's jobs | `jobs:read` |
| `GET /jobs/{job_id}` | Fetch caller-owned job and review state | `jobs:read` |
| `PATCH /jobs/{job_id}` | Edit caller-owned job; material edits may re-enter review | `jobs:write` |
| `POST /jobs/{job_id}/close` | Close/unpublish (soft close, no destructive DELETE) | `jobs:close` |
| `GET /usage` | API plan/quota and recent request counts (no PII) | `jobs:read` |

All API responses JSON; RFC3339 timestamps UTC; `application/json`; keys always server-side. Create request needs `Idempotency-Key`; client must use stable `external_id` unique per organisation. Duplicate same idempotency key+payload gives same safe result; same key with different payload gives `409`. Tenant/external IDs cannot be reassigned. Draft/reviewed jobs must never be displayed as active until published by trust workflow.

**Authentication:** `Authorization: Bearer <opaque random token>`; issue cryptographically random minimum 256-bit secret **once**; store only keyed fingerprint or strong one-way hash; never echo to logs, analytics, UI after issue. Key is tied to verified organisation and exact scopes, has an expiry/rotation mechanism, supports immediate revoke. Rotate with bounded overlap for safe migration. Use TLS, strict IP monitoring and per-tenant throttling. Bearer token is an integration credential, not employer identity verification by itself.

**Guardrails:** object-level owner checks on **every** query, explicit allowed writable fields (no mass assignment), distinct role and scope enforcement, CSRF for browser forms, no CORS-wide wildcard write access, payload size limit (example 32 KiB), max text lengths, prepared SQL, input normalization, and server-side output escaping.

**Illustrative abuse limits (adjust after measurement):** 60 total API requests/minute per token, 10 newly submitted postings/day per unproven pilot org, 100 updates/day, and global circuit breaker for runaway posting. Return `429` and `Retry-After`. These are sample limits, not supplier/API quotas. Burst moderation may reduce them.

**Response contract:** `201` created pending_review; `200` retrieved/updated/closed; `400` malformed; `401` auth missing/invalid; `403` scope or org unapproved; `404` not owned or missing (avoid enumeration); `409` idempotency/external-id conflict; `422` validation; `429` rate cap; `503` temporarily paused. Standard errors: `{ "error": { "code": "...", "message": "...", "request_id": "..." } }`. Never leak other organisations' listings or keys.

**Job statuses:** `draft` → `pending_review` → `published` → `closed` / `expired` / `rejected` / `suspended`. A company may withdraw instantly; approval is never guaranteed. Material edits (employer, domain, country, remote eligibility, compensation, sponsorship) can trigger a new review and temporarily unpublish if safety requires it.

## 7. Example integration

```bash
curl --request POST 'https://overseasjob.in/api/v1/partner/jobs' \
  --header 'Authorization: Bearer YOUR_SERVER_SIDE_SECRET' \
  --header 'Content-Type: application/json' \
  --header 'Idempotency-Key: company-job-987-v1' \
  --data '{
    "external_id":"company-job-987",
    "title":"Technical Support Engineer",
    "description":"Support customer IT systems and resolve technical incidents.",
    "employment_type":"full_time",
    "work_mode":"remote",
    "work_country":null,
    "location_text":"India (remote)",
    "candidate_eligible_countries":["IN"],
    "apply_url":"https://careers.example-company.com/job/987",
    "valid_through":"2026-12-15T23:59:59Z",
    "visa_sponsorship":"unknown",
    "consent_to_publish":true
  }'
```

**Mock response only (illustrative, endpoint does not exist yet):**

```json
{
  "id":"job_01JEXAMPLE",
  "external_id":"company-job-987",
  "status":"pending_review",
  "public_url":null,
  "created_at":"2026-11-22T12:00:00Z"
}
```

Do not ship the literal sample token as a real credential and do not label these as operational production endpoints.

## 8. Automation + minimal manual handling

- Employer submits from browser/API; deterministic validation performs required-field, company ownership, domain allowlist, duplication and forbidden-text checks.
- Low-risk verified employer postings may be auto-published **only after** adequate verification and successful pilot; first postings and anomalous overseas/sponsorship listings are review-gated.
- Status changes have audit entries. Duplicate/repeated rejected uploads are throttled or blocked.
- Cron expires jobs after `valid_through`, notifies when possible, and records failures; closure immediately removes active search visibility and relevant `JobPosting` metadata.
- Daily digest lists unusual employer/job activity, failed checks and review queue counts; do not claim that AI alone can certify employer legitimacy.
- Admin kill switches: turn off entire recruiter onboarding, API writes, specific organisation/token, public employer listings and schema generation independently.
- No heavy ATS, email campaigns, CV storage, chat, applicant screening, payment/escrow or job-seeker subscriptions in pilot.

## 9. Search, Google Jobs and monetisation rules

- Only **direct employer-submitted postings** that satisfy Google JobPosting content/technical requirements may be eligible for schema; use separate source-policy flag `schema_allowed`. No markup on third-party feeds with restrictive licences (notably Himalayas), list pages, fabricated jobs, expired or promotional-only job pages.
- Third-party provider jobs cannot be exposed through API, bulk export, partner syndication, webhook, or SEO distribution without a specific independently documented licence.
- Direct employer jobs may be copied externally *only if* the employer explicitly opts into syndication with a documented destination licence; default `distribution_consent=false`.
- AdSense applies only if approved; do not put ads that imitate or obstruct Apply. No guaranteed referral payments. Sponsored jobs must be clearly labelled and cannot be presented as organic verified jobs.
- The API is **free for approved pilot employers**, with no paid API services/billing at launch; any future premium/API pricing requires evidence of demand and new founder approval.

## 10. Testing checklist / acceptance gates

**Functional:** browser create/edit/close, API create/list/get/patch/close, scoped keys, idempotent retry, stale-to-expired path, preview and public source distinction, first job review, safe rejection and reporting.

**Security:** expired/revoked tokens, wrong org ID in URL, field injection (`is_verified`, `owner_org_id`, `status=published`), SQLi, XSS in text, SSRF/open redirects, impersonating company domain, rate abuse, idempotency conflict, replayed/stolen token, CSRF, overly permissive CORS, web-root secrets, log token leaks, bulk spam, account recovery.

**Licensing:** provider-imported records never returned from partner API, public export, sitemap or structured data where forbidden; no employer-generated claim can override feed restrictions.

**Quality:** no unsupported paid service; real production disable toggles work; full deployment/rollback instructions; smoke tests after migration; verify every job can be closed immediately.

**Security reference:** https://owasp.org/projects/api-security-project ; https://cheatsheetseries.owasp.org/cheatsheets/REST_Assessment_Cheat_Sheet.html
**Google reference:** https://developers.google.com/search/docs/appearance/structured-data/job-posting
**India overseas recruitment reference:** https://www.mea.gov.in/oe-faq.htm ; https://emigrate.gov.in/

**Completion definition:** A verified employer can post/maintain *their own* jobs, while an anonymous candidate can discover and apply externally, without the platform running placement services or redistributing restricted third-party feeds. API is not 'done' until security, tenancy, moderation, logging and kill-switch tests pass.


## 11. v1.2 corrections, dependency gates and operating limits

This is an **optional** branch after core Gate 2, not an automatic feature at launch. At least 3–5 real, legitimate partners must demonstrate demand and documented identity/onboarding/support burden must be within maintainable limits (manual trust review is still required). See architecture `06_*` sections 10–12 and `11_*` audit traceability. Draft documents are NOT tested services.

- **Authentication:** verified email plus proven human session/password recovery with CSRF, secure cookies, brute-force limits, org role separation. API keys do not log in a person. If safe email delivery is unavailable for free on real hosting, delay this module.
- **Ownership and trust:** first companies invite-only and human reviewed; approved external ATS destinations must show employer authority. Never mark provider imports as employer-owned; source policy licence remains intact. No default verified-employer badge for self-signup.
- **Job state:** POST always creates `pending_review`, `201` response reflects this; only reviewer can publish. Material edit returns to review; close is immediate; expiry hides. No automatic renewal. Store publication-consent version/actor/time.
- **Concurrency:** `revision` field and `If-Match`/`409` conflict; `external_id` scoped to org and queriable in list to reconcile retries. Atomic idempotency storage of request hash and create result.
- **Fields:** explicit `work_mode`, `work_country`, optional `employer_country`, candidate eligibility countries and unknown state, visa support separately. Apply domain and redirects screened without SSRF/probing arbitrary internal resources.
- **Analytics:** only aggregated daily page views/qualifying outbound clicks with bot/duplicate safeguards and limited retention; not applicant profiles.
- **Kill switch:** default flags OFF; pilot max 5 orgs; any unreviewable queue triggers pause, not auto-publish. Two new manual review cases/day is a proposed founder budget requiring real measurement. Honest 48h review window is a proposed target, not an automatic guarantee.
- **Retention:** decide lawful evidence/audit log retention, org offboarding and deletion in a separate approved privacy schedule before first live employer signup.
- **Allowed API direction:** approved employer ATS -> own jobs on OverseasJob. Never feed third-party imported jobs to another partner, even under a mistaken “public API” promise.


## v1.3 canonical contract precedence

Request and response field types MUST match `08_PARTNER_JOB_POSTING_API_OPENAPI.yaml`. Sponsorship and relocation support are strings `yes|no|unknown`, not booleans. On-site/hybrid `work_country` is a required non-null ISO alpha-2 string; full reconstructed object validation is mandatory after PATCH. Use the sample-request contract test in `23_VALIDATE_SPEC.py`; this section is illustrative and may not grant URL/domain authority.

Recruiter onboarding, email/domain checks and exceptional moderation remain manual-dependent; do not silently auto-approve organisations or regulated overseas recruitment. On full-access AI-agent build, the agent may implement, run tests, deploy to staging, restore backups and iterate without repeated founder micro-approvals; the public recruiter POSTING feature must remain disabled until verification workflow is working.

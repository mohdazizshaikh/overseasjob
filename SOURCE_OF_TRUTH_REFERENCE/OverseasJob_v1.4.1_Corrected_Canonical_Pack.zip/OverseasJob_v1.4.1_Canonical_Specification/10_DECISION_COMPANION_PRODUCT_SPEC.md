# OverseasJob.in — Career Decision Companion: Job Decision Cards + Opportunity Radar

**Version:** 1.4.1 | **Date:** 2026-11-23 | **State:** PRODUCT SPECIFICATION ONLY, not live.
**Priority:** Gate 0 source/coverage proof → Gate 1 Decision Cards → Gate 2 local Radar/tracker → Gate 3 optional mission/game. **No paid APIs, no candidate account or mandatory signup.**

## 1. User promise and honest boundary

“We help people in India find source-linked global job opportunities, understand what is explicitly known or unknown about eligibility and costs, compare their options, and manage next steps.” This does **not** promise guaranteed employment, employer legitimacy, visa sponsorship, continuous personal monitoring, automatic application, or accurate live net salary/tax calculation.

Separate public directories:

1. **Remote, explicitly open to applicants in India** only with source-backed eligibility evidence.
2. **Remote, limited or not confirmed for India** with clear `not_allowed`/`unknown` state, never euphemistically “Worldwide”.
3. **On-site abroad / relocation** ONLY if a reliable permitted listing confirms on-site/physical country; sponsorship separately marked yes/no/unknown. Free remote feeds do not imply supply in category 3.

When no jobs match, render a genuine “No newly confirmed matches” state and useful alternative tool/guide actions. Never invent supply or manipulate sorting to simulate updates.

## 2. First-use UX contract and flows

**Anonymous onboarding:** one screen with role (suggestions, editable), path (`remote_from_india | remote_other_or_unknown | onsite_abroad`), desired country/region, optional experience. Showing results must require zero signup; saved preferences require a user action and remain browser-local. UI on mobile should make first source-linked results reachable in 3 meaningful actions from landing page.

**Job Decision Card** displays source label/required link, title/company as supplied, work model, source-backed eligibility state, evidence wording and source URL (if publisher terms permit quote; otherwise human-readable summary + link), salary disclosed/unknown, job published date (if available), last feed check and status check (not conflated), role match reasons and 1–2 actionable tools. Use disclaimer “Source information can change; confirm directly with employer.” No fake “94% fit”, “Guaranteed eligible” or algorithmic scam-safe badge.

**Application action:** must use the approved original provider apply target. The user leaves site. No callback implies successful application; display “You left OverseasJob.in; mark Applied only if you completed your application.” Allow manually entered Applied/Interview/Offer/Rejected statuses and follow-up dates, never pretend the external system sent updates.

**Returning user:** local profile filters current safe public DB results on visit. `new_for_you` means not in this browser's last-seen set (NOT recently published); `newly_published` means source publication evidence. Distinguish these labels. Detect changes by stable `(source, source_job_id, source_version/content_hash)`. Unknown status or stale source is not fresh opportunity.

**Data loss:** browser clearing/device switch may erase state. JSON download/upload and delete-all must be available, with schema version and validation (no server-side import), plus optional `.ics` calendar export for follow-ups. No automatic email/push in MVP. Do not insert CV contents, applications, names or employer notes into URL queries or analytics.

## 3. Public job lifecycle and eligibility policy

- **Job origin:** `provider | direct_employer | licensed_partner`; provider records never transformed into employer-owned records. Per-origin licences and display flags have deny defaults.
- **Canonical public DTO:** Use `16_DATA_AND_OPERATIONS_CONTRACT.md` §“Canonical JobView” exactly; legacy `origin_type`, `remote_eligible_countries`, `published_at` and `india_eligibility_state` naming in earlier drafts is deprecated. Do not silently equate update/first-seen times with publication or offer universal remote eligibility.
- **Location eligibility states:** `explicitly_allowed | explicitly_not_allowed | unknown`. A remote label alone, employer domicile alone, or the word “global” alone is not evidence of India eligibility. Source-provided country lists and explicit statements may support classification; contradictory evidence becomes unknown/reviewed.
- **Status states:** `available_verified | available_unverified | stale_unknown | confirmed_closed | expired | quarantined`. The public UI may display only statuses allowed under per-provider TTL; unavailable verified feed or transient error must NOT reset all jobs to closed.
- **Date fields:** source-published timestamp must never be overwritten by re-import; first_seen once; last_seen on complete valid fetch; last_checked on check attempt; status_checked only after authoritative success; expires_at only when known; all server timestamps UTC.
- **Closure evidence:** a documented authoritative provider closure signal where available, or source expiry when authoritative; **Himalayas has no documented per-job 410 endpoint**. Absence from Jobicy's bounded latest-results feed is **not** proof of closure. Partial pagination failure cannot shrink public catalogue automatically.
- **Rights gates:** `allow_public_render, allow_index, allow_jobposting_markup, allow_sitemap, allow_partner_export, apply_link_mode, attribution_required`. Deny defaults, per-source unit fixtures; never leak provider records via employer partner API.
- **Salary:** preserve reported original currency and period; never infer net take-home or country tax from role title. Tools operate on user entered exchange rates, expenses and assumptions; use clear estimate label. No unprovided official visa fees.

## 4. Background / private data boundary

```text
PUBLIC: Provider APIs -> scheduled cron under licence/quota -> validate/sanitize
  -> source policy -> canonical JobView -> store + verify status -> public search/cache
  -> anonymous site and source-required apply URL

PRIVATE (only upon user's visit): local role/path/region preferences
  -> query current site jobs -> local explainable filter + new-since-last-visit set
  -> saved cards -> manually maintained application state + local reminders
  -> encrypted? NO: ordinary browser storage; warn about device access and clearing
```

Global API refresh can happen when users are offline. Per-user custom notifications **cannot** occur offline without opt-in server-side preference storage and delivery infrastructure, which remains out of scope. Browser-local data is not automatically synced across devices.

## 5. Matcher rule specification (no proprietary claims)

1. If source expressly excludes India, set `explicitly_not_allowed`, never label “recommended India-eligible.”
2. If source expressly permits India or exhaustive allowed-country list includes IN, set `explicitly_allowed` and attach evidence citation/field.
3. If unrestricted “remote” with no country proof, `unknown`; don't treat as worldwide.
4. Confirm work path (remote vs on-site) independent of sponsorship. On-site abroad may have unknown sponsorship.
5. Sort confirmed allowed roles first for an explicitly India-eligible filter, then by role relevance, recency with grounded timestamps, then match explanations. `unknown` excluded by strict India eligibility filter, but may be viewed under “Show unknown eligibility.”
6. Never expose arbitrary percentages or “verified employer” from ingest-only content.
7. If provider terms restrict quoting, show brief source-grounded paraphrase with link, not scraped full description.

## 6. Minimal local state schema

```json
{
  "schema_version": 1,
  "career_profile": {"roles": ["IT support"], "work_path":"remote_from_india", "countries": ["IN"], "saved_at": "2026-11-22T00:00:00Z"},
  "seen_jobs": [{"origin":"provider", "source":"example", "source_job_id":"a1", "last_seen_version":"hash-example"}],
  "saved_jobs": [],
  "applications": [],
  "follow_ups": [],
  "last_dashboard_view_at": "2026-11-22T00:00:00Z"
}
```

IDs above are **sample fixtures, not real jobs**. Imported data must be schema-validated, have length/count caps and never be executed as HTML/script. Migrations require versioned client-side upgrades. Do not store personal CV details by default.

## 7. Minimal public REST / HTML interface (separate from partner API)

- `GET /jobs?role=...&path=...&eligibility=confirmed|unknown|all` — safe filtered anonymous public search; no personal identifier.
- `GET /jobs/{provider}/{id}/{slug}` — source-correct details; index rights depend on licence and original value.
- `GET /api/public/jobs?role=...` — optional tightly limited same-site read endpoint for local matching; **enforce source rights**, pagination and abuse limits; do not become a third-party resyndication API. Safest default is same-site server-rendered data and no separate public API.
- `/my-career` — entirely local pref storage; optional noindex; offline awareness accurate. No cloud service promise.

**No candidate registration, email delivery, auto-apply, CV upload or recruitment placement** in these routes.

## 8. Original daily mission as optional experiment

One original puzzle or relevant 3-minute career challenge, selected from reviewed evergreen question bank on a date/key basis. Store optional local streak. No ads adjacent to controls; no forced return or ad clicks. Success measured by subsequent meaningful career actions, not streak counts alone. Pause if the mission consumes maintenance or harms task completion.

## 9. 14-day feasibility sampling report (required Gate 0)

Collect raw API samples under provider rate limits. Record per-day source, role, total fetched, fully paginated flag, unique job count, India explicitly allowed/not allowed/unknown, role-relevant count, unsupported on-site promises, stale/closed count, canonical apply-link pass/fail, errors and terms notes. Do NOT publish real user PII or copied full descriptions in evidence report. Produce summary by source/category and a **go/no-go** assessment; never fabricate sample counts.

**Decision:** If evidence shows very few confirmed India opportunities, reduce emphasis on “daily new matches” and position as career tools + decision support. Do not make up a magic numerical coverage threshold before baseline data exists.

## 10. Analytics / revenue test (privacy-safe)

Events: `role_selected`, `career_path_selected`, `decision_card_viewed`, `eligibility_explained`, `source_apply_clicked`, `calculator_completed`, `saved_job`, `manually_marked_applied`, `radar_opened`, `new_matches_viewed`, `local_export_used`, `mission_completed` (when live). No exact CV details, emails, salary notes or per-user employer contact in events. Measure meaningful action completion, qualified user returns, 7/30-day cohorts where privacy lawful and feasible, source link error rate, number of accurately labelled India-eligible jobs, cost and AdSense status. Attribution/analytics depend on consent settings.

**Financial model:** `monthly pageviews / 1,000 × actual page RPM`, once AdSense approved; do not claim Apply clicks pay commission unless an approved partner explicitly provides it. Compare business effort and cost to measured earned revenue, not hypothetical click counts.

## 11. Explicit test fixtures — release blocking

1. Remote role explicitly US-only: India eligibility is `explicitly_not_allowed`.
2. Remote with no allowed-country proof: `unknown`, not “Worldwide”.
3. On-site UAE role, sponsorship absent: work mode on-site abroad, sponsorship unknown.
4. Partial/failed sync: prior cache retained, never mass close.
5. Jobicy missing from bounded discovery results: not automatically closed.
6. Himalayas Apply uses exact `applicationLink`, has credit and no `JobPosting` markup/resyndication.
7. Jobicy public feed preserves canonical Jobicy link; free feed does not imply direct ATS apply.
8. Duplicate cross-provider record retains distinct rights/URLs and origins.
9. External Apply clicked: job not automatically marked “Applied”.
10. Local preferences deleted on browser reset: warning/export option; JSON import validated, delete-all works.
11. No account + offline browser: never claim personalised background email or server monitor.
12. Gross salary with no tax data: no net salary asserted.
13. No new suitable jobs: honest empty state with useful next action.
14. Unverified employer/API: cannot publish jobs. Client-supplied `published` ignored/rejected.
15. Imported feed jobs requested via recruiter API: never accessible.
16. Unavailable tool: not displayed as operational; no fake output.
17. Thin imported snippet: do not index as original SEO/ad page by default.
18. Affiliate click with no qualified sale: recorded attributable revenue remains zero.
19. New-since-last-visit is labelled as such, not “posted today”.
20. Detailed evidence citation missing: classification reverts to unknown.

## 12. Implementation / ownership boundaries

- **Gate 0:** Hosting, licences and 14-day sample; no production changes.
- **Gate 1:** Source jobs + decision cards + T01/T02/T05 + five original sourced guides; local first-use selector.
- **Gate 2:** Local Radar, manual tracker, export/import and `.ics` follow-ups.
- **Gate 3:** One optional mission/game and remaining tools based on actual demand.
- **Optional branch 2B→3B:** verified recruiter pilot, then inbound API; disabled until dedicated identity/moderation/security test gates pass.

**Definition of done:** tests, failure modes, source-policy evidence, mobile/a11y, measurable user value and simple recovery instructions exist for each shipped stage. Documentation alone never counts as implemented, tested or deployed.

## Canonical status label adapter (v1.4)

This UX document uses `explicitly_allowed` / `explicitly_not_allowed` for readable descriptions; they are NOT extra API/database values. The canonical persisted `eligible_from_in` enum, defined only in `16_DATA_AND_OPERATIONS_CONTRACT.md`, is `allowed|not_allowed|unknown`. Render the first as “Explicitly allows applicants from India”, the second as “India not eligible”, and the third as “India eligibility not confirmed”. Source evidence must be attached in every non-unknown case.

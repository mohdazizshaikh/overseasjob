#!/usr/bin/env python3
"""Portable contract and documentation smoke checks; does not test deployed product."""
from pathlib import Path
import json, re, sys, hashlib, math
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
try:
    import yaml
    from jsonschema import Draft202012Validator, FormatChecker
except ImportError as exc:
    print('Missing free developer test dependency:', exc, '\nInstall in development environment: pip install pyyaml jsonschema')
    sys.exit(2)

ROOT=Path(__file__).resolve().parent
spec=yaml.safe_load((ROOT/'08_PARTNER_JOB_POSTING_API_OPENAPI.yaml').read_text())
checks=[]
def check(name,condition):
    checks.append((name,bool(condition)))
    print(('PASS' if condition else 'FAIL')+'  '+name)

def validator(name):
    return Draft202012Validator({'$ref':f'#/components/schemas/{name}','components':spec['components']},format_checker=FormatChecker())

create=validator('JobCreate'); patch=validator('JobPatch')
fixtures=json.loads((ROOT/'18_TEST_FIXTURES.json').read_text())
check('saved API fixture valid remote',create.is_valid(fixtures['api']['create_valid_remote']))
check('saved API fixture valid onsite',create.is_valid(fixtures['api']['create_valid_onsite']))
sample={
 'external_id':'test-0001','title':'Technical Support Engineer',
 'description':'Provide customer technical support and resolve incidents using documented escalation procedures.',
 'employment_type':'full_time','work_mode':'remote','work_country':None,
 'location_text':'India remote','candidate_eligible_countries':['IN'],
 'apply_url':'https://careers.example.org/jobs/1','valid_through':'2026-12-31T23:59:59Z',
 'consent_to_publish':True,'visa_sponsorship':'unknown','relocation_support':'unknown'
}
for v in ['yes','no','unknown']:
    a=sample|{'visa_sponsorship':v,'relocation_support':v}
    check(f'create sponsorship+relocation enums {v}',create.is_valid(a))
    check(f'patch sponsorship enum {v}',patch.is_valid({'visa_sponsorship':v}))
check('reject boolean sponsorship',not create.is_valid(sample|{'visa_sponsorship':True}))
check('reject onscreen null work country',not create.is_valid(sample|{'work_mode':'onsite','work_country':None}))
check('reject hybrid null work country',not create.is_valid(sample|{'work_mode':'hybrid','work_country':None}))
check('accept onsite ISO country',create.is_valid(sample|{'work_mode':'onsite','work_country':'AE'}))
check('reject short/invalid country',not create.is_valid(sample|{'work_mode':'onsite','work_country':'ZZZ'}))
check('reject unknown example property',not create.is_valid(sample|{'country':'IN'}))
check('accept temporary employment PATCH',patch.is_valid({'employment_type':'temporary'}))
check('accept sample curl fixture',create.is_valid(sample))
# ensure doc curl uses actual fields
recruiter=(ROOT/'07_RECRUITER_LITE_AND_PARTNER_API.md').read_text()
check('curl field names current', '"work_country":null' in recruiter and '"candidate_eligible_countries"' in recruiter and '"remote_eligible_countries"' not in recruiter)
# job source rules fixed and included
source=(ROOT/'16_DATA_AND_OPERATIONS_CONTRACT.md').read_text()
for phrase in ['locationRestrictions','timezoneRestrictions','source_updated_at','Jobicy','source_published_at','first_seen_at','not automatically closed']:
    check('source invariant '+phrase, phrase in source)
# module inventory
modules=(ROOT/'15_CANONICAL_MODULE_REQUIREMENTS.md').read_text()
for i in range(18):
    check(f'module register M{i:02d}',bool(re.search(rf'\| M{i:02d} \|',modules)))
tool=(ROOT/'17_TOOL_ALGORITHMS_AND_FIXTURES.md').read_text()
for i in range(1,11):
    check(f'tool contract T{i:02d}',bool(re.search(rf'^## T{i:02d} ',tool,re.M)))
# deterministic numeric fixture tests (formulas in tool spec)
gross=120000;take=gross-(gross*.10);exp=30000+15000+5000;savings=take-exp
check('T01 take home',take==108000)
check('T01 monthly savings',savings==58000)
check('T01 savings percentage',round(savings/take*100,4)==53.7037)
check('T02 first year A',(100000-60000)*12-100000==380000)
check('T02 first year B',(80000-30000)*12==600000)
check('T04 relocation total',60000+3*40000+0.1*(60000+3*40000)==198000)
from datetime import datetime as dt
winter=dt(2026,1,15,9,0,tzinfo=timezone.utc); summer=dt(2026,7,15,9,0,tzinfo=timezone.utc)
check('T05 London winter DST',winter.astimezone(ZoneInfo('Europe/London')).hour==9)
check('T05 London summer DST',summer.astimezone(ZoneInfo('Europe/London')).hour==10)
check('T05 Kolkata half-hour offset',all(t.astimezone(ZoneInfo('Asia/Kolkata')).strftime('%H:%M')=='14:30' for t in (winter,summer)))
# docs naming/authority
readme=(ROOT/'00_READ_ME_FIRST.md').read_text()
check('readme current version',readme.startswith('# OverseasJob.in — Canonical AI-agent Project Pack v1.4'))
check('readme no old mandatory Phase 0 only', 'Authorise **Phase 0 only**' not in readme)
check('full access documented', 'full technical access' in (ROOT/'19_AGENT_AUTONOMY_AND_DELIVERY.md').read_text())
# ensure all root-specific files present, no absence in manifest
required=['00_READ_ME_FIRST.md','01_COMPLETE_PROJECT_BLUEPRINT.md','02_AI_AGENT_MASTER_PROMPT.md','03_MILESTONE_TASKS.md','04_QA_AND_LAUNCH_CHECKLIST.md','05_SOURCE_POLICY_MATRIX.csv','06_ARCHITECTURE_AND_DATABASE.md','07_RECRUITER_LITE_AND_PARTNER_API.md','08_PARTNER_JOB_POSTING_API_OPENAPI.yaml','10_DECISION_COMPANION_PRODUCT_SPEC.md','15_CANONICAL_MODULE_REQUIREMENTS.md','16_DATA_AND_OPERATIONS_CONTRACT.md','17_TOOL_ALGORITHMS_AND_FIXTURES.md','19_AGENT_AUTONOMY_AND_DELIVERY.md','20_VERIFICATION_LEDGER.md']
check('expected canonical files',all((ROOT/name).exists() for name in required))
# v1.4 deep consistency checks (document/schema tests, NOT live adapter/security tests).
source_truth=(ROOT/'00_SOURCE_OF_TRUTH.md').read_text()
check('source-of-truth physically included', (ROOT/'00_SOURCE_OF_TRUTH.md').is_file() and 'canonical source of truth is THIS VERSIONED PROJECT PACK' in source_truth)
check('README starts from authority map', '0. `00_SOURCE_OF_TRUTH.md`' in readme)
prompt=(ROOT/'02_AI_AGENT_MASTER_PROMPT.md').read_text()
for phrase in ['**Start with Phase 0 only.**','Phase 1 (only after Phase 0 approval)','do not start without explicit go-ahead','explicit Phase 2B permission','explicit Phase 3B permission']:
    check('reject obsolete agent command '+phrase[:28],phrase not in prompt)
check('AI agent full-access authority is first', '00_SOURCE_OF_TRUTH.md' in prompt and 'founder technical micro-approval is not required' in prompt)
check('Arena canonical route', '`/arena` (optional `/daily` redirect)' in modules and '`/arena`' in (ROOT/'01_COMPLETE_PROJECT_BLUEPRINT.md').read_text())
check('status enum one authority', '`allowed|not_allowed|unknown`' in modules and 'canonical persisted' in (ROOT/'10_DECISION_COMPANION_PRODUCT_SPEC.md').read_text())
check('T01 no contradictory 48.33 percent', '48.33%' not in tool)
check('SQL unknown company null', 'company_name VARCHAR(255) NULL' in (ROOT/'24_DATABASE_SCHEMA_REFERENCE.sql').read_text())
# Production worker must implement the same semantics against live provider JSON. This
# oracle only checks that saved truth-table fixtures are internally consistent.
def _country_state(value):
    if not isinstance(value,list): return 'unknown'
    codes=[]
    # Contract check only: a minimal subset of valid ISO2 fixtures; real app validates full ISO table.
    allowed_fixture_codes={'IN','US','AE','DE','GB','CA'}
    for obj in value:
        if not isinstance(obj,dict) or not isinstance(obj.get('alpha2'),str) or obj['alpha2'] not in allowed_fixture_codes: return 'unknown'
        if not isinstance(obj.get('name'),str) or not isinstance(obj.get('slug'),str): return 'unknown'
        codes.append(obj['alpha2'])
    return 'allowed' if not codes or 'IN' in codes else 'not_allowed'
def _timezone_state(value):
    if not isinstance(value,list): return 'unknown'
    offsets=[]
    for x in value:
        if not isinstance(x,str): return 'unknown'
        m=re.fullmatch(r'UTC([+-])(\d{1,2})(?::(\d{2}))?',x)
        if not m:return 'unknown'
        hh=int(m.group(2)); mm=int(m.group(3) or 0)
        if mm>=60 or hh*60+mm>14*60:return 'unknown'
        offsets.append((1 if m.group(1)=='+' else -1)*(hh*60+mm))
    return 'allowed' if not offsets or 330 in offsets else 'not_allowed'
def india_eligible(item):
    c=_country_state(item.get('country_restrictions'))
    z=_timezone_state(item.get('timezone_restrictions'))
    if 'not_allowed' in (c,z): return 'not_allowed'
    return 'allowed' if c==z=='allowed' else 'unknown'
check('provider OpenAPI truth fixtures expanded',len(fixtures.get('provider_eligibility',[]))>=18)
for i,item in enumerate(fixtures['provider_eligibility']):
    check('Himalayas official location-object+timezone-string truth '+str(i+1),item['source']=='Himalayas' and india_eligible(item)==item['expected_india'])
check('numeric offset excluded from current provider JSON',any(item.get('timezone_restrictions')==[5.5] and item.get('expected_india')=='unknown' for item in fixtures['provider_eligibility']))
check('Location object permits India with UTC+5:30',any(item.get('timezone_restrictions')==['UTC+5:30'] and item.get('expected_india')=='allowed' for item in fixtures['provider_eligibility']))
check('provider owner mandates browse offset/limit', '`offset`' in source and '`totalCount`' in source and '`nextCursor`' in source)
check('provider owner marks publication Unix ms', 'publication time in Unix milliseconds' in source and 'source_published_at' in source)
check('provider owner forbids invented per-job API', 'no documented per-job REST status URL' in source)
check('provider contract explicitly identifies Location objects', 'array of objects' in source and '`alpha2`' in source)
# Server-level constraints that JSON schema does not cover must remain release blockers.
check('reject HTTP apply URL',not create.is_valid(sample|{'apply_url':'http://careers.example.org/jobs/1'}))
check('reject arbitrary status injected',not create.is_valid(sample|{'status':'published'}))
check('reject missing consent',not create.is_valid({k:v for k,v in sample.items() if k!='consent_to_publish'}))
check('reject false consent',not create.is_valid(sample|{'consent_to_publish':False}))
check('reject salary negative',not create.is_valid(sample|{'salary_min':-1}))
check('reject email-or-script apply scheme',not create.is_valid(sample|{'apply_url':'javascript:alert(1)'}))
check('reject PATCH attempts to self publish',not patch.is_valid({'status':'published'}))
check('reject PATCH attempting origin takeover',not patch.is_valid({'origin':'provider'}))
check('reject PATCH empty mutation',not patch.is_valid({}))
check('onsite work_country required',not create.is_valid({k:v for k,v in (sample|{'work_mode':'onsite','work_country':'AE'}).items() if k!='work_country'}))
check('source response requires idempotency header',any(op.get('name')=='Idempotency-Key' and op.get('required') for op in spec['paths']['/jobs']['post']['parameters']))
check('API close scoped to owned jobs',spec['paths']['/jobs/{job_id}/close']['post']['x-required-scope']=='jobs:close')
check('API has no public provider feed listing',all(not route.startswith('/providers') for route in spec['paths']))
check('Himalayas JobPosting explicitly forbidden', 'JobPosting' in source and 'Himalayas' in source and 'Himalayas' in (ROOT/'05_SOURCE_POLICY_MATRIX.csv').read_text())
# Status must reflect evidence, not documentation-only optimism.
status=json.loads((ROOT/'module_status.json').read_text())
ids=[x.get('module_id') for x in status.get('modules',[])]
check('machine register all 18 modules once', ids==[f'M{i:02d}' for i in range(18)])
allowed_status={'specified','implemented','tested','deployed','blocked_with_reason'}
check('machine register status in contract',all(x.get('implementation_status') in allowed_status for x in status['modules']))
check('no fake app evidence in starter register',all(x['implementation_status']=='specified' and not x['tests'] and not x['evidence_paths'] and x['last_verified_at'] is None for x in status['modules']))
check('default unsafe modules still off',all(s in (ROOT/'16_DATA_AND_OPERATIONS_CONTRACT.md').read_text() for s in ['RECRUITER_LITE_ENABLED','PARTNER_POSTING_API_ENABLED','ADS_ENABLED']))
# Zip's canonical files must have a complete SHA-256 inventory; derived readable
# Word/Markdown snapshots live outside this editable directory.
manifest_file=ROOT/'13_RELEASE_MANIFEST.json'
if manifest_file.is_file():
    manifest=json.loads(manifest_file.read_text())
    manifest_entries={x['name']:x for x in manifest.get('files',[])}
    expected={x.name for x in ROOT.iterdir() if x.is_file() and x.name not in ('13_RELEASE_MANIFEST.json',)}
    check('release manifest covers all editable files',set(manifest_entries)==expected)
    for name in sorted(expected):
        file=ROOT/name; entry=manifest_entries.get(name,{})
        check('manifest sha256 '+name,entry.get('bytes')==file.stat().st_size and entry.get('sha256')==hashlib.sha256(file.read_bytes()).hexdigest())
else:
    check('release manifest exists',False)

errors=[n for n,ok in checks if not ok]
print(f'\n{len(checks)-len(errors)}/{len(checks)} checks passed; {len(errors)} failures.')
if errors:sys.exit(1)

# Milestone-by-milestone execution plan

## Gate 0 / Phase 0 — Discovery, source coverage and risk check (no deployment)

- [ ] Confirm the exact destination: domain `overseasjob.in`, DNS, existing hosting plan, PHP, MySQL, SSL, cron quotas.
- [ ] Back up anything already hosted under that domain and inventory the Git repository; do not overwrite unknown production files.
- [ ] Collect 14 days of sampled real source results for 2–3 target roles, with India explicitly eligible/ineligible/unknown counts, duplicates, incomplete pagination, apply links and source terms.
- [ ] Check current official Jobicy + Himalayas terms (permissions, attribution, apply URL, request rate, expiry, re-syndication).
- [ ] Inventory available free tools and licences; prove no paid subscriptions needed.
- [ ] Draft DB schema, sample UI, routes, tests and privacy boundaries.
- [ ] Produce architecture decision, implementation cost analysis and safe rollback.

**Gate 0:** Owner can understand the plan; no user-facing data changed, no costs introduced.

## Gate 1A / Phase 1A — Job discovery + Decision Cards

- [ ] Implement source-policy config with hard flags: source credit, canonical/apply link, allowed indexing, resyndication, TTL.
- [ ] Implement Jobicy adapter, status checks, sanitisation, paging, retry and logging.
- [ ] Implement Himalayas adapter, correct `applicationLink`, per-job checks, no `JobPosting` schema.
- [ ] Implement DB + imports as idempotent transactions; no deletion on failed/incomplete sync.
- [ ] Build `/jobs` and `/jobs/{source}/{id}` pages with location-eligibility distinction and source attribution.
- [ ] No-login role/path/country selector and Decision Cards with source-backed India eligibility evidence, salary assumptions, correct distinct dates, explainable reasons and next-action tools.
- [ ] Search/filter/pagination and accessible no-results UI.
- [ ] Test 429/5xx, malicious HTML, XSS, open redirect, source outage, job expiry, India-eligibility logic.

**Gate 1A:** Jobs are genuine from permitted sources, properly credited, and correct links work. No scraping.

## Gate 1B / Phase 1B — Core utility experience

- [ ] T01 salary vs living expenses: no fake live data, clear gross/net and user FX.
- [ ] T02 offer comparison: annualisation, guaranteed/conditional compensation, assumptions.
- [ ] T05 timezone overlap: real IANA zones and DST transition tests.
- [ ] Publish accessible responsive landing page, tool index and shared design system.
- [ ] Publish five substantive sourced guides; privacy, terms, contact, safety and About.
- [ ] Search Console readiness and sitemap; noindex feed-only job pages by default.
- [ ] Test print/exports, no-PII server logging, speed and keyboard navigation.

**Gate 1B:** A visitor who never applies for a job still completes valuable tasks.

## Gate 2 / Phase 2 — Local Radar, tracker, utility depth and monetisation readiness

- [ ] T03 resume & cover letter kit (local editing and printable export).
- [ ] T04 relocation budget planner (user-supplied assumptions).
- [ ] Browser-local Opportunity Radar: match on visit, new-since-last-visit vs newly published, evidence explanations and honest empty states.
- [ ] T06 local-first application tracker (CSV/JSON export-import, manual status, .ics reminders and delete).
- [ ] No account and no offline email/push promise; public cron and local profile have separate boundaries.
- [ ] Error dashboard, log retention, backups and restore drill.
- [ ] Review originality and ad placements; apply for AdSense only when appropriate.
- [ ] Monitor actual impressions, core utility usage and return rate.

**Gate 2:** Original utility value is clear, source import is stable, ads safe if approved.

## Gate 3 / Phase 3 — Optional engagement experiment and demand-led capabilities

- [ ] T07 no-cost text interview practice.
- [ ] T08 dated official country checklist.
- [ ] One original simple daily puzzle with optional local streak.
- [ ] T09 browser-only WorkProof static portfolio export.
- [ ] T10 curated role-based roadmap builder.
- [ ] Validate game usage and tool conversions, avoid ad-heavy game controls.

**Gate 3:** Pilot one original mission/game and remaining tools only if users demand them; actual task completion/retention measured, no automatic requirement to ship all ten now.

## Optional branch Gate 2B — Verified recruiter pilot (separate go/no-go)

- [ ] Feature flag `RECRUITER_LITE_ENABLED=false` by default; verify safe rollback.
- [ ] Recruiter accounts, email confirmation, company/domain verification and scope-based roles.
- [ ] Basic company profile and job create/edit/close forms; employer-owned HTTPS apply link.
- [ ] Validate work model/country/visa claims, expiry, description sanitisation and origin labels.
- [ ] First employer posting requires review, suspicious jobs quarantined; mandatory verified-human trust review (not founder code review).
- [ ] Rate limiting, duplicate and phishing protections, immediate account/job suspension.
- [ ] Test admin moderation and daily digest; manual review workload acceptable for solo founder.

**Gate 2B:** Requires successful documented trust checks and evidence of 3–5 actual legitimate pilot employers; this is not per-commit founder permission. Trust, security and resource limits are proven. **Do not activate if verification/abuse work cannot be sustained.**

## Optional branch Gate 3B — Inbound API for verified employers / ATS only

- [ ] Feature flag `PARTNER_POSTING_API_ENABLED=false` by default.
- [ ] Implement draft OpenAPI 3.1 contract in `08_PARTNER_JOB_POSTING_API_OPENAPI.yaml`.
- [ ] Scope API tokens to one verified organisation; hash/rotate/revoke; one-time reveal only.
- [ ] Implement POST/GET/PATCH/close, idempotency, pagination and `429 Retry-After`.
- [ ] Test cross-tenant requests, privilege escalation, malicious URLs, token leaks and status bypass.
- [ ] Ensure partner API never exports 3rd-party provider jobs; only caller-owned jobs returned.
- [ ] Publish `/developers` only after contract and security tests pass.

**Gate 3B:** API is safe for a 3–5 employer pilot on existing infrastructure, and operational burden is measured. Keep disabled otherwise.

## Phase 4 — only after real traffic and approvals

- [ ] Apply to qualifying job publisher/affiliate programs; retain signed/accepted terms.
- [ ] Add partner adapters one-by-one only after permissions verified and tested.
- [ ] Expand original guide categories based on actual Search Console demand.
- [ ] Consider opt-in cloud sync only if genuine user demand and privacy resources exist.

**Gate 4:** No full employer ATS, recruiting placement agency, payments, or mandatory job-seeker login. Recruiter Lite/API require separate gates, not blanket approval.

---
## v1.4 execution note (binding; supersedes older founder micro-approval wording)

This plan's stages are **automated engineering quality gates**, not demands for founder technical approval per stage. The AI agent has full technical access and may progress independently after tests, backups and policy checks. Business/licence/paid-service decisions that cannot be inferred are recorded as blockers for the affected integration only. Do not ask the owner to code or audit a pull request. Use `15_*` through `20_*` and `23_VALIDATE_SPEC.py` as source of truth for all modules and completion evidence.

# v1.4.1 Verification and Residual-Risk Ledger

**Status date:** 2026-11-23. This ledger distinguishes corrected *documentation* from unproven implementation.

| Item | Documentation check | Deployment/real-world status |
|---|---|---|
| 18 modules M00–M17 named and release-specified | Included in 15 | No code/live inventory reviewed |
| T01–T10 calculation/validation contracts | Included in 17 | No runnable website tests yet |
| Recruiter OpenAPI schema syntax and example | Run 23_VALIDATE_SPEC.py | No deployed endpoint, identity workflow or tenant tests |
| Visa sponsorship `yes/no/unknown` | Fixed in OpenAPI and prose | Need server validation |
| On-site work country non-null | Fixed in create schema; PATCH requires full state validation | Need server tests |
| Himalayas JSON API `pubDate` as original publication time | Specified and externally corroborated | Need live adapter fixtures |
| Himalayas Location object + string timezone eligibility | Specified and externally corroborated | Need live adapter behaviour |
| Jobicy bounded feed disappearance ≠ closed | Specified and externally corroborated | Need observed feed reconciliation |
| Source licensing | Current docs consulted; rights matrix retained | Must revalidate before public activation |
| Hiring-side direct employer supply | Optional guarded source | No employers contracted, trust verification unproved |
| Five original public guides | Content requirements only | MUST author, source and review |
| Game question bank, resume layouts, role roadmaps | Requirements and fixtures | Original assets MUST be authored |
| Hostinger PHP/cron and backups | Architecture conditional on actual plan | Host inspection REQUIRED |
| Monetisation and ₹50,000/month | Revenue mathematics defined | Actual AdSense/affiliate approval and traffic UNKNOWN |
| Analytics privacy/consent | Behaviour defined | Legal/configuration review REQUIRED |
| Source code and deployed website | Not included in this documentation pack | NOT VERIFIED |

**Residual risks not eliminable by more writing:** external provider terms/rate limits may change; daily job count cannot be known without running real samples; on-site overseas-job supply not secured; recruiter verification takes human judgement; Google traffic/AdSense approval and income are not guaranteed. The agent must measure and report, not silently fill assumptions.

**Docs check result:** passing automatic document/schema checks only means files and selected contracts are internally consistent; it does NOT prove all conceivable logic bugs have been excluded. New contract changes require extending test fixtures and report.

**Out-of-scope certification:** Documentation syntax/fixture passes do not certify legal immigration claims, actual employer identities, paid API availability, live source permissions, every JavaScript calculation or production migrations. Agents need implementation-based evidence per module.

## v1.4 doc-only release addendum (2026-11-23)

`00_SOURCE_OF_TRUTH.md` is now physically inside the canonical pack. `module_status.json` lists 18 modules with `specified` status only. `25_DOCUMENT_AUDIT.md` records stale instructions, route/status/fixture/SQL corrections, and external blockers. Updated validator result is written to `26_VALIDATION_RESULTS.txt`. This is documentation/fixture evidence only. There are **zero** confirmed app implementations, end-to-end tests or deployment results associated with this pack. The source licence page reads do not establish 14-day supply coverage or an authorised production configuration.

## v1.4.1 source compatibility correction and GitHub discovery — 2026-11-23

Linked GitHub repository `mohdazizshaikh/overseasjob` exists and has a PHP development application, module ledger and CI evidence according to read-only GitHub connector inspection; its README reports release v0.9.15 on the current main branch. Do **not** treat this starter doc pack's specified-only statuses as evidence that the repository contains no code. Actual current Hostinger files, database, private permission attestation, CI outcome for the latest commit and public deployment were not verified. Repo v0.9.15 supports official browse pagination/pubDate but carries numeric-timezone and string-location *comments/fixtures*, which need exact upstream OpenAPI regression tests before enabling any provider. Reference `27_GITHUB_IMPLEMENTATION_RECONCILIATION.md`.

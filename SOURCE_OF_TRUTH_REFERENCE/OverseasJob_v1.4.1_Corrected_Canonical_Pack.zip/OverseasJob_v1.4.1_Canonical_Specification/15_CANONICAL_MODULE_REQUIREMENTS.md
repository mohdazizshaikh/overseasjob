# v1.4 Canonical Product Module Contracts

**Status:** normative specification; NOT implemented. **Priority:** correct behaviour > completeness of marketing pages > job count. Every feature must have a real empty/error state; no fake demos on public pages.

## Module register (canonical, no feature omitted silently)

| ID | Module | Mandatory release | UI/routes | Backend/data | Definition of done |
|---|---|---|---|---|---|
| M00 | Hosting/deployment/config & backup | Gate 0 | admin-only status | existing hosting, cron, DB, secrets, backups | host limits evidenced; rollback/restore proven |
| M01 | Provider licences, adapters & ingestion | Gate 1 | source credit/status | Jobicy + optional Himalayas permitted fetch, validation, caching | sample jobs pass source-specific fixtures |
| M02 | Normalised job catalogue | Gate 1 | `/jobs`, detail routes | provenance, source rights, stable IDs, expiry | filters accurate; no cross-source licence leak |
| M03 | Search + eligibility engine | Gate 1 | search/filter/empty states | location AND timezone; known vs unknown | IN truth table fixtures pass |
| M04 | Job Decision Cards | Gate 1 | card/detail, evidence disclosure | normalised evidence, dates, salaries | every claim traceable; unknown shown |
| M05 | 10 free utilities T01..T10 | T01/T02/T05 Gate1; others Gate2/3 | `/tools/*` | browser JS; assets as noted in 17 | all ten have tests before being labelled live |
| M06 | Original guidance, SEO and source safety | Gate 1 | `/guides/*`, `/report-job`, help | reviewed content, attribution; moderation of reports | five genuine guides + support/safety pages exist |
| M07 | Opportunity Radar, local profile, save/track | Gate 2 | `/my-career` | browser local versioned data, matching on visit | import/export and changed-job fixtures pass |
| M08 | Daily Career Mission / Arena | Gate 3 optional | `/arena` (optional `/daily` redirect) | pre-reviewed offline question bank, local streak | daily rotation reproducible, no paid API |
| M09 | Analytics and monetisation | Gate 1 hooks; ads after approval | disclosures and non-invasive ads | privacy-consented events; policy-safe ad slots | no invented revenue; AdSense off by default |
| M10 | Trust reporting, incident and takedown | Gate 1 minimum | Report issue, contact | bounded reports, action log, quarantine | phishing link report can result in safe suppression |
| M11 | Monitoring, backups, operations | Gate 1 | simple admin health view | cron run logs, alert, retry, backup/restore | simulated source outage leaves useful site |
| M12 | Recruiter identity and company accounts | 2B gated | `/employers/*` | email verification, org proof, role scopes | invalid/unverified org cannot publish |
| M13 | Direct job posting + org dashboard | 2B gated | create/edit/close; company page | review, consent, expiry, URL safety | first job held pending review |
| M14 | Inbound partner/ATS Job Posting API | 3B gated | `/developers` when ready | OpenAPI, token, idempotency, tenant isolation | contract/security tests pass |
| M15 | Privacy/consent/export/deletion | Gate 1 core; extend 2B | privacy/terms/consent | cookie controls; local delete; org PII deletion | consent and deletion paths tested |
| M16 | Accessibility/performance/test harness | Every gate | keyboard/mobile/print | CI tests + reports | WCAG review, speed measured, no broken routes |
| M17 | Source/traffic/business feasibility | Gate 0 and ongoing | transparent category labels | 14-day sample + weekly metrics | no job-supply / revenue claims without evidence |

**No missing mandatory module via omission:** all M00–M17 must be either `specified`, `implemented`, `tested`, `deployed`, or `blocked_with_reason` in a machine-readable progress log. A future-gated module counts as specified, not completed or live.

## End-to-end candidate journey, with negative paths

1. Arrive on home → choose role + `remote_from_india | remote_other | onsite_abroad`, optional country. No account required; works even with localStorage disabled (session only).
2. Backend returns only current allowed-source jobs; filter and present real matches or `No confirmed matches` with useful tool/guide link. No false “new today” count.
3. Job card explains `why matched`, source, evidence grade, verified vs unknown eligibility (not “verified employer”), actual last source check and source-updated timestamp separately.
4. Decision view: user can open appropriate salary/offer calculator with *only observed* salary/location prefilled and assumptions marked as needing input. Show how to verify job source and avoid scams.
5. `Apply at source` opens only licensed canonical/approved application URL in safe tab; do not report an application success or collect a CV.
6. `Save` local-only; `Mark applied` requires deliberate user action. Follow-up date can export `.ics`; no promise of background notifications.
7. On next visit, Radar compares stable provider job IDs/versions from local browser storage against latest safe cached listing snapshot; `new to you` never conflated with `newly published`.
8. On API outage, show cached last-checked information only if policy freshness allows, else hide job and suggest tools. Missing from a time-bounded feed is **not automatically closed**.
9. If browser storage cleared, show data-loss warning and JSON import option; users can delete all local data at any time. All imports have caps and validation.

## Recruiter journey, not a staffing agency

1. Employer registers, verifies email, claims org/domain and submits corporate identity/authority as allowed by local law. Apply URLs must be HTTPS hostnames controlled by company or approved ATS; no short links and no posting to applicant-fee forms.
2. User cannot grant self `verified_org` role. Early new organisations reviewed; overseas agency/relocation claims require extra legal/trust screening. Legitimate employers only, not candidates, may post.
3. Form and API create jobs as `pending_review`, with unique org-scoped `external_id`, terms consent recorded with version/time/actor; unverified org has no write token.
4. Reviewer accepts/rejects with reason. Org may edit/close its own job, but sensitive edits return to review. Published jobs inherit correct `origin=direct_employer` rights and a distinct label.
5. Cron hides expired jobs; recruiter can close immediately; org suspension hides all its jobs and disables keys. Dashboard counts views/clicks aggregated without collecting applicant identity.
6. Repeated errors or founder moderation capacity exhaustion: freeze new company registrations and posting submissions; existing legitimate candidates can keep using the site.

## UI complete-screen inventory

Public: homepage, job search/results, individual job view and evidence, related tools, tool index, ten tool pages, country/guide index and details, fraud/safety page, contact, about, privacy, terms, disclosure, report issue, My Career/Radar, daily mission. Recruiter (only if enabled): welcome/FAQ, register/confirm, pending-verification state, login/reset, organisation profile, job table, job form, job status/review reason, API key issuance/revocation, API docs. Owner: health/last sync/backups, incident report queue, source disable/reenable, employer/organisation review and suspension. Every screen needs empty, error, loading, mobile, keyboard and no-JS fallback where meaningful.

## Source/role priority rules

- `remote_from_india` only means employer's remote-location + timezone restrictions allow India **with cited source fields**. Visa rules are outside this inference.
- `onsite_abroad` requires verified physical work country and on-site/relocation type; sponsorship is separately yes/no/unknown. If no feed provides these jobs, show zero and explanatory guidance rather than mislabel remote roles.
- Confidence is explicit evidence category, not invented 97% match or employer trust score. Free-text role similarity cannot override country ineligibility.
- Local Radar scores role text and location only after mandatory eligibility gates; show the fields that matched; no paid model needed.

## Test coverage & gates

Gate 0: licensed source, actual source response/pagination test, 14-day sample with counts and ratios (may run over time; no fabricated retrospective data), verified hosting and budget. Gate 1: contracts M01–M06, M09–M11, M15–M17 with automated/browser tests, security and backups. Gate 2: M07 and remaining T03/T04/T06; Gate3: T07–T10 + optional M08; gated 2B/3B add M12–M14. Default `RECRUITER_LITE_ENABLED=false`, `PARTNER_POSTING_API_ENABLED=false`, `ADS_ENABLED=false` until justified.

## What is intentionally NOT in the platform

No candidate CV database, passport collection, automatic job applications, applicant-status scraping, paid AI API, employer applicant-tracking system, recruitment/placement service, hidden candidate fees, uncontrolled web scraping, unlicensed outgoing job API, fictional vacancies, guaranteed salary/tax/visa outcomes, or guaranteed ₹50,000/month. These are explicit non-goals rather than missing modules.

## Route and state cross-contract normalization (v1.4)

- Original Daily Arena destination is `/arena`, as registered in the project blueprint. `/daily` MUST NOT serve a divergent standalone experience; if an old link exists it redirects permanently to `/arena` and inherits indexing policy. No broken menu link while M08 is disabled.
- Persist the canonical JobView and database state as `allowed|not_allowed|unknown` (per `16_*`). UI copy may present `explicitly allowed`, `explicitly not allowed`, `unknown` only as human-facing labels; no second competing enum goes into APIs or persisted data.
- Accepted remote-from-India matching requires BOTH geography and timezone permission for Himalayas, with actual evidence. With missing/invalid fields use unknown; it cannot pass a strict allowed-only filter.
- `module_status.json` is a starter inventory, not evidence of implementation. The execution agent creates a fresh evidence log inside the actual code repository.

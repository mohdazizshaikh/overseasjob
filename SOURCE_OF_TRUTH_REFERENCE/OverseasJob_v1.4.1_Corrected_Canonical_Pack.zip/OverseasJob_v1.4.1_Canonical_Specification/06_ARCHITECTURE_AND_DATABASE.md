# OverseasJob.in — Developer Architecture & Database Reference

**Status:** Historical architecture explanation, not deployed code. Proposed sample SQL in this file is NON-NORMATIVE and MUST NOT be used as a production migration. Use canonical schema in `24_DATABASE_SCHEMA_REFERENCE.sql` and `16_DATA_AND_OPERATIONS_CONTRACT.md`, after checking actual hosting.

## 1. Design decision

Preferred (if supported by existing hosting): PHP 8.2+ / MySQL or MariaDB, no paid framework, accessible HTML/CSS and vanilla JS. Server-rendered original content pages. Two scheduled feed adapters. Future optional employer job submission and invite-only partner API must use the same safe PHP/MySQL architecture, disabled until verification and moderation gates pass. No always-on worker, no mandatory cloud queue. No direct public browser-to-provider calls per visit.

```
[Jobicy REST API] --\
                     --> [scheduled sync] --> [schema validation]
[Himalayas API] ----/           |                  |
                                v                  v
                         [retry/quotas]      [normalized DB]
                                                   |
                                [PHP job search + source-specific Apply]
                                                   |
                                       [public site visitor]

[Browser-only Decision/Radar + tools + game + tracker] --> [local browser storage/export]
[Reviewed original content] --------> [static/server-rendered pages]
[Admin read-only health] <----------- [sync runs / error summary]

[Verified company] -> [Recruiter Lite website] --\
                                             -> [posting validation, review, expiry] -> [owned-job records] -> [public job search]
[Approved ATS] ----> [scoped REST POST/PATCH] /
(No API export of third-party imported jobs)
```

## 2. Suggested directory structure

```
overseasjob/                  # canonical repository root
  app/
    Controller/
      JobsController.php
      ToolsController.php
    Service/
      JobImportService.php
      ProviderPolicy.php
      JobStatusService.php
      UrlSafety.php
    Provider/
      JobicyAdapter.php
      HimalayasAdapter.php
    Repository/
      JobRepository.php
  config/
    providers.php
    app.example.php
  content/
    countries/
    guides/
  cron/
    sync_jobicy.php
    sync_himalayas.php
    refresh_status.php
    health_report.php
  public/
    index.php
    assets/
      css/site.css
      js/tools/
      js/tracker.js
      js/arena.js
  migrations/
  tests/
    integration/
    unit/
    security/
  docs/
  .env.example
  README.md
```

Note: The public web root must be `public/` or configured to deny direct access to config, migrations, cron and app secrets.

## 3. Example SQL (illustrative; not production-reviewed)

```sql
CREATE TABLE providers (
  id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  slug VARCHAR(64) NOT NULL UNIQUE,
  name VARCHAR(128) NOT NULL,
  policy_url VARCHAR(500) NOT NULL,
  terms_checked_at DATETIME NULL,
  enabled BOOLEAN NOT NULL DEFAULT FALSE,
  source_credit_label VARCHAR(120) NOT NULL,
  apply_url_field VARCHAR(64) NOT NULL,
  allow_jobposting_schema BOOLEAN NOT NULL DEFAULT FALSE,
  restrict_resyndication BOOLEAN NOT NULL DEFAULT TRUE,
  sync_interval_minutes INT NOT NULL DEFAULT 720,
  last_success_at DATETIME NULL,
  last_error_at DATETIME NULL
);

CREATE TABLE jobs (
  id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  provider_id INT UNSIGNED NOT NULL,
  provider_job_id VARCHAR(255) NOT NULL,
  provider_original_url VARCHAR(1800) NOT NULL,
  provider_apply_url VARCHAR(1800) NOT NULL,
  title VARCHAR(300) NOT NULL,
  company_name VARCHAR(255) NULL,
  role_category VARCHAR(90) NULL,
  employment_type VARCHAR(60) NULL,
  remote_type VARCHAR(40) NOT NULL DEFAULT 'unknown',
  india_eligible_state ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  relocation_state ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  sponsorship_state ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  eligibility_regions_json JSON NULL,
  location_label VARCHAR(255) NULL,
  salary_min DECIMAL(16,2) NULL,
  salary_max DECIMAL(16,2) NULL,
  salary_currency VARCHAR(8) NULL,
  salary_period VARCHAR(30) NULL,
  description_sanitized MEDIUMTEXT NULL,
  published_at DATETIME NULL,
  expires_at DATETIME NULL,
  last_seen_at DATETIME NULL,
  last_verified_at DATETIME NULL,
  status ENUM('active','closed','stale','unknown') NOT NULL DEFAULT 'unknown',
  content_hash VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_provider_job (provider_id, provider_job_id),
  INDEX idx_status_published (status, published_at),
  INDEX idx_india_eligible (india_eligible_state),
  CONSTRAINT fk_jobs_provider FOREIGN KEY (provider_id) REFERENCES providers(id)
);

CREATE TABLE sync_runs (
  id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  provider_id INT UNSIGNED NOT NULL,
  started_at DATETIME NOT NULL,
  ended_at DATETIME NULL,
  outcome ENUM('running','success','partial','failed') NOT NULL DEFAULT 'running',
  pages_fetched INT NOT NULL DEFAULT 0,
  fetched_count INT NOT NULL DEFAULT 0,
  imported_count INT NOT NULL DEFAULT 0,
  updated_count INT NOT NULL DEFAULT 0,
  error_count INT NOT NULL DEFAULT 0,
  error_summary VARCHAR(1000) NULL,
  CONSTRAINT fk_sync_provider FOREIGN KEY (provider_id) REFERENCES providers(id)
);
```

**Schema caution:** JSON type and timestamp semantics need verification against the live DB engine/version, and unique IDs/content mappings must follow real provider response formats.

## 4. Source policy configuration — example only

```json
{
  "jobicy": {
    "enabled": true,
    "sourceCredit": "Jobicy",
    "applyUrlField": "url",
    "allowJobPostingSchema": false,
    "minSyncMinutes": 720,
    "notes": "Always preserve canonical Jobicy URL; do not equate 7-day feed absence with expiry"
  },
  "himalayas": {
    "enabled": true,
    "sourceCredit": "Himalayas",
    "applyUrlField": "applicationLink",
    "allowJobPostingSchema": false,
    "allowRedistribution": false,
    "minSyncMinutes": 1440,
    "notes": "Apply uses applicationLink exactly; cannot push to Google Jobs or other aggregators"
  }
}
```

**Important:** All source rules are subject to live re-verification. Example configuration is not a legal licence.

## 5. Import pseudocode

```
for each enabled_provider_due_for_sync:
    assert_source_policy_recently_checked()
    try:
        acquire_lock(provider)
        pages = fetch_complete_pagination_under_rate_limits(provider)
        normalized = validate_and_sanitize(pages)
        start_database_transaction()
        upsert_valid_jobs(normalized)
        record_successful_sync_metadata()
        commit()
    except RateLimit:
        schedule_retry_after_header()
        preserve_last_healthy_data()
    except AnyError:
        rollback()
        preserve_last_healthy_data()
        log_redacted_error()
    finally:
        release_lock(provider)

# Separate routine: mark CLOSED only on reliable provider closure/expiry
# Never assume 'not in recent Jobicy feed' equals closed
```

## 6. Search and source redirects

- `/jobs` should query local indexed database, not hit external API.
- Detail pages show original source, last verified and eligibility caveats.
- Outbound links must be `https:` and match a source-specific validated destination from stored records.
- Do not route all applications through tracking links that rewrite the partner's required apply URL.
- Log only coarse anonymised outbound events if tracking is legally configured; no personal identity profiling.

## 7. Hosting checklist

- Actual PHP version, extensions (`curl`, `pdo_mysql`, `intl`), MySQL version, writable cache/log locations.
- Cron command invocation, schedule limits, 1st-run log, locks, timeouts and quota.
- Real DB/asset storage and backup quotas.
- HTTPS certificate + renewal, DNS, mail credentials only if needed for critical alerts.
- Staging or safe preview URL before public deploy.
- Ability to disable source quickly with config flag.
- Restore DB from backup in a test environment before launch.

## 8. Versioning / release process

- Every deploy gets a numbered version and changelog.
- Schema migrations are reversible where feasible; back up before migrations.
- CI runs unit/contract/security tests, including provider apply link requirements and No-JobPosting restriction.
- No secrets committed to Git.
- After production deploy, run smoke tests for homepage, jobs, tools, HTTPS, cron and outbound apply.
- Keep a known-good rollback copy.

## 9. v1.2 — Employer/partner API storage extension (future gated phase; NOT deployed)

**Important:** The core MVP has no employer accounts. These tables and endpoints are a **proposal** for Phases 2B/3B only and must remain disabled until reviewed. The existing `jobs.provider_id` model can represent a special `DirectEmployer` origin only with explicit source flags and owner IDs. Keep provider-feed records non-exportable.

```sql
-- Simplified schema proposal; add after testing migrations on the actual DB engine.
CREATE TABLE organizations (
  id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  verified_domain VARCHAR(255) NULL,
  verification_status ENUM('pending','verified','rejected','suspended') NOT NULL DEFAULT 'pending',
  api_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE org_members (
  id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id BIGINT UNSIGNED NOT NULL,
  email VARCHAR(320) NOT NULL,
  password_hash VARCHAR(255) NULL,
  role ENUM('owner','editor','viewer') NOT NULL DEFAULT 'viewer',
  email_verified_at DATETIME NULL,
  UNIQUE KEY org_email (org_id,email),
  FOREIGN KEY (org_id) REFERENCES organizations(id)
);

CREATE TABLE partner_api_keys (
  id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id BIGINT UNSIGNED NOT NULL,
  key_hash CHAR(64) NOT NULL UNIQUE,
  key_prefix VARCHAR(24) NOT NULL,
  scopes_json JSON NOT NULL,
  expires_at DATETIME NULL,
  revoked_at DATETIME NULL,
  last_used_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (org_id) REFERENCES organizations(id)
);

CREATE TABLE employer_jobs (
  id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id BIGINT UNSIGNED NOT NULL,
  external_id VARCHAR(160) NOT NULL,
  title VARCHAR(250) NOT NULL,
  description_sanitized MEDIUMTEXT NOT NULL,
  employment_type VARCHAR(30) NOT NULL,
  work_mode VARCHAR(30) NOT NULL,
  country CHAR(2) NOT NULL,
  location_text VARCHAR(255) NOT NULL,
  eligibility_json JSON NULL,
  salary_json JSON NULL,
  apply_url VARCHAR(1800) NOT NULL,
  valid_through DATETIME NOT NULL,
  visa_sponsorship ENUM('yes','no','unknown') NOT NULL DEFAULT 'unknown',
  distribution_consent BOOLEAN NOT NULL DEFAULT FALSE,
  moderation_status ENUM('draft','pending_review','published','closed','expired','rejected','suspended') NOT NULL DEFAULT 'pending_review',
  published_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY org_external (org_id,external_id),
  INDEX idx_public (moderation_status,valid_through),
  FOREIGN KEY (org_id) REFERENCES organizations(id)
);

CREATE TABLE posting_idempotency (
  org_id BIGINT UNSIGNED NOT NULL,
  idem_key VARCHAR(128) NOT NULL,
  payload_hash CHAR(64) NOT NULL,
  response_json JSON NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(org_id,idem_key)
);

CREATE TABLE employer_audit_events (
  id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id BIGINT UNSIGNED NOT NULL,
  actor_type VARCHAR(30) NOT NULL,
  actor_id VARCHAR(80) NOT NULL,
  job_id BIGINT UNSIGNED NULL,
  event_name VARCHAR(80) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_org_audit (org_id,created_at)
);
```

Use a source-specific search view/service that merges employer_jobs with feed jobs **for display only** and never accidentally exports third-party feed jobs through employer APIs. Add a `source_origin` label and explicit `allow_partner_export=false` default on all feed records. Owner and moderator must be server-derived, never trusted from client JSON.

**Route structure:** `app/Controller/EmployerController.php`, `app/Controller/PartnerApiController.php`, `app/Service/EmployerVerification.php`, `app/Service/ApiKeyService.php`, `app/Service/PostingModeration.php`, `cron/expire_employer_jobs.php`, `public/developers` (docs only after live). Add explicit routing and test modules rather than exposing arbitrary database CRUD.

**Security design:** API bearer credentials are **not** authentication for human login. Hash service keys with a keyed or appropriate one-way representation, enforce access-scoped SQL predicates (`WHERE org_id = :caller_org_id`), audit modifications, redact secrets, throttle by token/org/IP, and use UTC expiry. Passwords, if password auth selected, require a current password KDF and protected recovery; prefer proven, lightweight managed implementation within existing free hosting limits. Do not assume SMTP/email verification is free/available without checking.

**Partner API operations:** See `08_PARTNER_JOB_POSTING_API_OPENAPI.yaml` for draft routes/schema and `07_RECRUITER_LITE_AND_PARTNER_API.md` for identity/abuse/launch gates. API works **inbound** only; external imported listings have separate licences and must not be disclosed as export inventory.


## 10. v1.2 canonical public JobView and source-rights enforcement (design contract)

**Existing illustrative SQL in §3 and §9 is NOT a production-ready unified migration.** Create actual migration code only after verified PHP/MySQL version and load tests; maintain a normalized **public JobView** assembled server-side with one explicit provider-to-view mapping and one employer-to-view mapping. Every record MUST include:

`public_id, origin_type(provider|direct_employer|licensed_partner), owner_org_id(nullable), source_policy_id, provider_id(nullable), source_job_id, provider_original_url, apply_url, attribution_label, public_status, title, company_name, work_mode, work_country, employer_country, candidate_eligible_countries, eligibility_state(allowed|not_allowed|unknown), eligibility_evidence_url, eligibility_evidence_note, visa_sponsorship_state, disclosed_salary_basis, published_at, first_seen_at, last_seen_at, last_checked_at, status_checked_at, expires_at, allow_public_render, allow_index, allow_jobposting_markup, allow_sitemap, allow_partner_export`.

Per-provider jobs have `origin_type=provider`, `owner_org_id=NULL`, `allow_partner_export=false` always. Employer jobs have `origin_type=direct_employer`, `owner_org_id` non-null and must be verified, moderated `published`, not expired; default no partner export without recorded employer consent. Public source-licence flags are checked on EACH DB query/render/index/schema/export path, not only at ingestion. Partner routes must fetch solely `employer_jobs WHERE org_id=:authenticated_org_id`, never `JobView` or `provider_jobs`.

**State mapping:** `provider active/verified` maps to public `available_verified` only on authoritative evidence; `active but unconfirmed` to `available_unverified`; stale to `stale_unknown`; `provider closed/expired` to hidden. Employer `published` maps to visible `available_verified` for *listing state only*, **not** employer trust/visa. Employer `pending_review/draft/rejected/suspended/closed/expired` is not publicly searchable. Unknown stale state must not be called newly posted.

**Source date contract:** `published_at` source-owned; `first_seen_at` immutable; `last_seen_at` updated on complete successful traversal; `last_checked_at` attempted check; `status_checked_at` authoritative status response only. Never mass-close on partial feeds or recent-window disappearance. UTC timestamps stored/emitted as ISO 8601 with Z. A job with no explicit expiry may be hidden after source-specific conservative stale TTL, but not labelled closed without evidence; tune TTL during Gate 0 and record source-specific rules in policy config.

**Source policy fields (deny by default):** `allow_public_render=false`, `allow_index=false`, `allow_jobposting_markup=false`, `allow_sitemap=false`, `allow_partner_export=false`, `apply_link_mode=source_required`, `allow_ads_on_page=false_until_publisher_check`, `require_attribution=true`. Add tests per origin/provider. Permission to render imported data is not permission to syndicate externally or put Google Ads on thin replicated pages.

## 11. v1.2 candidate private state and background boundary

No candidate DB, registration or email in Gate 1/2. Browser `career_profile` and `seen_jobs` are **local only**. On visit, client sends ordinary search filters and compares resulting job stable ID/version with local last-seen metadata; it does not send CVs or applicant history to server. Import/export uses capped, validated JSON; no unsafe HTML injection, private analytics or URL-param leakage. `.ics` follow-ups are generated from local data. The server's cron only refreshes PUBLIC available jobs, not offline personal profiles. Add accounts/consented delivery as a separate future ADR only if users request it and actual free infrastructure permits it.

## 12. Recruiter Lite/API implementation decisions needed before optional Gate 2B/3B

### Human auth and company identity

Choose a proven password+session-cookie flow compatible with hosting (e.g. Argon2id where supported), HTTPS-only Secure/HttpOnly/SameSite cookies, server-side session revocation, CSRF protection, login throttling, email verification from an owned sender and safe password reset. Human sessions and opaque service API tokens are separate. Invite-only company pilot: validate business website/domain and authority to post; email alone is never a verified-employer badge. Keep minimal evidence references plus reviewer/action dates, do not collect identity scans unnecessarily. Deferral mandatory if SMTP/recovery cannot be delivered safely within budget.

### Source of truth / organisation roles

`owner`: admin membership, token issuance and job management; `editor`: create/edit/close own jobs, no token issuance; `viewer`: read analytics. All API requests bind `org_id` from authenticated token, NEVER from supplied payload. Cross-org identifiers 404/403 per non-disclosure policy; all mutating actions audit actor, org, revision and timestamp. Organisation closure disables keys immediately, unpublishes owned jobs and retains only bounded compliance/audit evidence.

### Direct job contract / state machine

Post creates `pending_review` (HTTP 201), with external_id unique within org, idempotent request key scoped to org and body hash. `draft → pending_review → published` only by authorised reviewer, edits to material fields cause `published → pending_review` (job temporarily hidden), close from any owned active state is immediate `closed`; expiry is terminal unless a new reviewed revision explicitly approved. No partner may set verified/published via PATCH. Use `revision`/optimistic concurrency `If-Match` for material edits; document `409` on stale revision. Store `consent_to_publish=true` with legal-text version, org, actor and UTC time; store `distribution_consent` separately (default false) and revalidate on material changes. Define worker-owned fields, accepted ISO 3166-1 alpha-2 countries and ISO 4217 currency, amount ranges and HTTPS domain and redirect constraints.

### Third-party apply URL protection

Only HTTPS employer-owned or authorised ATS domains after domain evidence; reject shortening/open redirects, embedded credentials, private IP/reserved ranges where URL probing is performed, suspicious DNS changes and looped cross-host redirects; **do not** fetch arbitrary URLs server-side to avoid SSRF. Verify host control manually during pilot. Automatic checks reduce risk, cannot guarantee authenticity. High-risk overseas recruiting must remain on hold pending applicable legal review.

### Idempotency, metrics, moderation and retention

Atomic transaction: `(org_id, idempotency_key)` payload hash and job creation/replay response recorded together; identical retries return equivalent result, different body returns `409`. Define expiry for idempotency records (e.g., 7 days as a policy decision), use UTC and clean via cron. Basic `job_metrics_daily` only aggregated unique-ish bot-filtered views/clicks with no applicant PII; otherwise defer recruiter analytics. Define bounded retention policies for verified company evidence, applicant-free jobs, logs and reports based on legal review; implement owner deletion/offboarding and token revoke. In pilot cap at **5 orgs, 10 new jobs/day/org and 2 review items/day founder capacity** as adjustable *operational stop rules*; if queue exceeds capacity, automatically pause onboarding and posting, not auto-publish. First jobs and all high-risk overseas posts require explicit review. Add report-job triage queue and critical issue kill switch. All counts are launch-policy proposals, not verified staffing capacity.

### Contract + release evidence

Update API `JobResponse` to return full employer-owned fields, status, validThrough, revision, timestamps, rejection reason code; support `GET /jobs?external_id=` to reconcile uncertain POST responses. `201` creation status MUST be `pending_review`. Non-owner imported jobs forbidden from partner endpoints, ever. Secure key issuing requires review/rotation/revocation, hashed at rest. A draft YAML passing syntax validation is NOT equivalent to passing integration/security/release tests. See OpenAPI 3.1.0 contract and `91_HISTORICAL_V12_TRACEABILITY.md`; do not enable before all v1.1 audit C01–C05 and H01–H14 are demonstrated by implementation evidence.

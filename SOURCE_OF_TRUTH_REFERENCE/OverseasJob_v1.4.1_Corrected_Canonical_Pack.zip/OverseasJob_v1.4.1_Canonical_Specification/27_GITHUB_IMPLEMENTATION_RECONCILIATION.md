# Existing GitHub code and canonical spec reconciliation — 2026-11-23

**Read-only discovery:** Connected GitHub repository https://github.com/mohdazizshaikh/overseasjob (`main`, PHP; current README v0.9.15) exists. It is not a blank project. Its module ledger reports local implemented and CI-tested modules but still blocks host/site cutover. GitHub latest main commit `c53e565fc45676c3e682d342f4a28751328ab801` (2026-11-23 15:22:55 UTC) was verified; the linked CI run [45204589587](https://github.com/mohdazizshaikh/overseasjob/actions/runs/45204589587) completed with success for that commit. Earlier failed attempts on other commits exist; a green CI run is NOT a production/site or source-permission certificate. No write to this repo or Hostinger was made while creating v1.4.1. Existing files must be retained, not replaced by an older docs ZIP.

## Official evidence links checked

- Himalayas OpenAPI: https://himalayas.app/docs/openapi.json — browse `GET /jobs/api` `offset`, `limit<=20`, `totalCount`; search `GET /jobs/api/search`; NO per-job documented status route; `pubDate` & `expiryDate` integer Unix ms; `locationRestrictions`: `Location[]` with `alpha2`; `timezoneRestrictions`: string[] UTC offsets; required `applicationLink` may be employer ATS URL.
- Himalayas docs: https://himalayas.app/docs/remote-jobs-api ; attribution and provider conditions must be rechecked at activation.
- Jobicy API: https://jobicy.com/jobs-rss-feed — latest jobs, at most 100, `count`, `geo`, `industry`, `tag`; no documented cursor or universal seven-day guarantee on current page; keep provider job URL, credit and no false closure on absence.

## Existing repo code reconciliation (read-only GitHub inspection)

| Area | Observed existing repo | New v1.4.1 contract | Recommended action |
|---|---|---|---|
| Existing product | `README.md` v0.9.15; `src/`, `public/`, `tests/`, `deploy/` and status ledger exist | Specification-only zip does not replace app | Preserve repo, compare contract as targeted changes |
| Himalayas pagination | `src/Jobs.php` and `scripts/sync_jobs.php` use offset/limit/totalCount; no cursor | Matches official OpenAPI | Keep; add source contract assertions |
| Himalayas pubDate | `src/Jobs.php` maps to source_published_at | Matches official OpenAPI | Keep; test Unix ms |
| Himalayas status | Repo documents no production public per-job status endpoint; offline legacy test helper exists | No fabricated status checker | Keep status checker disabled; remove misleading examples if safe |
| Himalayas timezone | `src/Jobs.php` accepts numeric offsets as normal and `tests/php_tests.php` calls numeric field current | Official JSON field is `string[]` | Update misleading documentation/fixtures; fail malformed numeric provider response closed; accept `UTC+5:30`, `UTC+05:30` after documented canonical parsing |
| Himalayas location | Existing code accepts strings and country objects for migration; some tests use string `IN` | Official JSON field is `Location[]` objects with alpha2 | Use object fixtures for current provider; treat malformed/missing unknown; legacy handling must not promote unsafe eligibility |
| Hostinger | README warns `index.html` vs `index.php` cutover and demands backup/restore | No blind live overwrite | Maintain cutover gate: real existing homepage and DB restoration, then deployment health |
| Provider activation | README says global/provider source flags and private rights attestation default OFF | No licensed live provider assumed | Keep OFF until real rights/source evidence |
| Full product | Ledger reports all 10 tools and module code; README references Chromium/CI | Docs ZIP was only specification | Independently run code/CI and review current latest commit before claiming production readiness |

## Priority safe next coding work

1. In existing GitHub repo, add official-OpenAPI-shape fixtures for `locationRestrictions` Location objects, timezone UTC strings, valid/malformed/missing arrays; require strict known evidence for IN. Preserve fallback to `unknown` for unsupported format. Old numeric fixtures should be historical only, never describe current JSON API.
2. Add regression assertions: only public browse and search routes; offset 0/20 limit<=20; integer milliseconds publication/expiry; top-level `updatedAt` not per-job source update; exact `applicationLink`; no per-job status requests. Use tests without hitting live providers.
3. Reconcile source docs and code release version using evidence; leave existing main untouched until tests pass on a branch/PR.
4. Verify latest GitHub CI and actual Hostinger resources through authorised account; restore backup of the **existing** theme/DB before any website cutover. No paid staging required if founder uses same hosting for testing, but never disrupt current site blindly.
5. Complete real 14 distinct days of permitted job-coverage samples, content review and source policy checks. Do not invent results; do not enable provider flags, recruiter/partner API, or ads prematurely.

**Evidence boundary:** Inspection of public README and source through the linked GitHub connector is not a local clone, complete CI rerun, source licensing approval, actual Hostinger inspection or production deployment. `module_status.json` in this ZIP remains documentation-only; do not overwrite the actual repository's ledger.

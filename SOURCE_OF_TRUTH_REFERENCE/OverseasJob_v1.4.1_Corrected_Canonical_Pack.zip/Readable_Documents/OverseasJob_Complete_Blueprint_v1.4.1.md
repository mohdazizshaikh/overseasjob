# OverseasJob.in — Comprehensive Canonical Blueprint and Agent Handoff v1.4.1

**23 November 2026 — CANONICAL SPECIFICATION CORRECTION; NOT HOSTINGER-DEPLOYED.** The authoritative editable sources are in the v1.4.1 ZIP. This readable Word/Markdown snapshot is derived; the existing GitHub repository contains separate application code, not replaced here.

---


---

# Included canonical file: `00_SOURCE_OF_TRUTH.md`

# OVERSEASJOB.IN — SOURCE OF TRUTH & AUTHORITY REGISTER

**Release:** v1.4.1 (authority reconciliation, deterministic fixtures and release audit)  
**Date:** 23 November 2026  
**Status:** CANONICAL DOCUMENTATION; NOT A WORKING OR DEPLOYED PRODUCT  
**Scope:** The complete OverseasJob.in product, modules M00–M17, utilities T01–T10, optional Recruiter Lite and inbound Partner API.

## 1. What is the single source of truth?

**The canonical source of truth is THIS VERSIONED PROJECT PACK, not any one Word document.**
This file is its **authority/index**, not a replacement specification. The requirement owner for each topic is shown below. Do not duplicate detailed business logic, types, formulas or request schemas here.

**Canonical editable location:** the Markdown, YAML, JSON, CSV, SQL and validation files inside this package.
**Human-readable exports:** `OverseasJob_Complete_Blueprint_v1.4.1.docx` and root Markdown copies are snapshots. If an export differs from the canonical files, the canonical files win. Regenerate exports after changes; do not separately edit their content.
**Prior releases:** Any v1.1/v1.2 ZIPs, Word files and `90_`–`92_` audit archives are historical evidence, NOT current implementation commands.

## 2. Exact authority map (one owner per type of requirement)

| Domain / decision | Normative authority | Supporting references (not overriding) |
|---|---|---|
| Business purpose, target audience, boundaries, monetisation intent | `01_COMPLETE_PROJECT_BLUEPRINT.md` | `10_DECISION_COMPANION_PRODUCT_SPEC.md` |
| All modules M00–M17, release gate, workflows, UI states, acceptance meaning | `15_CANONICAL_MODULE_REQUIREMENTS.md` | `01_*`, `03_MILESTONE_TASKS.md`, `04_QA_AND_LAUNCH_CHECKLIST.md` |
| JobView, eligibility, source provenance, date semantics, job state and automation lifecycle | `16_DATA_AND_OPERATIONS_CONTRACT.md` | `06_ARCHITECTURE_AND_DATABASE.md`, `10_*` |
| Free career utilities T01–T10: calculations, input validation, fixtures | `17_TOOL_ALGORITHMS_AND_FIXTURES.md` | `18_TEST_FIXTURES.json`, `15_*` |
| Inbound employer/ATS HTTP field names, types, paths, status codes | `08_PARTNER_JOB_POSTING_API_OPENAPI.yaml` | `07_RECRUITER_LITE_AND_PARTNER_API.md` |
| Database physical table/column/index reference | `24_DATABASE_SCHEMA_REFERENCE.sql` | `16_*` determines the required data semantics; implement DB changes so the two agree |
| Recruiter verification, posting workflow, employer trust and operational gates | `07_RECRUITER_LITE_AND_PARTNER_API.md` | `15_*`, `08_*`, `16_*` |
| Provider-specific licences, attribution, indexing/export/JobPosting restrictions | `05_SOURCE_POLICY_MATRIX.csv` together with `16_*` | The **actual current written provider terms/permissions** override every local summary |
| Privacy, user consent and security rules | `15_*`, `16_*`, `07_*` as applicable | Applicable law overrides any incorrect or obsolete local instruction |
| Technical stack and hosting adaptation | `06_ARCHITECTURE_AND_DATABASE.md` | Actual verified hosting capabilities and zero-new-paid-cost constraint |
| Opportunity Guardian, Job Decision Cards, no-login Radar | `15_*`, `16_*` | `10_DECISION_COMPANION_PRODUCT_SPEC.md` for supplemental UX detail |
| Autonomous AI-agent delivery and boundaries | `19_AGENT_AUTONOMY_AND_DELIVERY.md` | `02_AI_AGENT_MASTER_PROMPT.md` |
| Phase ordering, work packages | `03_MILESTONE_TASKS.md` | Gate ownership in `15_*` is definitive |
| Required QA, reproducible contract checks and verification claims | `04_QA_AND_LAUNCH_CHECKLIST.md`, `18_TEST_FIXTURES.json`, `23_VALIDATE_SPEC.py` | `20_VERIFICATION_LEDGER.md` records evidence, not unrun claims |
| What has actually been checked vs only documented | `20_VERIFICATION_LEDGER.md` | Real implementation test logs and deployed module status, once available |

**Safety and factual truth trump document order:** Applicable law, explicitly authorised source rights, actual provider API contract/response and verified infrastructure facts are not optional assumptions. If they conflict with written plans, preserve the safer truthful behaviour and reconcile documentation and tests. Never invent employer verification, sponsorship, job inventory, affiliate payments or advertising approval.

## 3. Conflict-resolution procedure for an autonomous coding agent

1. Locate the owner file in the table above; follow its contract instead of older descriptive examples.
2. Verify external facts against source terms and real APIs before enabling that integration.
3. If two *current* authorities conflict: reproduce with the smallest relevant test; apply the most restrictive **non-fabricating, privacy-preserving** interpretation temporarily; update both authoritative files, tests and changelog to one consistent decision.
4. If the conflict changes a genuine **business choice** (pricing, whether to act as a recruitment agent, legal representation, making a paid commitment) and there is no documented answer, keep only the affected feature **not live**. Continue other fully specified work autonomously.
5. Never treat a passing documentation validator as proof of deployed code, legal compliance, live employers or revenue.

Examples:
- Unconfirmed India eligibility → show `unknown`; not “India eligible.”
- Provider job disappears from seven-day discovery feed → **not** automatically `closed`.
- Source forbids downstream redistribution → exclude the imported records from partner APIs/exports.
- Recruiter claims verification without evidence → posting remains held; no verified badge.
- One API sample contradicts OpenAPI → fix sample to conform to `08_*`; do not silently change the API interface.

## 4. Mandatory machine-checkable module register

The platform is specified through **18 modules M00–M17** in `15_*`; utilities T01–T10 belong to M05. Each implementation must maintain `module_status.json` with `module_id`, `spec_version`, `implementation_status`, `tests`, `routes`, `dependencies`, `evidence_paths`, `blocker_reason`, and `last_verified_at`.

Allowed statuses: `specified`, `implemented`, `tested`, `deployed`, `blocked_with_reason`. Do not mark work `tested` or `deployed` on the strength of documentation alone. Future-gated Recruiter Lite and API modules still belong to the module inventory; **specified is not live**.

## 5. Agent autonomy: FULL ACCESS, NO TECHNICAL MICRO-APPROVALS

The authorised AI coding agent may inspect hosting, choose implementation details within written constraints, create/edit code, install free dependencies, migrate with backups, test, repair, deploy and roll back through the existing authorised environment. The founder is not required to review code, YAML, SQL or approve each technical operation. Record decisions and produce a plain-language report. Never create an unapproved paid recurring commitment, destroy unrelated projects, breach third-party rights or fabricate legal/job claims.

## 6. Change management — keep one truth

1. Modify the **owner contract** first; revise dependent examples, fixtures, SQL and tests.
2. Change module IDs/status only if the actual scope changes; preserve existing identifiers.
3. For any normative behaviour/interface change, update `09_CHANGELOG.md` and bump release version; for a governance-only edit, patch version is enough.
4. Run `python 23_VALIDATE_SPEC.py` from this folder; add tests for new claims; preserve failed cases until fixed.
5. Regenerate `13_RELEASE_MANIFEST.json` with SHA-256 of canonical files, and generate new export ZIP/documents. Never independently edit an old export and call it authoritative.
6. Record real test evidence in `20_VERIFICATION_LEDGER.md` and the implemented project's test reports. Keep historical audits archived, not competing instructions.
7. If a file only repeats rules already owned elsewhere, replace duplicated normative prose with a reference to its owner.

## 7. Release truth boundary

This v1.4.1 package reconciles binding specifications, agent instructions and automated document checks; it is not an implementation. It does **not** change jobs, tools, employer/API business scope, add live features, verify job supply, prove hosting support, or guarantee AdSense/affiliate revenue. The actual code, deployment, external integrations and monitoring require independent evidence. The source-of-truth pack is the contract used to build and test them.

**Read order:** `00_SOURCE_OF_TRUTH.md` → `00_READ_ME_FIRST.md` → `01_*` → `15_*` → `16_*` → `17_*` → relevant owner contract → `19_*` → fixtures/validator → verification ledger.

## v1.4.1 current external API correctness override

When a local provider contract contradicts the provider's currently published OpenAPI, treat official provider specs as external authority. For Himalayas browse use offset/limit/totalCount, UTC offset strings, country objects, pubDate publication milliseconds, and **no invented per-job status route**. For Jobicy use the current documented count-limited latest API; do not assume cursor pagination or 7-day guarantees. See `16_DATA_AND_OPERATIONS_CONTRACT.md` and `27_GITHUB_IMPLEMENTATION_RECONCILIATION.md`.



---

# Included canonical file: `00_READ_ME_FIRST.md`

# OverseasJob.in — Canonical AI-agent Project Pack v1.4.1.1

**Prepared:** 23 November 2026  
**State:** DOCUMENTATION / IMPLEMENTATION SPECIFICATION ONLY. No working product or deployment is asserted.

## Start in this order

0. `00_SOURCE_OF_TRUTH.md` — the canonical authority map, conflict rules and agent autonomy.
1. `01_COMPLETE_PROJECT_BLUEPRINT.md` — business purpose, user promises and scope.
2. `15_CANONICAL_MODULE_REQUIREMENTS.md` — every module, complete user workflows, edge cases and release gates.
3. `16_DATA_AND_OPERATIONS_CONTRACT.md` — provenance, legal/source rules, matching, status, automation, recovery.
4. `17_TOOL_ALGORITHMS_AND_FIXTURES.md` — deterministic formula/validation/test cases for ten utilities.
5. `08_PARTNER_JOB_POSTING_API_OPENAPI.yaml` — canonical inbound partner HTTP contract; **not yet deployed**.
6. `07_RECRUITER_LITE_AND_PARTNER_API.md` — recruiter workflow, trust and API restrictions.
7. `18_TEST_FIXTURES.json`, `23_VALIDATE_SPEC.py` and `24_DATABASE_SCHEMA_REFERENCE.sql` — executable document/contract tests.
8. `19_AGENT_AUTONOMY_AND_DELIVERY.md` — full-access agent authority, autonomous workflow and evidence-based final handoff.
9. `20_VERIFICATION_LEDGER.md` — honest statement of what was checked and still needs live evidence.
10. `02_AI_AGENT_MASTER_PROMPT.md`, `03_MILESTONE_TASKS.md`, `04_QA_AND_LAUNCH_CHECKLIST.md`, `05_SOURCE_POLICY_MATRIX.csv`, `06_ARCHITECTURE_AND_DATABASE.md`, `10_DECISION_COMPANION_PRODUCT_SPEC.md` — detailed supporting context.
11. `90_HISTORICAL_V11_AUDIT_ARCHIVE.md`, `91_HISTORICAL_V12_TRACEABILITY.md`, and `92_HISTORICAL_V12_GAP_REVIEW.md` — historical only; **not current instructions**.

**Precedence:** See `00_SOURCE_OF_TRUTH.md` for the full authority matrix. Partner HTTP request/response shape: OpenAPI > other prose. User/business behaviour: `15_*` > historical prose. Source status, eligibility, operations: `16_*`. Tool mathematics: `17_*`. Historical audits are evidence, not build instructions. If a contradiction exists, repair current documents/tests automatically and log it; no silent invention.

## What the founder authorises

The founder is nontechnical and gives the coding agent full technical access to existing authorised infrastructure. Do not demand approval for each command, file edit, technical choice or normal deployment step. Be self-directed: inspect → implement → test → fix → deploy safely if environment authorises → verify → document. Make backups and use rollback. Do not incur new paid commitments, misrepresent live features, enable unsafe public recruiter onboarding, or violate third-party licences. For unknown external credentials, law, terms or hosting limits, record a precise blocker and complete independent work.

## Product promise

Remote work and overseas career *decision support* for India-based users, with source-backed job discovery, honest eligibility, Job Decision Cards, no-login Opportunity Radar, 10 genuinely functioning free utilities, original guidance and optional simple Daily Arena. Recruiter Lite / inbound API are designed but gated; candidate ATS, placement service, auto-apply and resyndication of imported jobs are excluded.

## Execution

Run `python 23_VALIDATE_SPEC.py` before code generation and after any contract edit. Create test evidence from **actual implementation**, not merely from documents. Deploy no paid external systems. Core gate order: source-coverage proof → source-backed jobs/Decision Cards/first 3 tools → local Radar/tracker → remaining utilities/game → recruiter pilot/partner API only if safety and capacity allow. The agent can progress autonomously through stages if automated gates pass, without asking for a technical review from the non-developer founder.

## Release artifacts and truthful status

`module_status.json` starts at `specified` for all 18 modules. This is a documentation package, not source code, a deployment, a live API connection or a 14-day supply audit. `21_FOUNDER_HANDOFF.md` states what an authorised coding agent must verify next. `25_DOCUMENT_AUDIT.md` records this release's corrections and external blockers. `13_RELEASE_MANIFEST.json` hashes the editable canonical documents and tests. Never claim a verified production result from a sample or contract check.

## Critical v1.4.1 correction and existing repository

A functioning *development repository* was discovered at `https://github.com/mohdazizshaikh/overseasjob`; never replace its code with this spec-only pack. The v1.4 source-specific pagination, timezone, location and `pubDate` assumptions were corrected here against the provider OpenAPI. Read `27_GITHUB_IMPLEMENTATION_RECONCILIATION.md` and run targeted tests against the existing repo before merging documentation. Hostinger deployment and live provider activation remain separate blocked work.



---

# Included canonical file: `01_COMPLETE_PROJECT_BLUEPRINT.md`

# v1.4.1 authority note — 23 November 2026

This Word-facing product blueprint is a specification; a separately discovered PHP application exists in GitHub and is not verified deployed. `00_SOURCE_OF_TRUTH.md` and the v1.4 canonical owner files control any conflicting examples below. Corrections in v1.4 unify `/arena`, API/DB status vocabulary, AI-agent full technical autonomy, source evidence, release audit, and automated fixtures; they do not prove hosting, real job supply, code or revenue.

---

# OVERSEASJOB.IN
## Complete Project Blueprint — Career Decision Companion + Automated Jobs + Utilities

**Version:** 1.4 (v1.3 product scope retained; corrected authority, fixtures and agent handoff)  
**Prepared:** 22 November 2026  
**Audience:** Solo, non-technical founder; AI coding/development agents  
**Status:** Proposed implementation specification, not a built or launched website  
**Business goal:** Build a genuinely useful, low-maintenance product with the potential to reach ₹50,000/month, primarily from advertising; no revenue or traffic is guaranteed.

> **Product promise:** “Find legitimate opportunities, understand your options, prepare for your next move, and build your career — without paying to search or apply.”

---

## v1.4.1 product direction (retains the v1.3 decision, supersedes v1.2 delivery sequencing): Career Decision Companion, not generic alerts

**Product wedge:** A user in India chooses a role, then explores remote-from-India versus relocation-abroad as distinct paths. OverseasJob.in shows only source-grounded opportunities, **honest location eligibility**, freshness and source provenance, practical salary/cost comparisons, and one clear next action. This integrated decision workflow is the differentiation hypothesis; it is **not** a claim that alerts or trackers were invented here.

**Value loop (first useful visit):** Select role / work path / country (no login) → view eligible/unknown opportunities → inspect a **Job Decision Card** → calculate savings or compare offers → use the source-required Apply link or save job → on return see changes since last visit plus user-entered application follow-ups.

**Automation boundaries:** Globally scheduled server jobs refresh the *public* dataset. Private saved preferences, last-seen state and progress are stored in the browser and evaluated **when the user visits**. Without an opt-in server-side account/notification infrastructure, the service **does not monitor individual users or email them while offline**. “Guardian” and “Radar” are product labels, not claims of human verification or persistent personalised background agents.

**No unsupported jobs promise:** Free remote-job feeds do not establish physical overseas/visa sponsorship coverage. Show three pathways separately: (1) explicitly India-eligible remote, (2) remote with restrictions/unknown eligibility, (3) on-site abroad/relocation **only from independently authorised evidence**; never invent relocation roles. The source licence and eligibility evidence override marketing copy.

**Economics reality:** Jobs imported from free feeds have **no assumed click commission**. Jobicy's separately approved referral programme concerns eligible employer-posting purchases, not automatic candidate Apply clicks. Content and tools must have substantive original value for AdSense evaluation; provider permission does not imply AdSense approval. ₹50,000/month remains aspirational, not forecast.

**Release status:** v1.4 is a *documentation/design update*, not a deployed application. The previous static audit's technical issues are requirements to resolve and TEST before enabling recruiter or partner API. See `10_DECISION_COMPANION_PRODUCT_SPEC.md` and `91_HISTORICAL_V12_TRACEABILITY.md`.

---
# 1. Executive decision: what to build, and why

OverseasJob.in should **not** launch as another LinkedIn, Naukri, Apna, Upwork, staffing agency, or all-purpose social network. It will launch as a **free, privacy-conscious career utility website** with an **automated, source-attributed job discovery layer** and **original tools** people can use independently of vacancies. Users searching for remote roles discover calculators and preparation resources; users arriving for a tool discover relevant jobs. Later, lightweight daily puzzles can give people a reason to return without misleading incentives.

**Expansion boundary:** A future **Recruiter Lite** module will let verified employers post their own vacancies by form or secure integration API; the first public launch remains an anonymous job-discovery/utilities site. Full ATS and recruitment/placement services are outside scope. See sections 4A–4B and `07_RECRUITER_LITE_AND_PARTNER_API.md`.

**Business distinction:** AadiTechs.in remains the IT services business; OverseasJob.in is a self-service information/utility property. Managed IT service contracts, placement services, payment escrow, and client/freelancer handling are **out of scope**.

**Founder reality:** One person with multiple projects, no budget for new subscriptions, and development implemented through AI agents. Design choices must privilege a small codebase, public/official free APIs, scheduled automation, precomputed pages, browser-only tools, no paid AI inference, no mandatory user accounts, and failure-safe operations. There is **no such thing as zero-maintenance or guaranteed passive income**: reviews, content checks, API term monitoring, uptime and ads compliance remain necessary.

## 1.1 Success definition

1. Visitors finish a genuinely useful task (find a suitable job, compare two offers, calculate realistic costs, save their applications).
2. Source-attributed jobs are current enough, and an outbound application works without hidden fees or forced signup.
3. Original guides and tools give the site value even if external job feeds fail.
4. Job operations (fetch, deduplicate, close/hide, monitor) execute automatically under source-specific terms.
5. Costs remain within existing hosting and free service limits; any proposed paid component must be explicitly blocked until approved.
6. Business progress is measured through **search impressions → engaged users → repeat visitors → ad eligibility/RPM**, not raw imported job counts.

## 1.2 Non-goals at launch

- Guaranteeing a job, visa, employment sponsorship, income, or job interview.
- Recruitment agency services; candidate placement, résumé sales, foreign-employer representation, passport collection.
- A full recruiter ATS, internal job applications, payment gateway, fee-based membership, chat/social feed. **A minimal verified-employer job posting form and inbound Job Posting API are specified for later gated phases, not Day-1 launch.**
- Scraping LinkedIn, Naukri, Indeed, Apna or other platforms without express permission.
- Publishing hundreds of auto-written articles or thin indexed jobs to manipulate search results.
- Promoting gambling-like rewards, forced ad clicks, notification spam, or misleading countdowns.
- Hiring staff, operating a manually moderated marketplace, or promising 100% hands-off operation.

---

# 2. Positioning, audience, and practical user needs

**Main positioning:** “OverseasJob.in — India-to-global Career Decision Companion: discover, check eligibility, compare, prepare and track.”

The brand name is overseas-focused, but the website must be **accurate**: a remote role hiring from India is not automatically a visa-sponsored overseas job; a job requiring relocation is not remote.

## 2.1 Initial audiences

| Persona | Problem they want solved | Immediate website value | Minimum friction |
|---|---|---|---|
| Indian professional seeking global remote work | Cannot easily identify jobs that accept Indian applicants | India-eligible/Worldwide-eligible filters, accurate source-linked jobs | No account needed |
| First-time overseas job explorer | Unsure about costs, documents, work eligibility, scam risks | Cost-of-living, relocation, and official-source checklists | No sensitive document uploads |
| Working professional comparing offers | Hard to compare cash, tax assumptions, benefits and expenses | Offer comparison and take-home/savings estimator | Local browser calculation |
| Fresher looking for career direction | Little experience and unclear requirements | Role-based roadmap, interview questions, templates | Free accessible resources |
| Frequent job applicant | Loses track of applications on several websites | Personal application tracker | Local-first optional export |
| Remote team member | Multiple time zones make meetings confusing | Time-zone overlap calculator | Browser-only |
| Casual returning visitor | Wants a short useful daily habit | One original daily vocabulary/logic puzzle | No forced login |

## 2.2 Fundamental user experience rules

- Search, view listings, access sources and use calculators **without registering**.
- Clearly label three job types: **Remote (work from India allowed)**, **Remote (location restricted)**, **On-site/relocation**, plus **Eligibility not verified** where appropriate.
- Never infer visa sponsorship, local work authorisation, “verified employer,” or salary numbers from missing data.
- Show salary as disclosed by the source; mark missing/uncertain fields as unknown rather than inventing values.
- Users can see when a listing was **published** (if available), **last checked**, and which **provider** supplied it.
- Outbound application action shows the source destination and uses the provider-required canonical URL.
- Profiles, documents and contact details are not necessary for the basic version.
- Language: launch in readable English, with Hindi/Hinglish guidance optionally added and carefully verified. Do not mass-translate low-quality pages.

---

# 3. Product architecture: five connected modules

**Module A — Job Discovery + Job Decision Cards:** Source-attributed jobs, eligibility evidence, source freshness and honest next actions.  
**Module B — 10 Free Utilities:** Independent career calculators, templates and planners.  
**Module C — Country & Safety Knowledge Base:** Original overseas preparation guides, official sources and anti-fraud resources.  
**Module D — Opportunity Radar + Career Actions (local-first):** Private browser preferences, new-since-last-visit matches, manual application follow-ups, portable export/import. Optional Daily Arena is a later low-cost retention experiment.  
**Module E — Recruiter Lite + Partner Job Posting API (gated):** Verified company accounts submit/close employer-owned jobs via simple dashboard or secure server-to-server API, **without** candidate application storage, recruiting services or unrestricted third-party feed redistribution.

**Launch order:** Gate 0 source-supply audit → A with usable Job Decision Cards + local preference selector + first 3 utilities + 5 original guides → local Radar / saved-job tracker / import-export → optional single mission/game → if justified, verified employer pilot and only afterwards partner API. **Recruiter features have separate security and moderation launch gates and may remain disabled indefinitely if not sustainable.** The full specification describes all 10 tools **without requiring all 10 before validation**.

## 3.1 Navigation (desktop and mobile)

Home | Find Jobs | My Career (on-device) | Free Tools | Countries & Safety | Daily Arena (only when live) | For Employers (when approved) | About

Footer: About | Contact | Privacy | Cookies | Terms | Disclaimer | Report a job | Sources / Attributions

On mobile, primary navigation should remain accessible without covering content or encouraging accidental ad clicks.

## 3.2 Canonical URLs

| Page | Proposed path | Indexing policy |
|---|---|---|
| Homepage | `/` | Index |
| My Career / local Radar | `/my-career` | Noindex personal state; static explanation may be indexed if substantive |
| Opportunity Radar setup | `/my-career/setup` | Noindex, no login required |
| Job search & user filters | `/jobs` | Index one useful evergreen landing page; noindex unbounded query/filter combinations |
| Job details | `/jobs/{provider}/{stable-id}/{slug}` | Default noindex for third-party syndicated feed-only pages; check each source's terms |
| Remote hiring eligibility guide | `/remote-jobs-from-india` | Index if original, useful, and maintained |
| Free tools index | `/tools` | Index |
| Salary vs expenses | `/tools/salary-savings` | Index |
| Offer comparison | `/tools/offer-compare` | Index |
| Resume kit | `/tools/resume-kit` | Index |
| Relocation budget | `/tools/relocation-budget` | Index |
| Time-zone overlap | `/tools/time-zone-overlap` | Index |
| Application tracker | `/tools/application-tracker` | Index |
| Interview practice | `/tools/interview-practice` | Index |
| Document checklist | `/tools/document-checklist` | Index |
| WorkProof portfolio | `/tools/workproof` | Index public tool explanation, never private portfolios by default |
| Career roadmap | `/tools/career-roadmap` | Index |
| Country overview | `/countries/{country}` | Index only when original, maintained content exists |
| Scam warning hub | `/safety` | Index |
| Daily original game | `/arena` | Index if actual standalone value |
| Report job | `/report-job` | Noindex |
| Employer introduction | `/employers` | Index only if useful and operational; no fake free job posting promises |
| Employer onboarding | `/employers/register` | Noindex; disabled until security/verification ready |
| Recruiter dashboard | `/employers/dashboard` | Auth-only, noindex |
| Recruiter post/edit | `/employers/jobs/new`, `/employers/jobs/{id}/edit` | Auth-only, noindex |
| Partner API reference | `/developers` | Index documentation only after feature readiness; never expose tokens |
| API data routes | `/api/v1/partner/*` | Auth-only, noindex |

Server-rendered HTML is preferred for all crawlable pages. Do not launch 500 empty city/role keyword combinations to inflate page count.

---

# 4. Job aggregation: provider strategy, permissions, constraints

**Critical:** Free job sources provide discovery, **not affiliate income**. Jobicy employer-posting referral commissions are separate and require real qualifying purchases, not candidate Apply clicks. Commercial affiliate programmes require separate application, approval, tracking and payment terms. No provider rates are assumed.

## 4.1 Source decision matrix, verified 22 November 2026

| Provider | Role | Current documented rules to encode | Launch decision |
|---|---|---|---|
| **Jobicy public API** | Primary remote feed | Public API, free to integrate; maintain visible Jobicy source credit and canonical Jobicy URL; cache; do not start new sync passes more than hourly; statuses may be checked in batches | **Enabled**, subject to final pre-launch terms review |
| **Himalayas public remote-jobs API** | Secondary remote feed | Commercial integration allowed with attribution; each Apply must use supplied `applicationLink`; do not resyndicate to other boards, Google Jobs or LinkedIn Jobs, including via `JobPosting` structured data; respect rate limits and expiry | **Enabled**, with hard-coded source restrictions |
| **Remotive public API** | Optional alternate | Source must be credited and Remotive job URL linked; restrictions on forwarding listings to third-party aggregators and signup gating | **Disabled by default** until source-specific intended use is confirmed |
| **Careerjet publisher programme** | Possible future monetised feed | Publisher widgets/API/XML and monetisation exist; account, commercial acceptance and rules required | **Not enabled** until approved |
| **Jooble / other paid or partner feeds** | Possible future CPC/CPA | Rates, regions, publisher approval and rights must be confirmed in writing | **Not enabled** until approved |
| Employer career websites | Original outbound discovery | Publishing rights depend on source terms; original short commentary and direct links only with permitted use | **Manual research only** or written authorisation |
| LinkedIn / Indeed / Naukri / Apna | No public permission assumed | No scraping or data copying without authorised contract | **Never scrape** |

**Source terms may change.** Store `provider_policy_version`, `policy_checked_at` and an owner-maintained reference URL. Set disabled when terms cannot be verified.

Official documentation is in Section 23.

## 4.2 Technical ingestion pipeline

1. Scheduled job starts (twice daily initially; never more frequent than the provider allows).
2. Fetch provider terms/config from local configuration; ensure source enabled, cooldown elapsed and request quota available.
3. Fetch JSON with a timeout (e.g. 15–30 seconds), proper User-Agent, conditional HTTP caching if supported, and provider pagination. Honor `Retry-After` on HTTP 429.
4. Validate fields against provider-specific schemas; if malformed, log source error and retain last healthy cache.
5. Sanitize provider HTML descriptions and all URLs; permit only `https://` destinations unless explicitly justified. Never execute imported scripts or embed third-party HTML blindly.
6. Map valid entries to normalized records; preserve exact source URL and apply link separately. Unknown geo, salary, visa or job type stays unknown.
7. Deduplicate via `(provider, provider_job_id)` first. Cross-provider matching may flag same employer/title/location but must **not** erase attribution or swap required apply links.
8. Persist in a local database in a transaction; publish atomic cache updates only after successful full ingestion.
9. Run source-aware active/expired status checks within limits. An API failure or an item no longer in Jobicy’s *bounded latest-results feed* is **not proof of expiry**.
10. Generate/search cache and public last-sync indicators; log counts: imported, updated, duplicates, errors, stale, closed.
11. On closed status remove from search, disable Apply, and serve user-friendly closed message (or HTTP 410 where appropriate). Never redirect closed jobs to unrelated monetised content.
12. Trigger alerts only for genuine errors or policy/expiry risk, not every successful run.

### Failure-safe policy

- If feed fails: display cached records only if their validation freshness remains acceptable; label “last checked.” Disable/hide listings whose status is too uncertain rather than claiming they are current.
- If rate limit: back off, do not switch to scraping.
- If sync yields zero due to an error: **do not wipe the database**.
- If a provider changes apply-link rules: temporarily disable that provider until reviewed.
- If feeds contain no India-eligible roles: show an honest empty state and alternate tools; do not relabel location-restricted jobs.

## 4.3 Source-aware eligibility logic

Filters:
- Keyword, role/category, source, remote eligibility, country/region, salary disclosed, posted date, employment type.
- `eligible_from_india = true` **only** when source explicitly permits India or genuinely worldwide; worldwide wording must be validated against source location exclusions.
- `requires_relocation = true` only when explicit in source; no visa sponsorship inferred.
- Any unknown eligible field gets `unknown` and explanatory badge, not a checkmark.
- Users can toggle “Show India-eligible remote jobs only” without being misled by “US Remote” listings.

## 4.4 Job detail card minimum fields

Job title; employer name; location/work model; eligibility note; salary if stated; employment type; source; published date if given; last checked date; short permitted description; source terms summary if provided; prominent **Apply on [Provider]** button; **Save/Track** action; report issue action; relevant original tool suggestion. No fabricated trust scores or “guaranteed job” badges.

**Display rule:** “Imported from Jobicy” and “Imported from Himalayas” are always visible on respective records, with direct source link. Himalayas jobs **must** apply using the provider's `applicationLink`.

---


# 4A. Recruiter Lite: low-cost direct employer job posting

**Decision v1.1:** Add a **limited, invitation-led employer self-service posting feature** to improve job supply quality without operating a full ATS or recruitment agency. This is **not part of the first lean MVP**: build and launch only after public site, security, backup and exception-handling workflows are validated. It may remain behind a disabled feature flag if founder workload becomes unacceptable.

## 4A.1 Direct posting workflow

1. Employer visits `/employers`, confirms email, creates an organisation record and provides evidence that they are authorised to publish the vacancy.
2. Platform verifies company domain/control and identity as appropriate. Pilot employer approval is manual for the first few organisations; automated identity checks alone are not proof of legitimacy.
3. Verified account fills a structured form with title, responsibilities, category, work arrangement, country/candidate eligibility, accurate salary when available, employer-controlled HTTPS apply URL, and **mandatory expiry**.
4. Automated checks sanitize content, validate hostname/company ownership, reject duplicates/deposit scams, rate-limit spam and hold suspicious submissions for review.
5. Job state progresses `draft -> pending_review -> published -> closed/expired/rejected/suspended`. Only published jobs are visible; high-risk overseas jobs require an explicit legal/trust review.
6. Recruiter can edit, pause/close, or request extension; expiry cron hides jobs automatically. **No candidate resumes, passport documents, application data or payments** are handled by OverseasJob.in.
7. Candidate clicks **Apply on employer site** and goes to the organisation's own authorised application link. Every job identifies `Direct employer listing` instead of disguising it as an external API feed.

**Recruiter Lite MVP tools:** free job posting, job edit/close, expiry and job health, basic job views/outbound-apply counts (aggregated), company profile and job-description form templates. No full ATS, internal candidate application workflow, interview scheduling, candidate matching, or paid advertising at start.

## 4A.2 Abuse, identity and legal safeguards

- Recruiter accounts are **optional** and entirely separate from anonymous job seekers; no candidate login required.
- Registering an email does not mean employer verification. Domain/email identity, legitimate business details and authority to post must be checked. Overseas recruiting agents and foreign-employer recruitment require applicable MEA/eMigrate compliance review before related postings or services are enabled.
- Never permit candidate payment demands, deposit requests, false visas, fake sponsorship, or claims of guaranteed hiring. Suspicious jobs go into a quarantine queue; ability to disable an organisation immediately is mandatory.
- All job content is untrusted: input length limits, sanitized markup, HTML escaping, HTTPS apply URL and approved employer/ATS domains. No unverified redirects or short links.
- Expire jobs at specified `valid_through` and suppress job metadata when closed. No silent renewal merely to keep listings fresh.
- **Founder operations:** automated routine checks, small daily exception digest, manual handling of suspicious/new accounts. 100% automated employer legitimacy screening cannot be promised. Disable onboarding if moderation queue grows beyond manageable capacity.

**Pilot gate:** At least 3 legitimate pilot employers, documented verification method, tested kill-switches and rollback, rate limits, account recovery, spam prevention, backups and privacy policy updates. Employers must not be allowed to post publicly by anonymous request.

# 4B. Recruiter / ATS Job Posting API (inbound) — future Phase 3B

**Business value:** Existing businesses and ATS systems can maintain their own OverseasJob.in listings without manually entering every vacancy. API is initially **free and invite-only for verified organisations**, with no assumption of monetisation or guaranteed partner demand.

**API direction (critical):** `Employer / authorised ATS -> OverseasJob.in`. This is **not** a generic public feed of all OverseasJob.in jobs for other boards. Third-party imported jobs (Jobicy, Himalayas, affiliate feeds) **must never** be redistributed via this API. Optional future read-only exports of directly submitted jobs require explicit employer distribution consent and independently verified destination licences.

| Method | Versioned endpoint | Use |
|---|---|---|
| POST | `/api/v1/partner/jobs` | Submit owned job, idempotent retries; pending review |
| GET | `/api/v1/partner/jobs` | List caller organisation's jobs, paginated |
| GET | `/api/v1/partner/jobs/{job_id}` | Read one owned job/status |
| PATCH | `/api/v1/partner/jobs/{job_id}` | Edit owned job; material changes may re-enter review |
| POST | `/api/v1/partner/jobs/{job_id}/close` | Close/soft-unpublish immediately |
| GET | `/api/v1/partner/usage` | Scoped integration quotas, status and counts |

**Contract rules:** OpenAPI 3.1 schema in `08_PARTNER_JOB_POSTING_API_OPENAPI.yaml`. Requests JSON, UTC timestamps, explicit external-id and idempotency key. `201` returns `pending_review`, not unverified `published`. Tenant ownership and scope enforced for every route. API keys are high-entropy, one-time revealed, server-stored as hashes, revocable, rotatable and never included in browser JavaScript. Illustrative pilot rate limits: 60 requests/minute/token and 10 new jobs/day per new organisation; adjust through safe configuration, use `429 + Retry-After`.

**Developer integration:** Public `/developers` docs + OpenAPI contract after readiness, a client testing guide with placeholder tokens, and a dashboard to issue/revoke keys **only** to verified organisation admins. Do not launch public free-for-all API key signups. A self-service recruiter may request API access but does not automatically receive a key.

**Example response:** `POST` accepted `201 { "id":"job_...", "status":"pending_review", "public_url":null }`. Only after approval is a public URL created. Keep a traceable audit trail of submit, review, edit, close and token use without leaking secrets or candidate data.

**Security / launch criteria:** OWASP API Security risk review; per-object and per-function authorisation; mass-assignment rejection; idempotency replay/conflict handling; `401/403/404/409/422/429` behaviour; domain-verified redirects; API token rotation/revocation; abuse throttling and emergency disable; no provider-feed data leakage in public/partner endpoints. No CORS wildcard for sensitive write routes. No paid external middleware is assumed.

**Cost impact:** PHP/MySQL tables plus existing HTTPS/cron, no new recurring service if the actual shared-hosting plan handles it. Email verification, support and abuse handling may introduce genuine operating work; if so, defer rather than compromise verification. See `07_RECRUITER_LITE_AND_PARTNER_API.md` for full workflow, data and acceptance criteria.

---

# 4C. Career Decision Companion (v1.3 core product)

This is the **primary differentiator to test**, not a late AI add-on. Implement exact UI, data, privacy and tests from `10_DECISION_COMPANION_PRODUCT_SPEC.md` before declaring the Phase 1 public job experience complete.

**First-use pathway:** role → work arrangement (remote-from-India / region-restricted or unknown remote / verified on-site abroad) → preferred region → relevant source-linked results → Job Decision Card. Save locally only after showing value; no candidate account or database required.

**Job Decision Card fields:** source label and original apply destination; `published_at` if provided and *separate* `first_seen_at`, `last_seen_at`, `last_checked_at`; factual location/work model; India eligibility state `explicitly_allowed|explicitly_not_allowed|unknown` plus evidence pointer/URL and source wording; visa support state `yes|no|unknown`; salary provenance and gross/net basis; explainable match reasons; relevant savings/offer calculator; clear next action. Unknown never becomes “verified”, “worldwide” or a numeric success score.

**Opportunity Radar:** public feed sync occurs independently of visitors. A browser-local profile evaluates the current published catalogue on each visit, filters by explicit eligibility, compares with an on-device last-seen job ID/version set, and shows “new/changed/none”. Apply click is **not** application submission: user must explicitly mark Applied. Local profile supports JSON export/import, complete deletion, device-loss warning and no PII in analytics. Email/push monitoring while offline is **out of scope** until separately approved account/delivery/privacy infrastructure exists.

**Empty state:** Show “No newly confirmed matches today” with a way to broaden *known* filters and 1–2 genuinely relevant original tools/guides. Do not invent jobs, claim the feed continuously scanned for the individual, or create manipulative daily streak obligations.

**Evidence gate:** Before building large-scale personalised features, sample real permitted API responses over 14 days in 2–3 priority roles. Report explicitly India-eligible, explicitly ineligible, unknown, duplicates, closure evidence, apply-target validity and source-licence caveats. If supply is poor, position the site primarily as a *career decision utility*, not a promise of daily India-eligible jobs. No fabricated coverage thresholds or sample counts.

**Data rights:** Himalayas imported jobs are never exported/resyndicated/marked with `JobPosting` structured data. Free Jobicy URLs remain canonical source links; disappearance from a recent-window feed is not closure evidence. All third-party pages use source-specific rendering/indexing/ads policies and are not bulk SEO assets.

---

# 5. The ten free utilities: full product requirements

All tools must be **usable without account**, keyboard-accessible, mobile-friendly, with privacy notices and honest assumptions. Prefer client-side JS and local browser storage. If a tool cannot provide reliable information without a maintained external dataset, require user-entered values or link to official information instead of inventing numbers.

## T01 — Overseas Salary vs Living Cost & Savings Calculator

**Need:** “A Dubai/Germany offer looks large in INR; can I actually save more?”

**Inputs:** Destination country/city (optional label), payment currency, gross/net monthly salary (explicit choice), estimated tax/deductions (user-provided percentage/value, optional), rent, food, commuting, utilities, insurance, dependants, one-time costs, user-supplied FX conversion rate and date.

**Outputs:** Estimated monthly disposable income, estimated savings, savings %, annualised amount, cost breakdown chart, assumptions and printable/shareable summary.

**Rules:** Never silently treat gross as net; never invent live tax, cost-of-living or exchange rates. User may manually update assumptions; sample values must be visibly labelled as illustrative. Negative savings should show a warning, not false positivity.

**Acceptance:** Works offline after page load; zero/negative guardrails; currency precision; unambiguous gross-vs-net statement; calculator results not sent to server by default.

## T02 — Global Job Offer Comparison

**Need:** “Which of two real offers is better for me?”

**Inputs:** Offer A/B base salary, currency, pay frequency, deductions, bonus (guaranteed vs conditional), accommodation, insurance, leave, relocation/visa costs, employer-provided benefits, working hours, user-provided FX.

**Outputs:** Side-by-side estimated cash and non-cash components, net estimate, monthly savings scenarios, pros/cons prompts, downloadable decision summary.

**Rules:** Separate guaranteed compensation from variable compensation, and financial figures from subjective features. Never label an offer ‘legitimate’ or visa approved based on entered numbers.

**Acceptance:** Correct currency conversion, annualisation and optional benefits; missing benefits show unknown.

## T03 — Resume & Cover Letter Kit (No paid AI)

**Need:** “I need a professional international-format resume and cover letter without paying.”

**Features:** Three accessible, ATS-readable templates; role-focused checklist; actionable resume writing guidance; browser-only text editor; export to PDF via print stylesheet, plus plain text/HTML download. Cover letter structure with fillable sections. Optional link to official application requirements.

**Rules:** No unsupported ‘ATS score 95%’ claims. No fabricated skills or experience. No résumé storage/upload by default, no mandatory email collection. Export should not include ad content.

**Acceptance:** Correct A4/Letter printing; no text clipping; copy/paste; mobile editing; no forced sign-up.

## T04 — Relocation Budget Planner

**Need:** “How much should I have ready before and after moving abroad?”

**Inputs:** Airfare, visa/permit costs entered by user (not fixed official fees), document translation, initial deposit, accommodation, first-month living costs, emergency reserve, family, arrival transport and contingency.

**Outputs:** Pre-departure cost, arrival cash needed, suggested reserve under assumptions, adjustable what-if scenarios.

**Rules:** Not immigration advice; never claim any listed cost is an official visa fee unless sourced, dated and reviewed.

**Acceptance:** User can change every input and save/export privately.

## T05 — Global Time Zone & Work Overlap Calculator

**Need:** “Can I collaborate with a UK or US team from India?”

**Inputs:** Two or more IANA time zones, working-hour ranges, preferred meeting duration, weekdays.

**Outputs:** Overlapping hours, suggested slots and local times; daylight saving time (DST) handled via built-in `Intl` APIs / IANA timezone data available in runtime.

**Rules:** Never apply fixed UTC offsets for time zones that observe DST. Show the actual date of comparison.

**Acceptance:** Test UK/US DST transitions, Asia/Kolkata fixed offset, overnight shifts, no overlap.

## T06 — Job Application Tracker (Local-first)

**Need:** “Where did I apply, and when should I follow up?”

**Fields:** Company, role, link/source, applied date, status (saved/applied/interview/offer/rejected/closed), notes, next reminder date, work location.

**Features:** Manual entry, one-click Save from portal, filter/sort, CSV/JSON import/export, delete-all, optional browser notification only with explicit opt-in and supported environment.

**Rules:** Store in localStorage/IndexedDB by default; warn that browser/device changes or clearing storage may delete entries; no cloud sync promise. Never imply an external application was submitted through OverseasJob.in.

**Acceptance:** 50 sample records; offline usability; export/import round trip; safe handling of malicious links; accessible statuses.

## T07 — Free Interview Practice & English Communication

**Need:** “I want to practise interviews without an expensive AI tool.”

**Features:** Curated role-specific questions (starting with IT support, customer support, administration), answer-planning prompts, response timer, self-review rubrics, English vocabulary/phrasing, optionally browser speech recognition **only if available and consented**, with clear limitations.

**Rules:** No paid LLM dependency; no fabricated hiring success prediction; audio remains local unless user expressly opts into a separately approved service.

**Acceptance:** Works in text-only mode even when mic permissions are denied; accurate accessibility controls.

## T08 — Country Document & Readiness Checklist

**Need:** “What do I need to prepare before applying abroad?”

**Features:** Country-specific generic preparation checklist: identity documents, qualification evidence, translated certificates, language proof, employment contract, insurance and official resources. Let user tick own progress locally.

**Rules:** Country rules differ by visa/category and can change. Every rule-related item needs official source URL, last-reviewed date and caveat; legal eligibility must not be decided automatically. Do not upload passports/identity cards into MVP.

**Acceptance:** Clearly differentiated general checklist vs official mandatory requirement; old pages flagged for review.

## T09 — WorkProof Portfolio Generator (later phase)

**Need:** “How can I present evidence of skills if I have little work experience?”

**Features:** Generate static downloadable portfolio from user-entered projects, descriptions and URLs; clearly mark self-reported vs externally verified evidence (no ‘verified’ feature at launch); link to GitHub or website entered by user.

**Rules:** No fake certifications or employer badges, no unconsented public profiles. Browser-only export at first.

**Acceptance:** User reviews before sharing; no sensitive default fields; downloadable static HTML/PDF.

## T10 — Career Roadmap Builder (later phase)

**Need:** “What should I learn to become ready for a target role?”

**Features:** Curated role-to-skills maps, 30/60/90-day learning plan, portfolio practice suggestions, free official learning references, user-defined schedule.

**Rules:** Rule/template-based at launch; no AI API; link sources and update dates; do not claim employment guarantee.

**Acceptance:** Role selection produces actionable roadmap with an edit/export feature and no mandatory registration.

## 5.1 Shared tool design system

A consistent shell: one paragraph explaining the user's problem; editable fields with examples; a clear Calculate/Generate action; results with assumptions; reset; export/print; privacy note; 2–3 related articles/jobs. Fast LCP, mobile layout, correct form labels, no dark patterns, no ads inside input controls.

---

# 6. Country & overseas readiness knowledge base

Start with **India-to-UAE** and **India-to-Germany** *information guides*, not claims of available sponsored jobs. Add country pages only after original, researched content is ready.

Each guide needs: who it helps; general work/remote distinction; official job-search and government links; document/credential questions; language considerations; cost calculator link; scam warnings; last-reviewed date; editor notes; disclaimer and correction/report link.

**Strict source order:** destination-country government/embassy/official employment portals → India's MEA/eMigrate and other official sources → reputable public statistical sources → clearly labelled third-party explainers. Never automatically rewrite visa rules from blogs as facts.

**Content review policy:** every 90 days for evergreen pages, sooner if a government policy changes. If review cannot happen, display visible last-reviewed date and restrict sensitive assertions; for a major change, unpublish outdated guidance rather than leave misinformation.

**Safety module:** “Avoid job scams” checklist; suspicious fees, asking for original passports, unverifiable employer identity, demands for immediate transfer, impersonated domains. Link users to official verification/reporting channels. A page displaying safety tips is not an actual government or employer verification service.

---

# 7. Daily Arena: retention without gimmicks

**Launch one original game only:** `WorldWords` (daily global workplace vocabulary/logic clue) OR `LogicSprint` (original daily logic puzzle). Use deterministic content seeded by date in server time zone plus a reviewed content bank; avoid copyrighted LinkedIn puzzle clones.

**Core loop:** Open today's game → solve in under 3 minutes → view explanation and optional shareable result → optionally check career tool / job match. Local-only streak tracking, no forced account. Show how scores work and reset with date; allow keyboard controls and screen-reader labels.

**Anti-manipulation rules:** no paid streak rescue, gambling, job-ranking advantages from game scores, ad-click rewards, excessive reminders, or forced sharing. No ads adjacent to rapid-tap input or answer controls.

**Measurement:** Daily game users, D1/D7 return, meaningful transition to tools, user satisfaction; if no measurable utility beyond vanity clicks, do not build a game library.

---

# 8. Monetisation: ads first, partner revenue only if approved

## 8.1 AdSense

- Account/site must be accepted; no approval or revenue is promised.
- Place ads on substantive original pages. Avoid ad-heavy thin imported job detail pages; no ads in calculators' essential controls, job Apply buttons or game interaction zones.
- Honor consent/privacy requirements and applicable personalised-ad settings.
- Observe AdSense publisher and replicated-content policies. Source licenses permitting syndication **do not** guarantee Google will allow ads or index the pages.
- Publishing original tools, relevant commentary and reviewed guides is the core monetisable content strategy.

**Income math (hypothetical Page RPM, not a forecast):**

| Page RPM assumption | Pageviews needed for ₹50,000/month | Approximate daily pageviews (30-day month) |
|---:|---:|---:|
| ₹50 | 1,000,000 | 33,333 |
| ₹100 | 500,000 | 16,667 |
| ₹200 | 250,000 | 8,333 |
| ₹300 | 166,667 | 5,556 |

Page RPM = revenue ÷ pageviews × 1000. Values above are illustrative; they are **not promised India or US rates**. Early revenue may be zero for months.

## 8.2 Affiliate / partner jobs

- Launch with **zero assumed CPC** from free feeds.
- Evaluate approved Careerjet/Jooble-style publisher relationships only **after** useful traffic exists. Record approval emails, regions, payment threshold, attribution rules, eligible-click definitions and expiry of agreement.
- Use `sponsored`/`affiliate` labels where required; track outbound link events only with privacy-respecting methods. Do not incentivise clicks, redirect without disclosure or overwrite partner URLs.
- No speculative commission table in the real dashboard. If no partner approved, hide all affiliate revenue UI.

## 8.3 Future optional revenue (not launch requirements)

Original sponsored career events (clear disclosure), verified business advertising, optional paid exports only if users request value. Avoid candidate recruitment fees and anything requiring placement licensing without specialist legal review.

## 8.4 Founder's business dashboard

Track: total sessions, engaged sessions, traffic source/country, tools started/completed, top landing pages, original content performance, outbound Apply CTR, provider sync health, returning users, AdSense approved/rejected, actual page RPM when available, reported/closed jobs. Use Google Analytics / Search Console only after privacy configuration and if founder accepts their terms. Do not present visitors or ad earnings estimated from fake data as actuals.

---

# 9. Traffic acquisition and search strategy

**Critical business risk:** Automation supplies jobs, not visitors. Traffic acquisition is uncertain and requires occasional product/content decisions.

## 9.1 Search strategy

- Focus on tasks with intent: “Dubai salary and expenses calculator”, “compare overseas job offers”, “India US work overlap”, “job application tracker without signup”. These are **candidate topics**, not verified ranking opportunities.
- First publish about 6–10 carefully researched original guides around the tools; expand only when Search Console shows actual demand and users complete tasks.
- Important pages must offer substantial useful content, meaningful examples and verified official references.
- Noindex feed-only third-party job pages by default, noncanonical filtered search combinations, and other thin near-duplicates. Assess other indexing options case-by-case under provider terms.
- Correct HTML titles/metas, canonical links, breadcrumbs, internal links, sitemaps (only useful indexable pages), `robots.txt`, no broken links, mobile usability.
- Do not add Himalayas content to Google Jobs via JobPosting structured data or syndicate that provider to others. `JobPosting` schema **off by default on imported partner listings**.
- Track real search performance; treat SEO as an experiment, not guaranteed automated growth.

## 9.2 Organic sharing

Public calculators' non-sensitive result summaries (opt-in share), one original game share card, clear source links, beginner-friendly guides. No automated unsolicited emails, social DMs, comment spam or fake accounts.

## 9.3 Content editorial calendar (initial suggestion)

1. India-to-UAE: how to compare an offer after living costs (original calculator walkthrough).
2. India-to-Germany: document questions and official starting points (dated sources).
3. Understanding “remote worldwide” vs “remote US-only”.
4. How to read overseas compensation packages without overestimating savings.
5. Avoiding common foreign job scams: official verification steps.
6. How to track applications from many portals without giving away your data.
7. Time-zone overlap for India + UK + US with DST examples.
8. Resume template example: IT support role, honest skill description.
9. What employers may mean by “relocation assistance” vs “visa sponsorship”.
10. A printable offer-comparison checklist.

Human verification of high-stakes facts is mandatory; AI may assist drafting but not publish policy claims unattended.

---

# 10. Technical plan for an existing shared-hosting budget

## 10.1 Architecture decision (ADR-001)

**Preferred lightweight stack if Hostinger plan supports it:** PHP 8.2+ server-rendered pages + MySQL/MariaDB (or SQLite if supported), vanilla JavaScript / small modular CSS, server-side scheduled PHP cron scripts, no paid external backend, no always-on Node process, no paid AI. Verify actual hosting plan's PHP, database, scheduled job and storage limits before coding/deploying. Hostinger documents cron support but plan limits vary.

**Alternative if PHP/database not available:** Static HTML + built-at-deploy JSON snapshots generated by a free, permitted scheduler/CI where quotas and terms allow; store local-only tracker; accept less flexible search. Do **not** build unsupported background worker infrastructure.

**Critical design principle:** Fast public pages still load when remote APIs fail. The browser never calls third-party job APIs for every user visit. Scheduled backend fetch populates cache, and public search uses local data.

### Logical components

`Official provider APIs` → `Cron sync workers` → `validation + source rules` → `local jobs DB` → `PHP search/detail pages` → `anonymous browser users`.

`Browser JavaScript` → `private role preferences / Radar / compare / tracker / games` → `device-local state and JSON export/import`; personalised matching runs on visits, **not offline**.

`Reviewed content files` → `original guides/tool explanations` → `SEO/AdSense-ready pages`.

`Cron health report` → `error dashboard + low-volume alert` → `founder/AI maintenance agent`.

## 10.2 Data model (simplified)

**providers:** `id, slug, name, policy_url, terms_checked_at, enabled, source_credit_label, sync_interval_minutes, apply_url_field, allow_jobposting_schema, require_attribution, restrictions_json, last_success_at, last_error_at`.

**provider_jobs:** include original source/apply URLs, source policy ID, origin=provider, status and exact evidence/eligibility and timestamps (`published_at`, `first_seen_at`, `last_seen_at`, `last_checked_at`, `status_checked_at`); missing eligibility is **unknown**. Public `JobView` explicitly maps provider jobs and future employer-owned jobs without flattening rights or source links. See `06_ARCHITECTURE_AND_DATABASE.md` and `10_DECISION_COMPANION_PRODUCT_SPEC.md`; the earlier illustrative `jobs` table is *not* a deployable unified migration.

**sync_runs:** `id, provider_id, started_at, ended_at, outcome, pages_fetched, fetched_count, imported_count, updated_count, error_count, error_summary`.

**country_guides:** can begin as Git-tracked Markdown/content files rather than DB rows; include `source_urls` and `last_reviewed_at` front matter.

**reports:** `id, job_id, report_type, free_text_sanitized, created_at, status` with rate limiting and strict retention if user reports are enabled.

**No candidate accounts in the public MVP.** User preferences, application tracker and game progress remain on-device. Future Recruiter Lite organisations/members/credentials are a separately approved, gated storage and identity subsystem; no candidate CV, passport or payment collection.

## 10.3 Security rules

- Prepared SQL statements, strict validation/escaping of query params, HTML sanitize allowlist, CSP with sensible policies, CSRF protection where POST forms exist, rate limiting, no remote images from untrusted domains by default.
- HTTPS, security headers, no API credentials in client JS, least-privilege DB account, administrative endpoints restricted, no unauthenticated import trigger.
- Validate outbound redirect destinations and allowlist provider hostnames/URLs as required by agreements; prevent open redirects and JavaScript URLs.
- Admin operations protected; content and logs redact private data; limit retention and keep secure periodic backups within available storage.
- No upload functionality in initial build; portfolio/resume generation browser-side.
- Recruiter expansion: store scoped API token hashes only, enforce tenant/organisation object-level authorization and explicit writable fields. Gate API issuance on verified employer approval; throttle, audit and reject suspicious outbound job URLs. Do not create anonymous posting endpoints.
- Source data may contain malicious HTML/URLs; treat all external feed fields as untrusted.
- Respect privacy law and cookies/consent; DPDP requirements must be reviewed for actual processing activities and implementation timeline.

## 10.4 Performance and accessibility

- Mobile-first, semantic headings, labelled inputs, accessible focus, keyboard navigation, sufficient contrast, reduced-motion support.
- Target Core Web Vitals: LCP ≤2.5 s, INP ≤200 ms, CLS ≤0.1 at 75th percentile as performance goals (not guaranteed).
- Cache search results, index frequently filtered fields, paginate 20–30 jobs at a time, compress assets, lazy-load nonessential visuals, eliminate heavy JavaScript libraries.
- Return sensible empty results with filters to broaden search; never display fake jobs.

## 10.5 Automation schedules (proposal, adjust to provider limits)

| Job | Initial cadence | Error behaviour |
|---|---|---|
| Jobicy feed sync | Every 12 hours | Keep last healthy cache, alert after repeated failures |
| Himalayas feed sync | Daily + targeted per-job status checks under quota | Do not purge if a partial/failed traversal |
| Provider status refresh | Daily for eligible records, batched/rate-limited | Mark last verified; don't equate API downtime with closure |
| Expiry cleanup | Daily | Hide confirmed expired, retain audit metadata |
| Sitemap regeneration | After reviewed content publication | Only index-worthy routes |
| Broken outbound link sampling | Daily/weekly under provider terms | Flag for follow-up, avoid aggressive HEAD/GET crawling |
| Backup & retention | Daily/weekly depending on hosting | Alert on failure |
| Analytics summary | Weekly | Report actual data only; no invented results |
| Source terms check | Manual assisted, monthly and on detected change | Disable providers on material uncertainty |

No cron task should directly send large volumes of email, republish social feeds, or mass-generate SEO pages.

---

# 11. Automation scenarios and failure handling

| Trigger | Automated action | What still needs human review |
|---|---|---|
| New API listing | Normalize, attribute, deduplicate, cache, apply eligible filters | Suspicious/ambiguous job patterns as needed |
| Listing closed in official status API | Hide listing, disable Apply, log reason | Disputes about closure |
| Status unknown | Flag for later check, hide if too stale | Ambiguous sources |
| Provider 429 or 5xx | Retry with capped exponential backoff, then fallback cache | Persistent outage and commercial terms |
| Job report submitted | Save anonymized report under retention limit, optionally quarantine high-risk link by strict automatic rules | Genuine false positives and safety complaints |
| Currency tax guide date passes | Mark “review needed”, avoid treating data as current | Official rule updates |
| AdSense not approved | Keep ads disabled; improve original content and compliance | Review and reapply when appropriate |
| Daily game date changes | New deterministic puzzle and local streak update | Content-bank quality and bugs |

**Red flag:** Any feature marketed as “fully automatic overseas verified jobs”, “guaranteed affiliate income”, or “automated AdSense approval” violates this blueprint.

---

# 12. Monetisation and analytics instrumentation

**Events (privacy-conscious, no applicant PII):** `job_search`, `filter_used`, `job_detail_view`, `apply_external_click` (provider/category only), `tool_open`, `tool_complete`, `tool_export`, `arena_play`, `arena_complete`, `guide_read`, `report_job_submitted` (no raw report text in analytics).

**Consent:** disable optional analytics/ad personalised tracking until configured appropriately. No fingerprints or employer contact harvesting.

**Weekly dashboard:**
- Organic search impressions and clicks by useful original page (Search Console).
- Tool completion count and visitors’ return rate.
- Jobs served, stale jobs, feed error rate, outbound apply click rate.
- AdSense status, actual page RPM and revenue when approved.
- Top issues and recommended small actions.

**KPIs and thresholds are experiments, not market forecasts:** aim for 98% successful scheduled sync attempts, <1% invalid outbound links on sampled checks, majority useful tools finishing on mobile, nonzero returning visitors, and validated usefulness before expanding. Performance and retention targets should be tuned from measured baseline.

---

# 13. Build phases and dependencies (90-day target, not guaranteed timeline)

## Phase 0 / Gate 0 — verify infrastructure, permissions and actual job supply

- Confirm domain DNS and hosting plan limits, PHP version, DB availability, cron and backups.
- Verify source terms live and record them; create source restrictions config.
- Sample 14 days of real feed output for 2–3 launch roles; quantify explicitly India-eligible, ineligible, unknown, duplicates and source-linked Apply coverage; do not claim a complete job inventory.
- Decide temporary public site structure and content owner.
- Establish repository with `.env.example`, tests and deployment documentation.
- Produce a privacy/terms disclaimer draft and plan legal review for regulated overseas activities.

**Exit gate:** source rules documented; demo job import works without public deployment; budget remains ₹0 additional recurring fees.

## Phase 1 — Lean public MVP

- Accessible homepage, 30-second no-login career selector, Decision Cards, tools index and jobs search (Jobicy + optional Himalayas), source credits and external Apply.
- 3 complete tools: salary savings, offer comparison, time-zone overlap. (If development is constrained, launch just 2 but no broken placeholders.)
- 5 original sourced guides; About, Contact, Privacy, Terms, Disclaimer, Report Issue pages.
- Scheduled global source sync, eligibility evidence, date semantics, status/expiry safeguards, noindex for imported thin pages, sitemap and privacy-safe analytics. Local preferences may launch here only if usable and tested.

**Exit gate:** real-source jobs displayed under terms, Job Decision Cards accurately distinguish confirmed/ineligible/unknown, no fake listings, tool calculations tested, no account/payments, pages stable on mobile.

## Phase 2 / Gate 2 — local-first Opportunity Radar and utility depth

- Local-first Opportunity Radar, preferences and new-since-last-visit comparison; manual application tracker with JSON import/export/delete, downloadable calendar follow-ups; resume kit and relocation budget; source freshness monitoring and weekly summary.
- Explicitly do not promise personalised email/push alerts or remote application-status polling without later authorised accounts/integrations.
- Enhance search/eligibility filters and add additional reviewed guides.
- Apply for AdSense when site has enough original value and passes preflight; no presumption of approval.

**Exit gate:** real users complete tools; source sync failures handled without breaking site; privacy and ad placement audited.

## Optional branch Phase 2B — verified Recruiter Lite pilot (only after core Gate 2 and objective trust gates)

- Add employer-only registration, email/domain verification, basic company profile, job create/edit/close, expiry, and safe external apply.
- Keep new organisations/overseas job postings review-gated; no anonymous posting. Do not accept candidate resumes.
- Rate-limit, deduplicate, hold suspicious jobs, track low-volume exception digest and emergency kill switches.
- Pilot with 3–5 legitimate organisations; disable if reviewer workload or scam-risk exceeds safe capacity.

**Exit gate:** Recruiter-owned jobs are safe, accurate, easily closed, and not confused with third-party feeds; cost stays within approved infrastructure. **Skipping this phase is allowed** if the founder cannot maintain trust checks.

## Core Phase 3 / Gate 3 — retention experiment and demand-led utility expansion

- One original Daily Arena game; curated interview kit, country checklist, browser-only WorkProof and roadmap when quality can be maintained.
- Accessibility/usability testing; improve pages that show actual demand.
- Explore publisher affiliate accounts after demonstrable traffic; keep unapproved integrations off.

**Exit gate:** assess 7/30-day return, mission-to-career-action movement and actual feature use; pause games or tools without evidence of value, and avoid increasing owner workload.

## Optional branch Phase 3B — inbound Partner Job Posting API (only after Phase 2B pilot)

- Build authenticated versioned `/api/v1/partner/jobs` create/list/read/edit/close and `/usage`; maintain OpenAPI reference.
- Issue invite-only per-organisation scoped API keys with one-time reveal, hashing, expiry, rotation and revocation.
- Verify idempotency, ownership checks, quotas, error codes, audit logs, moderation gates and ability to close every listing.
- Publish developer docs only when API is production-ready; third-party provider feed data is not available for resale or resyndication.

**Exit gate:** API contract tests and OWASP review pass, cross-tenant and third-party-feed leaks impossible in test, no bypass of job verification. **Remain disabled if unaffordable to operate safely.**

## Phase 4 — Expansion conditional on traction

- Additional source partnerships with written terms; more country guides; local language additions; optional account sync only if users ask and legal/privacy support exists.
- Full employer ATS, candidate applications, custom AI, complex social moderation, native apps and a full social network remain **out of scope without a paid/research case**. Recruiter Lite and inbound API are the explicitly limited exceptions in Phases 2B/3B.

---

# 14. Requirements & acceptance criteria (implementation contract)

**v1.3 first-user-action additions (functional):**

- FR-15: Within a short no-login flow user can choose work path and see jobs with verified/unknown eligibility semantics; no unsupported “India eligible” claims.
- FR-16: Every usable Job Decision Card has visible source, work mode, evidenced eligibility state, separate date labels, explainable reasons, required Apply link and relevant next-step tools.
- FR-17: Public ingestion refresh and browser-local per-user matching are separate; no offline personalised alert claims without accounts.
- FR-18: Radar distinguishes first_seen/changed/seen locally, handles zero results, stores no raw candidate PII in server metrics, and supports export/import/delete.
- FR-19: External Apply click never auto-sets Applied; only the user can add/change their application status.
- FR-20: Real 14-day feed coverage report gates any “daily India-eligible matches” marketing claim; source policy and freshness are tested at provider level.

**Functional (FR):**

- FR-01: Anonymous users can browse jobs, filter and open source links in ≤3 user actions from homepage.
- FR-02: Every imported job displays its provider, actual apply target and last-check timestamp.
- FR-03: No job displays eligibility/sponsorship claims without source support.
- FR-04: Scheduled imports are idempotent, enforce provider quotas, log outcomes and preserve cache on failure.
- FR-05: Confirmed closed/expired jobs cannot be applied to from an active listing.
- FR-06: The ten tools meet their per-tool specifications; initially only Phase 1 tools may be live, while unreleased tools are not falsely presented as usable.
- FR-07: Application tracker is stored locally, exports/imports correctly and can delete all data.
- FR-08: All official-country requirement pages have source URLs and last-reviewed dates.
- FR-09: Ads disabled by default until approved; game controls have safe ad-free interaction zone.
- FR-10: No account, paid service, or optional marketing consent is required to see jobs or operate tools.
- FR-11 (Recruiter Lite gated): Only verified employer accounts may submit employer-owned jobs; pending jobs stay unpublished; recruiter can close immediately.
- FR-12 (Partner API gated): Versioned create/get/list/patch/close endpoints follow the OpenAPI contract; every request is scoped to a verified organisation and may be refused/revoked.
- FR-13 (Rights): Jobs imported from external sources cannot appear in partner export endpoints; apply URLs and source restrictions survive all transformations.
- FR-14 (Abuse): Posting uses expiry, rate limits, duplicate checks, first-job review and emergency suspension; no paid candidate application flow.

**Non-functional (NFR):**

- NFR-01: WCAG 2.2 AA as a design/test target, keyboard navigable core journeys.
- NFR-02: No secret/API token shipped in client-side assets; secure headers and prepared SQL.
- NFR-03: Database backups, recovery instructions and logs have a verified restoration drill.
- NFR-04: Core search/tools remain useful under third-party provider outages.
- NFR-05: Mobile page speed and Core Web Vitals actively monitored.
- NFR-06: External license and advertising compliance are release-blocking.
- NFR-07 (Employer/API): Object/function-level authorisation, hashed rotated API secrets, idempotent writes, explicit write allowlists, audit events and safe `429` behaviour are release blockers.
- NFR-08 (Pilot): Recruiter/onboarding features must be feature-flagged and stay disabled until verification and exception-handling can be sustained.

---

# 15. Test plan: must-pass scenarios

**Additional optional recruiter/API regression suite (mandatory before enabling modules):** verified-employer signup, cross-organisation job ID access denial, foreign-org PATCH/close denied, API token revoked/expired, leaked secret not logged, status field injected, duplicate/idempotency conflict, job phishing URL, first job pending review, overseas recruiting-agent compliance hold, scheduled expiry, edit triggers review, read-only external feed not exported, kill-switch and restore drill. See `07_RECRUITER_LITE_AND_PARTNER_API.md`.


1. Import valid Jobicy jobs and retain exact canonical URL.
2. Import Himalayas jobs; Verify Apply uses `applicationLink`, never ATS bypass.
3. Assert imported Himalayas jobs do **not** produce `JobPosting` structured data or export feeds.
4. Simulate API timeout, 429, invalid JSON and empty success; public site remains usable.
5. Simulate Jobicy record leaving a bounded latest-results feed while still open; it must not be marked closed based only on absence.
6. Test Himalayas documented expiry and stale/unknown states; prohibit undocumented per-job 200/410 status requests.
7. Reject malicious `javascript:` external URL, encoded redirects and HTML scripts in descriptions.
8. Deduplicate re-imports and retain correct provider credit on cross-source same role.
9. Filter “India eligible” excludes US-only jobs; unknown eligibility not treated as India eligible.
10. Salary tool tests annual/monthly conversion, gross-vs-net, zero denominators, negative savings, decimal currencies.
11. Offer tool distinguishes guaranteed and conditional payments.
12. Time-zone tool tests DST week for UK/US and India time.
13. Tracker data survives reload, exports/imports without loss and deletes cleanly.
14. Templates export to printable PDF without cut-off and with no ads.
15. Interview tool works with no microphone.
16. Country checklist shows dated official source and uncertainty warning.
17. Game puzzle refreshes once per day, score/streak local, accessible by keyboard.
18. Ad placeholders never cover Apply button, controls or game answers.
19. Search/indexing: tools and reviewed guides indexable; filter permutations and imported thin jobs not indexable by default.
20. Source outage, restored backup and scheduled health reporting are tested in a staging environment.

**Release-blocking failures:** external API terms violated, source apply URL incorrect, fake job eligibility, sensitive leak, stored XSS, unexpected paid API requests, unsafe advertisement placement, or broken privacy controls.

---

# 16. Launch checklist / founder handover

**Product:** no placeholder jobs, no false stats/testimonials, complete working primary journeys, readable mobile UI, accessible forms.

**Sources:** current provider terms rechecked, apply/source attribution visible, required URLs used, dates/expiry reliable, no accidental resyndication.

**Infrastructure:** domain+HTTPS, cron enabled, `.env` secure, DB backups/restoration tested, error logging and alerts, security headers, dependencies pinned.

**Privacy/legal:** About/Contact, Privacy/Cookies/Terms/Disclaimer, report/complaint method; no résumé/passport collection, site not claiming to be official recruiter, legal review if recruitment services added.

**Search/ads:** robots and XML sitemap, tested noindex rules, original indexed content, Search Console property, ad placements conditional upon approval, no forced ad clicks.

**Founder operations:** one-page admin SOP: how to disable feed, interpret sync health, restore backup, update country guide, replace a broken source, export metrics, check ads.

---

# 17. Minimal ongoing human work (the honest operating model)

Automate routine import and monitoring; reserve **a short weekly review window** when possible for: feed failures, unsafe jobs, top pages/visitor behaviour, external terms and content corrections. High-stakes country/visa guidance and legal compliance **must never be left to an unattended AI publishing loop**. A significant outage, complaint or source-policy change may require extra work. The goal is not zero work; it is **small, controlled, mostly exception-based work**.

Expected routine work: review alerts, verify a sample of outbound jobs, check Search Console, review user issue reports, approve any new guide or monetisation partner. Use an AI agent for diagnosis and patch proposals, with automated tests, but do not grant unrestricted live deploy or spending access.

---

# 18. Risks and contingencies

| Risk | Likelihood/impact (qualitative) | Mitigation |
|---|---|---|
| No traffic despite content | High business impact | Start with original high-utility tools, test real query demand, iterate |
| AdSense disapproval | High business impact | Original substantial content, no copied thin pages, policy-first layouts |
| API restrictions or discontinuation | Medium/high | Provider adapters + disabled-on-error config + alternative utilities |
| False or expired jobs | High user trust impact | Status refresh, source credit, reporting, stale hide rules |
| Overseas recruitment legal exposure | High | Information-only initial model; specialist review before placement |
| Developer/agent bugs | High | Small codebase, unit/integration tests, staging, rollback and backups |
| Privacy breach | High | No accounts/uploads; local-first storage; minimal analytics |
| Excess maintenance | Medium/high | Deliberate feature limits; measured scope; no manual marketplace |
| Currency/tax advice mistaken | High personal impact | User-entered assumptions, warnings, sourced dates |
| Poor game retention | Low/moderate | One original game pilot, cancel if no practical value |

---

# 19. Decision rules: when to scale, pause, or pivot

**After 30 days live:** Are core tools functioning, jobs accurate, and any users completing meaningful actions? If not, fix UX/sources rather than add features.

**After 60–90 days:** Evaluate real impressions, engaged visitors, return rate, AdSense readiness and hosting overhead. If indexable original pages get no impressions, inspect technical SEO and usefulness; if users abandon tools, improve functionality. Do not build more imported job pages as a reflex.

**Money gates:** No recurring expense without explicit founder approval. Do not add paid AI or paid affiliate technology to chase hypothetical future income. If an approved ad or affiliate arrangement eventually yields revenue, track **net** revenue and time cost, not gross screenshots.

**At ₹50,000/month:** Reassess costs, reliability, diversification and legal exposure before adding a larger marketplace.

---

# 20. Implementation backlog: exact AI-agent work packages

| ID | Priority | Work package | Definition of done |
|---|---|---|---|
| P0-01 | P0 | Inspect hosting and choose stack | Constraints documented; no new paid service |
| P0-02 | P0 | Create repository, coding standards, CI tests | Reproducible local setup and deploy guide |
| P0-03 | P0 | Design system/mobile layout | Keyboard + mobile QA complete |
| P0-04 | P0 | Build Jobicy adapter | Attribution, canonical URL, paging, backoff tested |
| P0-05 | P0 | Build Himalayas adapter | Apply link and no-JobPosting restrictions tested |
| P0-06 | P0 | Normalize DB, dedup and expiration logic | Safe transactional sync + status tests |
| P0-07 | P0 | Public search and job details | Honest eligibility, empty states, source actions |
| P0-08 | P0 | T01 salary savings | Maths and disclaimers tested |
| P0-09 | P0 | T02 offer comparison | Currency & bonus rules tested |
| P0-10 | P0 | T05 time-zone overlap | DST tests pass |
| P0-11 | P0 | Original trust/SEO guides | Five reviewed guides, source links, crawl validation |
| P0-12 | P0 | Legal, privacy, performance, backups | Launch gates green |
| P1-01 | P1 | T03 Resume Kit | Print/export privacy safe |
| P1-02 | P1 | T04 Relocation Budget | Inputs/export accurate |
| P1-03 | P1 | T06 Application Tracker | Local-first, import/export, delete |
| P1-04 | P1 | Analytics/alerts/AdSense preflight | Review-ready without assuming approval |
| P2-01 | P2 | T07 Interview Practice | Text-only, no paid AI |
| P2-02 | P2 | T08 Country Checklist | Official dates, offline local ticks |
| P2-03 | P2 | One Daily Arena game | Original, accessible, no ad interference |
| P2-04 | P2 | T09 WorkProof export | Self-reported evidence clearly labelled |
| P2-05 | P2 | T10 Career Roadmap | Curated editable plans |
| P3-01 | P3 | Approved commercial publisher feeds | Written authorisation and attributed earnings |
| R2-01 | P2B (gated) | Recruiter verification + organisation accounts | Verified domain, company check and audit trail |
| R2-02 | P2B (gated) | Employer create/edit/close and expiry | Owner-only jobs, pending review, immediate close |
| R2-03 | P2B (gated) | Posting abuse controls + review queue | Rate limits, quarantine, kill-switch, first-job review |
| R3-01 | P3B (gated) | Partner Job Posting API | OpenAPI routes and contract tests; scoped/rotatable secrets |
| R3-02 | P3B (gated) | API documentation and API usage | Verified partners only; no third-party feed redistribution |

**Task rule:** Each work package needs an implementation note, tests, deployment instructions, rollback, measured added maintenance cost and no policy shortcuts.

---

# 21. AI engineering agent contract

The user intends to use this document with Claude CLI, Codex or another coding agent. The agent must:

1. Read this whole blueprint and the source-policy matrix before touching code.
2. Inventory the existing repository/hosting without deleting or replacing anything without backup.
3. Submit architecture choice + exact free dependencies + risk assessment before implementation.
4. Implement in milestones; produce working code and tests for one milestone before the next.
5. Keep integrations modular and disabled until policy and terms verified.
6. Never use test/fake jobs or synthetic metrics in public production UI.
7. Never silently add paid SaaS, API keys requiring billing, hidden telemetry or external image assets.
8. Do not publish generated immigration advice or scraped copyrighted job text.
9. Use providers' exact apply links and comply with every attribution/republication rule.
10. Add automated tests for import expiry, eligibility, dangerous URLs, privacy, and noindex/schema.
11. Prepare one-command (or clearly documented) deployment + rollback within existing infrastructure.
12. At every step distinguish **implemented**, **tested**, **deployed**, **not implemented**, and **blocked on external legal/business evidence**.

**Implementation starts with Phase 0 only.** Do not construct the entire 10-tool product or the full marketplace in a single uncontrolled code change.

---

# 22. Founder-friendly FAQ

**Will jobs appear automatically?** Yes, after an authorised feed integration is built and working. Sources can change or stop, and the remote listings may not accept applicants in India.

**Will I earn for every Apply click?** No. Free job feeds generally give discovery data, not commission. Paid partner terms must be separately approved.

**Do users need accounts?** No for MVP. Tracker uses browser storage; cloud sync may be an optional later product.

**Will Google approve AdSense?** No guarantee. The website needs policy-compliant, valuable original content and acceptable ad placement.

**Can I reach ₹50,000 per month?** Possible at sufficient traffic/RPM, but there is no assured timetable. Follow the pageview scenario table, measure real RPM and iterate.

**Do all 10 tools launch together?** No. Three tools ship first; all ten remain in the project specification so the codebase can expand without losing the vision.

**Is OverseasJob.in a recruitment agent?** No, not under the proposed MVP. It is an informational job discovery website. Actual overseas recruitment/placement activities require legal review and applicable authorisation.

**Will I need to do anything manually?** Some review is unavoidable for accuracy, privacy, policy changes, complaints and traffic strategy. The system should minimise routine actions and surface exceptions.

---

# 23. Official research references (verify again at implementation time)

**Job API sources**

1. Jobicy official public API and fair-use rules: https://github.com/Jobicy/remote-jobs-api/blob/main/README.md
2. Jobicy API documentation: https://jobicy.com/jobs-rss-feed
3. Himalayas Remote Jobs API reference: https://himalayas.app/docs/remote-jobs-api
4. Himalayas API terms: https://himalayas.app/terms
5. Remotive API terms: https://remotive.com/remote-jobs/api
6. Careerjet publisher program: https://www.careerjet.com/partners/publishers

**Google and monetisation**

7. Google AdSense eligibility: https://support.google.com/adsense/answer/9724?hl=en-IN
8. Google AdSense page RPM: https://support.google.com/adsense/answer/112030?hl=en-GB
9. Google AdSense earnings determinants: https://support.google.com/adsense/answer/9902?hl=en
10. Replicated content publisher policy: https://support.google.com/publisherpolicies/answer/11190248?hl=en
11. AdSense website readiness: https://support.google.com/adsense/answer/7299563?hl=en
12. Google JobPosting structured data and content policies: https://developers.google.com/search/docs/appearance/structured-data/job-posting
13. Google Search spam/AI-scaled-content policy: https://developers.google.com/search/docs/essentials/spam-policies

**Operations, privacy, overseas safety**

14. Hostinger cron support: https://www.hostinger.com/support/1583465-how-to-set-up-a-cron-job-at-hostinger/
15. India Ministry of External Affairs overseas employment FAQ: https://www.mea.gov.in/oe-faq.htm
16. Ministry of External Affairs intending emigrants FAQ: https://www.mea.gov.in/issues-of-intending-emigrants.htm
17. India's official eMigrate portal: https://emigrate.gov.in/
18. India government announcement of DPDP Rules: https://www.pib.gov.in/PressReleasePage.aspx?PRID=2190655
19. Germany official career and work information: https://www.make-it-in-germany.com/en/

**Research date:** 22 November 2026. URLs and provider terms are not perpetual guarantees. Every launch and major integration requires a fresh review. This document is a product/engineering plan, not legal, immigration or investment advice.

---

# 24. Final release boundary

**Version 1.2 change:** Job Decision Cards and initial personal decision workflow are now the core launch value; private Radar comes next. Earlier v1.1 additionally specified optional, feature-flagged **Recruiter Lite** and a secure **inbound Partner Job Posting API** for verified employer-owned jobs only. These are not a full ATS and are never a shortcut to bypass compliance, moderation or source licences.


**Launch** = approved source-attributed remote job discovery + evidence-labelled Job Decision Cards + no-login career selector + source-correct external applications + 3 complete useful tools + original trusted content + safe automated sync + mobile, privacy and security basics.

**Expand later** = private Radar and application tracker, then demand-led 10-tool suite + one daily mission/game + richer guides + approved partner monetisation and **optional verified Recruiter Lite + inbound Job Posting API** after separate security/operating gates.

**Do not launch** = fake jobs, scraped competitor data, paid AI dependency, guaranteed employment claims, mass AI-generated SEO junk, premature social network, unrestricted recruiter API access, candidate fee collection, or revenue projections presented as fact. Later employer features require verification and security launch gates.

**North-star metric:** *Monthly users who successfully complete at least one meaningful career decision/action* (e.g., inspect an eligibility-grounded card, finish a comparison, save a suitable job) — not raw imported listings.

**v1.4.1 canonical scope:** Phase 0 supply audit → Phase 1 decision workflow + 3 utilities → Phase 2 local-first Radar/tracker → Phase 3 experiment; optional independent Phase 2B verified recruiter pilot → Phase 3B inbound API if demand/operations justify. Docs updated, no live implementation or outcomes verified.


---

## Version 1.1 supplemental official references (22 November 2026)

- Google job posting structured data rules: https://developers.google.com/search/docs/appearance/structured-data/job-posting
- OWASP API Security Top 10: https://owasp.org/projects/api-security-project
- OWASP REST Assessment Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/REST_Assessment_Cheat_Sheet.html
- MEA overseas employment FAQ: https://www.mea.gov.in/oe-faq.htm
- eMigrate official service: https://emigrate.gov.in/

Partner job posting v1 is a proposed specification and is **not** an operating API until deployed, tested and expressly enabled.



---

# 25. v1.3 Canonical contract and AI-agent autonomy (binding)

**Source of truth order:** (1) `08_PARTNER_JOB_POSTING_API_OPENAPI.yaml` for partner API shapes; (2) `15_CANONICAL_MODULE_REQUIREMENTS.md` for module scope, flows, deterministic behaviours and exceptions; (3) `16_DATA_AND_OPERATIONS_CONTRACT.md` for shared data/status/provenance/cron; (4) `17_TOOL_ALGORITHMS_AND_FIXTURES.md` for calculations; (5) this blueprint for product vision and phased release, followed by other named files. Historical `90_*` audits are non-normative. Contradictory old prose MUST be replaced or treated as superseded by these current contracts; record any discrepancy in `20_VERIFICATION_LEDGER.md` and repair it instead of inventing new behaviour.

**Founder access reality:** The founder uses a fully authorised AI coding agent and does not review code manually. The agent has autonomy for repository inspection, refactoring, implementing every specified feature, migrations, test execution, staging, fixes, docs, and rollback within existing no-cost resources. Do not ask for permission per command/commit. Prefer small reversible changes, automated tests and evidence-based completion. Full access is not permission to purchase services, publish fake jobs, compromise data or bypass legal/source licence restrictions. API/key credentials obtained from the founder or existing environment may be used only for permitted actions and never copied into reports.

**Delivery:** All defined modules are specified now, but release sequence keeps optional recruiter/partner functionality disabled until automatic tests and genuine employer trust operations are feasible. No fake working feature flags or incomplete placeholder buttons. The agent can work on independent tasks while external licence/hosting assumptions require verification; it must record externally unverified facts as unknown rather than treating speculation as verified.

**Release truth rule:** `DOCUMENTED` != `IMPLEMENTED` != `TESTED` != `DEPLOYED` != `PROVEN VALUABLE`. Use the verification ledger and generated tests to track state. No document can prove real visitors, employer verifications, current terms, secure production configuration or AdSense revenue.

**Job provider source rules:** Himalayas API uses `locationRestrictions: []` for worldwide geography AND `timezoneRestrictions: []` for any offset; country eligibility is true only if both conditions allow India. `pubDate` in Himalayas official OpenAPI is original publication in Unix milliseconds; JSON feed `updatedAt` is feed refresh metadata, not a job update. Jobicy bounded latest-results feed disappearance is not proof of closure (current official docs do not guarantee a universal seven-day window). Preserve source-specific apply link and attribution. Recheck upstream terms before activation. Do not export imported provider jobs in any partner-facing API. See `16_DATA_AND_OPERATIONS_CONTRACT.md` and official refs at end.

**User-centred default:** Show useful tasks, original sourced information and genuinely available jobs even when no source meets the desired country; never imply overseas relocation supply from remote-only APIs. Avoid building complex account systems for candidates. One evidence-backed job Decision Card and useful completed calculator are more valuable than 1,000 thin copied job pages.

**Objective:** An independently operable, recoverable product consistent with constraints—not a promise of absolute zero bugs or guaranteed income.



---

# Included canonical file: `15_CANONICAL_MODULE_REQUIREMENTS.md`

# v1.4 Canonical Product Module Contracts

**Status:** normative specification; NOT implemented. **Priority:** correct behaviour > completeness of marketing pages > job count. Every feature must have a real empty/error state; no fake demos on public pages.

## Module register (canonical, no feature omitted silently)

| ID | Module | Mandatory release | UI/routes | Backend/data | Definition of done |
|---|---|---|---|---|---|
| M00 | Hosting/deployment/config & backup | Gate 0 | admin-only status | existing hosting, cron, DB, secrets, backups | host limits evidenced; rollback/restore proven |
| M01 | Provider licences, adapters & ingestion | Gate 1 | source credit/status | Jobicy + optional Himalayas permitted fetch, validation, caching | sample jobs pass source-specific fixtures |
| M02 | Normalised job catalogue | Gate 1 | `/jobs`, detail routes | provenance, source rights, stable IDs, expiry | filters accurate; no cross-source licence leak |
| M03 | Search + eligibility engine | Gate 1 | search/filter/empty states | location AND timezone; known vs unknown | IN truth table fixtures pass |
| M04 | Job Decision Cards | Gate 1 | card/detail, evidence disclosure | normalised evidence, dates, salaries | every claim traceable; unknown shown |
| M05 | 10 free utilities T01..T10 | T01/T02/T05 Gate1; others Gate2/3 | `/tools/*` | browser JS; assets as noted in 17 | all ten have tests before being labelled live |
| M06 | Original guidance, SEO and source safety | Gate 1 | `/guides/*`, `/report-job`, help | reviewed content, attribution; moderation of reports | five genuine guides + support/safety pages exist |
| M07 | Opportunity Radar, local profile, save/track | Gate 2 | `/my-career` | browser local versioned data, matching on visit | import/export and changed-job fixtures pass |
| M08 | Daily Career Mission / Arena | Gate 3 optional | `/arena` (optional `/daily` redirect) | pre-reviewed offline question bank, local streak | daily rotation reproducible, no paid API |
| M09 | Analytics and monetisation | Gate 1 hooks; ads after approval | disclosures and non-invasive ads | privacy-consented events; policy-safe ad slots | no invented revenue; AdSense off by default |
| M10 | Trust reporting, incident and takedown | Gate 1 minimum | Report issue, contact | bounded reports, action log, quarantine | phishing link report can result in safe suppression |
| M11 | Monitoring, backups, operations | Gate 1 | simple admin health view | cron run logs, alert, retry, backup/restore | simulated source outage leaves useful site |
| M12 | Recruiter identity and company accounts | 2B gated | `/employers/*` | email verification, org proof, role scopes | invalid/unverified org cannot publish |
| M13 | Direct job posting + org dashboard | 2B gated | create/edit/close; company page | review, consent, expiry, URL safety | first job held pending review |
| M14 | Inbound partner/ATS Job Posting API | 3B gated | `/developers` when ready | OpenAPI, token, idempotency, tenant isolation | contract/security tests pass |
| M15 | Privacy/consent/export/deletion | Gate 1 core; extend 2B | privacy/terms/consent | cookie controls; local delete; org PII deletion | consent and deletion paths tested |
| M16 | Accessibility/performance/test harness | Every gate | keyboard/mobile/print | CI tests + reports | WCAG review, speed measured, no broken routes |
| M17 | Source/traffic/business feasibility | Gate 0 and ongoing | transparent category labels | 14-day sample + weekly metrics | no job-supply / revenue claims without evidence |

**No missing mandatory module via omission:** all M00–M17 must be either `specified`, `implemented`, `tested`, `deployed`, or `blocked_with_reason` in a machine-readable progress log. A future-gated module counts as specified, not completed or live.

## End-to-end candidate journey, with negative paths

1. Arrive on home → choose role + `remote_from_india | remote_other | onsite_abroad`, optional country. No account required; works even with localStorage disabled (session only).
2. Backend returns only current allowed-source jobs; filter and present real matches or `No confirmed matches` with useful tool/guide link. No false “new today” count.
3. Job card explains `why matched`, source, evidence grade, verified vs unknown eligibility (not “verified employer”), actual last source check and source-updated timestamp separately.
4. Decision view: user can open appropriate salary/offer calculator with *only observed* salary/location prefilled and assumptions marked as needing input. Show how to verify job source and avoid scams.
5. `Apply at source` opens only licensed canonical/approved application URL in safe tab; do not report an application success or collect a CV.
6. `Save` local-only; `Mark applied` requires deliberate user action. Follow-up date can export `.ics`; no promise of background notifications.
7. On next visit, Radar compares stable provider job IDs/versions from local browser storage against latest safe cached listing snapshot; `new to you` never conflated with `newly published`.
8. On API outage, show cached last-checked information only if policy freshness allows, else hide job and suggest tools. Missing from a time-bounded feed is **not automatically closed**.
9. If browser storage cleared, show data-loss warning and JSON import option; users can delete all local data at any time. All imports have caps and validation.

## Recruiter journey, not a staffing agency

1. Employer registers, verifies email, claims org/domain and submits corporate identity/authority as allowed by local law. Apply URLs must be HTTPS hostnames controlled by company or approved ATS; no short links and no posting to applicant-fee forms.
2. User cannot grant self `verified_org` role. Early new organisations reviewed; overseas agency/relocation claims require extra legal/trust screening. Legitimate employers only, not candidates, may post.
3. Form and API create jobs as `pending_review`, with unique org-scoped `external_id`, terms consent recorded with version/time/actor; unverified org has no write token.
4. Reviewer accepts/rejects with reason. Org may edit/close its own job, but sensitive edits return to review. Published jobs inherit correct `origin=direct_employer` rights and a distinct label.
5. Cron hides expired jobs; recruiter can close immediately; org suspension hides all its jobs and disables keys. Dashboard counts views/clicks aggregated without collecting applicant identity.
6. Repeated errors or founder moderation capacity exhaustion: freeze new company registrations and posting submissions; existing legitimate candidates can keep using the site.

## UI complete-screen inventory

Public: homepage, job search/results, individual job view and evidence, related tools, tool index, ten tool pages, country/guide index and details, fraud/safety page, contact, about, privacy, terms, disclosure, report issue, My Career/Radar, daily mission. Recruiter (only if enabled): welcome/FAQ, register/confirm, pending-verification state, login/reset, organisation profile, job table, job form, job status/review reason, API key issuance/revocation, API docs. Owner: health/last sync/backups, incident report queue, source disable/reenable, employer/organisation review and suspension. Every screen needs empty, error, loading, mobile, keyboard and no-JS fallback where meaningful.

## Source/role priority rules

- `remote_from_india` only means employer's remote-location + timezone restrictions allow India **with cited source fields**. Visa rules are outside this inference.
- `onsite_abroad` requires verified physical work country and on-site/relocation type; sponsorship is separately yes/no/unknown. If no feed provides these jobs, show zero and explanatory guidance rather than mislabel remote roles.
- Confidence is explicit evidence category, not invented 97% match or employer trust score. Free-text role similarity cannot override country ineligibility.
- Local Radar scores role text and location only after mandatory eligibility gates; show the fields that matched; no paid model needed.

## Test coverage & gates

Gate 0: licensed source, actual source response/pagination test, 14-day sample with counts and ratios (may run over time; no fabricated retrospective data), verified hosting and budget. Gate 1: contracts M01–M06, M09–M11, M15–M17 with automated/browser tests, security and backups. Gate 2: M07 and remaining T03/T04/T06; Gate3: T07–T10 + optional M08; gated 2B/3B add M12–M14. Default `RECRUITER_LITE_ENABLED=false`, `PARTNER_POSTING_API_ENABLED=false`, `ADS_ENABLED=false` until justified.

## What is intentionally NOT in the platform

No candidate CV database, passport collection, automatic job applications, applicant-status scraping, paid AI API, employer applicant-tracking system, recruitment/placement service, hidden candidate fees, uncontrolled web scraping, unlicensed outgoing job API, fictional vacancies, guaranteed salary/tax/visa outcomes, or guaranteed ₹50,000/month. These are explicit non-goals rather than missing modules.

## Route and state cross-contract normalization (v1.4)

- Original Daily Arena destination is `/arena`, as registered in the project blueprint. `/daily` MUST NOT serve a divergent standalone experience; if an old link exists it redirects permanently to `/arena` and inherits indexing policy. No broken menu link while M08 is disabled.
- Persist the canonical JobView and database state as `allowed|not_allowed|unknown` (per `16_*`). UI copy may present `explicitly allowed`, `explicitly not allowed`, `unknown` only as human-facing labels; no second competing enum goes into APIs or persisted data.
- Accepted remote-from-India matching requires BOTH geography and timezone permission for Himalayas, with actual evidence. With missing/invalid fields use unknown; it cannot pass a strict allowed-only filter.
- `module_status.json` is a starter inventory, not evidence of implementation. The execution agent creates a fresh evidence log inside the actual code repository.



---

# Included canonical file: `16_DATA_AND_OPERATIONS_CONTRACT.md`

# v1.4.1 Canonical Data, Provider and Automation Contract

## Source-isolation rules (hard constraints)

Each job holds `origin` (`provider` or `direct_employer`), `provider`, `provider_job_id` OR `owner_org_id`+`external_id`, immutable original source URL, canonical application URL, independent provider policy ID, content-use rights, source attribution, imported/updated/first_seen/verified times, eligibility evidence and status. Never merge two sources into one attribution record. Cross-provider duplicates may display one group with both retained URLs/rights. No partner API, CSV export or public developer endpoint may return third-party imported job records unless explicit source licence permits; default deny.

## Canonical JobView — exact field types

`id: opaque string`, `origin: enum(provider,direct_employer)`, `source_name: nonempty string`, `source_url: HTTPS`, `apply_url: HTTPS`, `title: string`, `company_name: string|null`, `work_mode: remote|hybrid|onsite|unknown`, `work_country: ISO2|null`, `employer_country: ISO2|null`, `eligible_from_in: allowed|not_allowed|unknown`, `eligibility_evidence: [{provider_field, fact, observed_at}]`, `time_zone_eligibility: allowed|not_allowed|unknown`, `visa_sponsorship: yes|no|unknown`, `salary_min/max: decimal|null`, `salary_currency: ISO3|null`, `salary_period: hour|day|week|fortnight|month|year|null`, `source_published_at: UTC|null`, `source_updated_at: UTC|null`, `first_seen_at: UTC`, `last_seen_at: UTC`, `last_verified_at: UTC|null`, `valid_through: UTC|null`, `availability: active|closed|stale|unknown`, `display_status: visible|hidden|held`, `rights: {attribution_required,allow_jobposting_schema,allow_resyndication}`, `reason_tags: string[]`. Source-specific fields/metadata stored separately, never invented.

**Timestamp invariants:** UTC ISO 8601 on API/JSON; SQL UTC `DATETIME` with known conversion; explicit `unknown` is not Unix epoch. `source_published_at` never silently set to first seen, source updated, or ingestion time. `new_since_last_visit` uses local first seen relative to browser last-view, not source posting date.

**Origin/status mapping:** Provider imported record = API provider ID + provider lifecycle state; direct employer record = verified org ID + posting review state. A public projection has `visible` only if rights permit, no trust hold, and either active provider evidence or approved nonexpired direct posting. For Himalayas, there is no documented public per-job status/410 endpoint: never call an invented per-job URL. Use the official browse/search responses and documented `expiryDate` conservatively; 429/5xx/partial retrieval retain the last known-good cache subject to freshness. An absent job alone is not an authoritative closure signal. It is **not automatically closed** simply because it is absent from discovery results. For direct employer, `pending_review`, `rejected`, `suspended`, `closed`, `expired` are hidden regardless of previously published status. All status transitions audited.

## Source-specific adapter mapping

### Himalayas JSON API

**Official authority:** https://himalayas.app/docs/openapi.json (OpenAPI 3.1, checked 2026-11-23), together with https://himalayas.app/docs/remote-jobs-api and https://himalayas.app/api. The provider's current contract overrides conflicting earlier v1.4 prose. Recheck before enabling live integration.

- **Exactly two documented public JSON endpoints:** `GET /jobs/api` and `GET /jobs/api/search`. The browse endpoint pages by `offset` (starting 0), `limit` (maximum 20), and the response `totalCount`, `jobs`. There is **no documented `nextCursor`**. Search uses `page` and filters; do not conflate the two.
- `guid` is an opaque ID, not necessarily a job URL. Preserve `guid` and a stable internal route key; **do not invent** a per-job Himalayas link. Display visible Himalayas credit with an actual known Himalayas destination. Preserve the exact provider-supplied HTTPS `applicationLink`, which may point to an employer/ATS site. Keep source attribution separate from Apply.
- `locationRestrictions`: **array of objects** with `alpha2`, `name`, `slug`; empty `[]` means worldwide geographic coverage. Validate `alpha2` against real ISO alpha-2 membership. Missing/null/malformed yields `unknown`. Do not mistake string-only legacy fixtures for current officially specified job response objects.
- `timezoneRestrictions`: **array of strings** such as `UTC-5`, `UTC+5:30`; empty `[]` means no timezone restriction. Parse explicit UTC signs/offsets and compare to India's UTC+05:30; missing/null/malformed values are `unknown`. Bare numeric `5.5` is **not** a valid current OpenAPI JSON field value. A timezone or geographic exclusion yields `not_allowed`; both evidenced permissions yield `allowed`; otherwise `unknown`.
- `pubDate` is **publication time in Unix milliseconds** and maps to `source_published_at` after UTC conversion, not `source_updated_at`. `expiryDate` is expiration time in Unix milliseconds. Response-level `updatedAt` is feed refresh metadata and is not a per-job update timestamp. Never fabricate original publication or a job update from ingestion time.
- There is **no documented per-job REST status URL**, nor an official 410/404 job status protocol in these public docs. Do not call one or treat simulated 410 tests as real endpoint evidence. A completed feed and documented expiry help assess freshness; partial traversal, provider error or absence alone must not mass-close jobs. If conservative freshness fails, hide with an honest stale/unknown label, without falsely marking employer closure.
- Data is cached/refreshed approximately daily according to public documentation. Respect 429 and backoff. Use backend-only requests, no client direct API, no unapproved redistribution or Google JobPosting markup. A policy-disabled provider remains disabled until actual rights/host/response checks pass.

### Jobicy public feed

Official docs: https://jobicy.com/jobs-rss-feed (reviewed 2026-11-22; verify relevant commercial and attribution terms on activation).

- Free JSON endpoint returns latest available matches (bounded to at most 100 per call according to current public docs); it is **not** an authoritative all-active-job index, and its current docs do not guarantee a universal seven-day window. Disappearance from its results alone ≠ closure. Preserve canonical Jobicy/source URL and required credit; do not redirect to arbitrary employer ATS links not licensed by provider.
- Map genuine source publish/updated time when explicitly documented; otherwise keep unknown. Source status check only if an authorised endpoint is available; never aggressive scrape third-party destination to prove closure.
- Do not invent affiliate click earnings for these jobs. A separate approved tracked employer-purchase referral program, if any, has independent conditions.

## Safe ingestion transaction

1. Cron lock ensures one provider job at a time; begin `sync_run`. Fetch using server-side requests and active provider policy version; enforce timeout/size/SSL; no source callback injection or arbitrary URL.
2. Validate raw response shape against versioned fixture. Normalise without inventing fields. Scrub HTML. Restrict outbound URLs to provider-specified links. Record source snapshot metadata and source policy ID.
3. Upsert idempotently on `(provider_id,provider_job_id)` only; duplicate grouped at display, not destructive data merger. Mark seen IDs within completed traversal.
4. Only after complete successful traversal evaluate possible missing jobs; absence from Jobicy time-bounded feed is never an automatic close. Authoritative expiry or provider-specific status closes; otherwise mark freshness uncertain and hide when stale threshold reached.
5. Commit transaction and sync_run health. 429/5xx/partial traversal → no deletion and no reset of last-known-good; log error and retry with bounded exponential backoff. Provider policy uncertainty → disable further public use safely.

## Freshness thresholds (project defaults; not upstream guarantees)

- Visible imported job requires successful provider status confirmation where available or a completed recent feed reference under per-source policy. In unverified state use warning rather than claiming “active”. If older than **72h since last successful source verification**, hide by default unless provider-specific documented evidence supports longer; configurable per provider and monitor false removals. Closed/expired authoritative record is hidden immediately. **TTL is an internal conservative safety setting, not proof of vacancy status.**
- Direct employer jobs expire at `valid_through`; notify org beforehand only if approved email delivery exists; no silent extension. Sponsor/eligibility changes must trigger review and revision increment.
- `source_terms_checked_at` more than 30 days old or provider terms materially changed → warn operator, disable affected integration if rights are uncertain. Manual-assisted legal review is honestly not automatic.

## Local browser profile & Radar (no backend-user illusion)

`profile_schema_version=1`, roles[], work_path enum, countries[], last_view_at, seen map, saved jobs, applications, followups, consent settings. Store locally only and validate imported JSON schema with caps (max 2000 saved jobs / 1000 applications and 1 MiB import by default). Use origin-qualified stable job key `provider:<slug>:<id>` or `direct:<org>:<external_id>`; never trust unsanitised imported HTML. Deterministic matching: required path/country gate → role token overlap with simple alias dictionary → date/seen state. No score percentage unless based on explicit defined formula and labelled heuristic. Show exact matched reason and unknown data warnings. Calendar reminder `.ics` only; offline email/push disabled at launch.

## Security operations

Data origin endpoints and webhook URLs never act as general SSRF fetchers. Reject localhost/private IPv4/IPv6, link-local, redirect to another hostname, punycode lookalikes and non-HTTPS schemes in employer apply URL review; do not assume DNS/domain verification alone proves employment or authority. All employer writes require session CSRF or scoped bearer token + per-object tenant checks, rate limits and audit. Store hashed tokens; never output a secret in logs/source/client.

## Bounded maintenance & auto-recovery

- Health cron once daily summarises last successful sync per provider, jobs visible/held, invalid links, failed backups, recent incident reports, API tokens abuse metrics (when active) and broken routes. Self-heal allowed for transient errors; substantive licence questions, company identity and suspected fraud are exceptions requiring trusted human judgement.
- Backups per available hosting, periodic restore drill, two retained restore points, failed-restore alert and reversible migration approach. Backups encrypted/access controlled and excluded from public web root.
- Admin emergency switches: `PROVIDER_JOBICY_ENABLED`, `PROVIDER_HIMALAYAS_ENABLED`, `RECRUITER_LITE_ENABLED`, `PARTNER_POSTING_API_ENABLED`, `ADS_ENABLED`. When off, site renders honest unavailable state, not fake success.
- No monitoring infrastructure should generate unbounded costs, emails or API calls. If email service unavailable use owner/admin dashboard; document that notifications won't be delivered.

## SEO, source rights and privacy

Imported provider-only thin job pages are `noindex` by default; provider-specific licence always wins over SEO wishes. Employer-owned original jobs may use JobPosting schema only when source/Google requirements pass, not for affiliate disguised jobs. Remove expired/closed jobs from job index and schema. Original guidance must have sources and last review timestamps; no mass AI-generated article spam. Ads only after actual account approval. Tracking consent must be applicable to region and vendor; analytics events never include applicant PII.


## Canonical DB reference

`24_DATABASE_SCHEMA_REFERENCE.sql` supplies the unified proposed schema and owner/provider invariants. The old illustrative SQL in `06_ARCHITECTURE_AND_DATABASE.md` is explicitly deprecated. Run schema against the actual available MySQL/MariaDB version in a scratch database, add migrations/rollbacks, and audit SQL constraints/application constraints before creating production tables. Candidate records remain browser-local.

**Country validation:** regex `^[A-Z]{2}$` alone does not make a valid country; validate ISO 3166-1 alpha-2 membership server-side (reject fabricated `ZZ`) on POST, PATCH full-object, source adapters and public filters. `candidate_eligible_countries` must be validated the same way.

## v1.4.1 provider-input type invariants

Current authoritative source object: `locationRestrictions: [{"alpha2":"IN","name":"India","slug":"india"}]`, `timezoneRestrictions: ["UTC+5:30"]`. For India, require both geography and UTC+05:30 timezone permission, or explicit empty-array unrestricted dimensions. Treat missing fields, nulls, unsupported types, invalid ISO membership and inconsistent restrictions as `unknown`; explicit valid geographic/time exclusion is `not_allowed`. Normalize only documented UTC string formats; do not assume the current JSON field is numeric. Independently test unknown, exclusion, empty arrays, malformed mixed arrays, and proven allowed. **Legacy source fixtures may be handled for migration, never as proof of current provider format.**

Source docs checked 2026-11-23: https://himalayas.app/docs/openapi.json. Repo v0.9.15 code must be assessed against this exact field contract before enabling live providers; docs checking is not live feed sampling.



---

# Included canonical file: `17_TOOL_ALGORITHMS_AND_FIXTURES.md`

# v1.4 Deterministic Contracts: All 10 Free Career Tools

Each tool must include: precise fields, units, validation, missing-data policy, sample input/output test, keyboard/mobile layout, local-data warning, reset and usable export/print. `null` means not known; 0 means actually zero. Display money rounded only at UI boundary (calculations use decimal minor units or fixed precision), currency codes not interchangeable; live data is never invented.

## T01 Salary, Living Cost & Savings

Inputs: `salary_value >= 0`, `salary_basis` (`gross|net`), `salary_period` (`monthly|annual`), `deductions_fixed >=0`, `deductions_rate` 0..100 (gross only), each monthly expense >=0, `fx_rate>0` optional with direction clearly labelled, `one_time_costs>=0` separate. Normalise salary to monthly (`annual /12`). If gross: `estimated_take_home = max(0, monthly_gross - deductions_fixed - (monthly_gross * deductions_rate/100))`; if net: `estimated_take_home=monthly_net` and deductions controls disabled (not subtracted). `monthly_expenses=sum(all monthly expenses)`; `monthly_savings = take_home - expenses`; `savings_rate = savings/take_home*100` if take_home>0 else `not_applicable`; `annual_savings=monthly_savings*12` WITHOUT one-time expenses; `first_year_after_move=annual_savings-one_time_costs`. FX converts presentation currency only if user provides explicit one-unit direction; if missing show original currency without misleading INR total. Allow negative savings, reject NaN/Infinity, high rates and negative fields. Golden A: gross 120000/month, 10% deduction, rent 30000+food 15000+transport 5000 => take-home 108000, costs 50000, savings 58000, savings rate 53.7037%, annual 696000. Golden B: net 50000, expenses 60000 => savings -10000; negative not an error. Gross example after rate: 120000-12000=108000; 58000/108000=53.7037037.

## T02 Offer Comparison

Per offer inputs: base salary amount, `period=hour|month|year` (for hourly require hours/week and weeks/year), currency, `estimated_deductions`, recurring monthly costs, guaranteed monetary benefits, conditional bonuses, one-time move/visa costs, hours/week, user FX to common display currency. Formula: monthly recurring base: year/12, month as-is, hour*hours_per_week*weeks_per_year/12. Guaranteed recurring compensation added to recurring base only if clearly cash-equivalent; noncash benefits separate. `net_monthly_estimate=gross_monthly+guaranteed_cash_monthly-user_estimated_deductions`; `monthly_savings=net_monthly_estimate-monthly_expenses`; `first_year_savings=monthly_savings*12 - one_time_costs`; optional conditional bonus is not included in guaranteed savings. No tax calculation without user input; FX incomplete = cannot rank monetary offers, show “comparison incomplete”. Higher monetary first-year savings can be displayed as a scenario, not objectively “better” job. Fixture: A monthly net 100000, costs 60000, move 100000 → first-year 380000; B monthly net 80000, costs 30000, move 0 → 600000. B higher first-year by 220000 (same currency only).

## T03 Resume & Cover Letter

Three original content templates with real headings: reverse-chronological, skills-based, concise fresher. All have contact, summary, experience/projects, education, skills and optional evidence links; no auto invented experience. Cover-letter structure: recipient if known, role, two evidence-backed achievement paragraphs, conclusion. Escape all user input; never store server-side by default; export HTML/text and browser print stylesheet for A4/Letter without clipped tables; proof using screenshots/print tests. Fixture: field contains `<script>alert(1)</script>` → printable output displays text, executes zero JS; empty required name triggers validation, never fabricated placeholder.

## T04 Relocation Budget

Explicit one-time categories: travel, documents, visa user-estimate, deposits, setup, arrival transport; recurring monthly categories: rent/food/utilities/transport/insurance; `reserve_months>=0` and `contingency_pct` 0..100. `one_time_total=sum(one_time items)`; `monthly_cost=sum(recurring)`; `reserve=reserve_months*monthly_cost`; `contingency=contingency_pct/100*(one_time_total+reserve)`; `target_cash=one_time_total+reserve+contingency`; display all three separately to avoid double-count. Fixture: one-time 60000, monthly 40000, reserve 3 months, contingency 10% => 60000+120000+18000=198000.

## T05 Time Zone Work Overlap

Input: valid IANA zones (e.g. `Asia/Kolkata`, `Europe/London`), selected calendar date, weekday work intervals in local wall time, optional overnight shift flag, min meeting length (minutes). Use `Intl.DateTimeFormat` with zone, **actual date** and DST; don't hardcode offsets. Compute candidates on UTC timeline in 15-minute steps (or finer for requested precision) and convert each UTC instant to respective wall time + day; compare allowed intervals, handling half-open boundaries; merge adjacent valid points into UTC spans. Display both local times with date and offset, and don't suggest nonexistent DST-gap local times. Fixture: 2026-01-15 UTC 09:00 = London 09:00 and Kolkata 14:30; 2026-07-15 UTC 09:00 = London 10:00 and Kolkata 14:30. Overnight/weekend/DST fold cases required. If device lacks sufficient timezone support show clear unsupported message.

## T06 Application Tracker

Status enum `saved|applied|interview|offer|rejected|closed`; no automatic 'applied' on outbound link click. Each entry contains id, URL (HTTPS if present), company, role, user-chosen applied_at/status, followup_date, notes optional, created_at, updated_at. LocalStorage/IndexedDB with schema version; export UTF-8 JSON and CSV; import validates field allowlist, sizes, date format, statuses and sanitises output (CSV formula injection guard). Duplicate IDs merged only after explicit user choice or stable deterministic new IDs. One-click delete all. `.ics` follow-up optional and exported file is NOT a backend reminder. Fixture: export→erase→import yields same 2 example records and no automatic cloud sync; malicious `javascript:` links rejected.

## T07 Interview Practice

Static original question bank keyed by role and question ID, not live LLM. Each record has prompt, role, objective, rubric, sample structure, source/author. Timer local only, keyboard operable, text mode works without microphone; speech recognition optional browser capability with explicit consent and graceful fallback. No “employer certified” badge or hiring likelihood predictions. Fixture: denying mic results in a working text question and timer with zero paid API calls.

## T08 Country Readiness Checklist

Country + intended visa/work-path categories are selected but no visa eligibility decision. Checklist item holds `title`, `category`, `is_generic`, `source_url`, `reviewed_at`, `expiry_review_at`. When rule-specific item has no current official source or is past review date, label “needs rechecking” rather than publish as current legal requirement; user progress saved local. Fixture: hypothetical requirement expired yesterday → warning, no “verified” claim; clearing storage loses ticks with warning.

## T09 WorkProof Portfolio Generator

Input self-reported project title, description, skills, project links, optional evidence. Output static HTML with escaped text and safe `https` external links, print/PDF and local preview. No online hosting, public profile or verification claim. Limit images or exclude uploads at launch; support up to 10 projects. Fixture: malicious HTML in project description renders inert; user sees “Self-reported” rather than “Verified”.

## T10 Career Roadmap Builder

Start with 3 curated role tracks (IT Support, Customer Support, Junior Web Developer), each with skills prerequisites, role-linked free learning resources, 30/60/90-day practice plan and at least one verifiable deliverable. Adapt weekly time-budget with deterministic distribution without guaranteeing employment; optional user edits and local export. Fixture: 3 hours/week yields 12 hours per 4-week planning block; milestone text is nonempty and does not claim certification. Every external link reviewed and dated.

## Content/readiness evidence gate

A module's algorithm can be specified while its **original templates, questions, sourced country guides or test snapshots still have to be created**. A coding agent should author/review those files and run validation before switching the route to LIVE; no placeholder content or fabricated official sources. Public content refresh remains an ongoing editorial task, not automatically guaranteed by AI.



---

# Included canonical file: `19_AGENT_AUTONOMY_AND_DELIVERY.md`

# v1.4 Full-Access AI-Agent Operating Contract

## The founder's real operating model

The owner is a solo nontechnical founder. An AI coding agent is the developer and has full technical access to the **authorised** project repository and hosting. The agent MUST carry technical work to completion where possible and must NOT require founder confirmation for every file edit, package install, test, Git commit, safe migration rehearsal, staging deploy or bugfix. Request an external credential or a real business/legal decision only when unavoidable; do not make the founder debug code.

## Autonomous development loop

1. Read the canonical specifications and project inventory. Identify actual framework/hosting before overwriting anything. Record baseline backup and git commit.
2. Derive a requirement-to-test map for M00–M17. Prefer existing code and minimal PHP/MySQL/JS if supported. Do not rewrite entire unrelated projects.
3. Implement all Gate 1 modules fully, test with deterministic fixtures and live authorised provider samples; adapt specifics only within documented user-benefit, data-rights and ₹0-new-subscription constraints. Continue independent Gate 2/3 modules where possible.
4. Maintain `module_status.json`: module ID, `specified|implemented|tested|deployed|blocked_with_reason`, tests passed, actual route and evidence path. `blocked_with_reason` includes exact unresolved external condition and safe user-visible fallback. Nothing is marked tested/deployed without executable evidence.
5. Before deploying, execute automated contract, regression, security, accessibility and responsive smoke tests. Backup DB and files, rehearse rollback, then deploy to authorised existing staging/production according to actual environment configuration. Compare post-deploy health/smoke tests and auto-rollback on failure.
6. Founder receives one plain-language status summary: what works now, what is disabled, verifiable URLs, new cost (must be ₹0 additional recurring), failures, next safe action. No demand for reading YAML, PHP or error stack traces.

## Technical discretion allowed without asking

Choose library versions, internal class/file names, HTML/CSS implementation, non-breaking DB indexes, rate-limit tuning within source quotas, tests, backup mechanisms supported by host, code refactor, data cleanup where recoverable, bugfix/rollback and UX details consistent with written journeys. Document an Architectural Decision Record when selecting a substitute stack or materially changing implementation.

## Boundaries that cannot be guessed

No fabrication of recruiter verification, job availability, visa eligibility, employer legitimacy, source licence, legal compliance, advertising approval or revenue; no new paid service/billing; no unauthorized credentials; no destruction of unrelated sites; no collection of sensitive candidate documentation; no automatic applicant submission. On licence uncertainty, turn off only that provider, not the entire product. On company verification uncertainty, don't publish that organisation's jobs. These are factual/legal constraints, not unnecessary developer micro-approvals.

## Correct response to an unclear requirement

First consult source-of-truth order. Next write the smallest safe deterministic implementation preserving privacy and user benefit. If it affects a mandatory business rule, record assumption, generate an example/test and choose conservative behaviour (`unknown` instead of fabricated true, hidden instead of unlicensed public listing). The agent need not stop unrelated development. Return for founder decision only when several materially different user-facing business choices truly remain and cannot be resolved with existing constraints.

## Hard handoff evidence

Project runnable in documented environment; real smoke tests; unit/integration fixtures; OpenAPI validation and samples; accessibility/print checks; no cross-tenant data; no source redistribution; source credit; performance budget; backup+restore evidence; module status; accurate URL list; list of genuinely unresolved external dependencies. Never claim '100% bug-free' or 'guaranteed passive ₹50,000'.



---

# Included canonical file: `20_VERIFICATION_LEDGER.md`

# v1.4.1 Verification and Residual-Risk Ledger

**Status date:** 2026-11-23. This ledger distinguishes corrected *documentation* from unproven implementation.

| Item | Documentation check | Deployment/real-world status |
|---|---|---|
| 18 modules M00–M17 named and release-specified | Included in 15 | No code/live inventory reviewed |
| T01–T10 calculation/validation contracts | Included in 17 | No runnable website tests yet |
| Recruiter OpenAPI schema syntax and example | Run 23_VALIDATE_SPEC.py | No deployed endpoint, identity workflow or tenant tests |
| Visa sponsorship `yes/no/unknown` | Fixed in OpenAPI and prose | Need server validation |
| On-site work country non-null | Fixed in create schema; PATCH requires full state validation | Need server tests |
| Himalayas JSON API `pubDate` as original publication time | Specified and externally corroborated | Need live adapter fixtures |
| Himalayas Location object + string timezone eligibility | Specified and externally corroborated | Need live adapter behaviour |
| Jobicy bounded feed disappearance ≠ closed | Specified and externally corroborated | Need observed feed reconciliation |
| Source licensing | Current docs consulted; rights matrix retained | Must revalidate before public activation |
| Hiring-side direct employer supply | Optional guarded source | No employers contracted, trust verification unproved |
| Five original public guides | Content requirements only | MUST author, source and review |
| Game question bank, resume layouts, role roadmaps | Requirements and fixtures | Original assets MUST be authored |
| Hostinger PHP/cron and backups | Architecture conditional on actual plan | Host inspection REQUIRED |
| Monetisation and ₹50,000/month | Revenue mathematics defined | Actual AdSense/affiliate approval and traffic UNKNOWN |
| Analytics privacy/consent | Behaviour defined | Legal/configuration review REQUIRED |
| Source code and deployed website | Not included in this documentation pack | NOT VERIFIED |

**Residual risks not eliminable by more writing:** external provider terms/rate limits may change; daily job count cannot be known without running real samples; on-site overseas-job supply not secured; recruiter verification takes human judgement; Google traffic/AdSense approval and income are not guaranteed. The agent must measure and report, not silently fill assumptions.

**Docs check result:** passing automatic document/schema checks only means files and selected contracts are internally consistent; it does NOT prove all conceivable logic bugs have been excluded. New contract changes require extending test fixtures and report.

**Out-of-scope certification:** Documentation syntax/fixture passes do not certify legal immigration claims, actual employer identities, paid API availability, live source permissions, every JavaScript calculation or production migrations. Agents need implementation-based evidence per module.

## v1.4 doc-only release addendum (2026-11-23)

`00_SOURCE_OF_TRUTH.md` is now physically inside the canonical pack. `module_status.json` lists 18 modules with `specified` status only. `25_DOCUMENT_AUDIT.md` records stale instructions, route/status/fixture/SQL corrections, and external blockers. Updated validator result is written to `26_VALIDATION_RESULTS.txt`. This is documentation/fixture evidence only. There are **zero** confirmed app implementations, end-to-end tests or deployment results associated with this pack. The source licence page reads do not establish 14-day supply coverage or an authorised production configuration.

## v1.4.1 source compatibility correction and GitHub discovery — 2026-11-23

Linked GitHub repository `mohdazizshaikh/overseasjob` exists and has a PHP development application, module ledger and CI evidence according to read-only GitHub connector inspection; its README reports release v0.9.15 on the current main branch. Do **not** treat this starter doc pack's specified-only statuses as evidence that the repository contains no code. Actual current Hostinger files, database, private permission attestation, CI outcome for the latest commit and public deployment were not verified. Repo v0.9.15 supports official browse pagination/pubDate but carries numeric-timezone and string-location *comments/fixtures*, which need exact upstream OpenAPI regression tests before enabling any provider. Reference `27_GITHUB_IMPLEMENTATION_RECONCILIATION.md`.



---

# Included canonical file: `21_FOUNDER_HANDOFF.md`

# OverseasJob.in — Founder handoff (v1.4.1, 23 November 2026)

## What is ready now

A single editable source-of-truth pack with 18 mapped platform modules M00–M17, 10 tool contracts, partner API OpenAPI, database reference, job licensing restrictions, full-access coding-agent operating rules, improved test fixtures, canonical authority register, and SHA-256 release manifest. Documentation is not a completed working application.

## What is NOT ready / must not be represented as live

Read-only inspection located https://github.com/mohdazizshaikh/overseasjob containing an existing PHP application and development tests, but we did not execute its code locally; no hosting connection/configuration, HTTPS, live database migration, 14-day job supply study, paid feature, verified recruiter organisation, live APIs, public guides, resume layouts, daily puzzle bank, app-level security testing, AdSense permission, backup restore rehearsal, or production deployment has been evidenced. Do not claim these happened.

## Exact next safe handoff to an AI coding agent

1. Unzip canonical v1.4.1 pack; start from `00_SOURCE_OF_TRUTH.md`, then `00_READ_ME_FIRST.md`. Do not treat the Word export as a more authoritative file.
2. Start by preserving and testing the discovered `mohdazizshaikh/overseasjob` main branch, then inspect the authorised Hostinger environment. **Do not overwrite the working repository with a specification ZIP.** Back up before changing anything; do not touch other hosted websites.
3. Run `python 23_VALIDATE_SPEC.py` and inspect the report. Carry out Gate 0 source licence checks and 14 days of real permitted source sampling (never fabricate a historical dataset).
4. Implement Gate 1 with working code, end-to-end tests, reviewed original content, consent/privacy, verified source links and safe rollback. Continue independently to Gate 2/3 features while holding unsafe modules off; no founder code approvals per command.
5. Keep Recruiter Lite, inbound partner API and ads disabled until *their own* legal/trust/security/approval gates are actually met.
6. Replace the starter `module_status.json` with genuine `implemented/tested/deployed/blocked_with_reason` evidence from the real repo. Deliver a short plain-language report with active URLs, tests, risks, blockers, extra recurring spend (must remain ₹0 without owner approval), and restore steps.

## External inputs that cannot be created by documentation

Existing hosting/repository access and plan limits; actual permitted job feeds and measured eligible roles; business/legal review for overseas recruiting and employer identity; reviewed factual country guidance; any AdSense or affiliate approval. Business/product design is already specified. The agent must proceed without requiring the nontechnical founder to review code, but must never invent the external facts.

## Immediate priority after this source check

The existing repository has later corrected Himalayas pagination/pubDate semantics than the earlier v1.4 ZIP, but some timezone/location fixture assumptions differ from official provider OpenAPI. Run targeted tests against OpenAPI-format fixtures before enabling live API; do not regress offset+limit or invent a 410 status route. See `27_GITHUB_IMPLEMENTATION_RECONCILIATION.md`. No GitHub code or Hostinger production change is implied by this ZIP.



---

# Included canonical file: `25_DOCUMENT_AUDIT.md`

# v1.4.1 canonical documentation audit / residual-risk report

**Run date:** 2026-11-23. **Scope:** offline canonical documentation, API schema and golden fixtures; selected public provider documentation checked. No active hosting, source sample data, website repository or deployment in this pack.

## Corrections in this release

- Merged the previously standalone `00_SOURCE_OF_TRUTH.md` (v1.3.1) *into* the ZIP and its hashed manifest, eliminating missing top-level authority.
- Removed contradictory Phase 0 / Phase 1 technical founder approval language in `02_*`; retained business, paid, identity and compliance gates.
- Standardised optional Daily Arena route to `/arena`; `/daily` is at most a redirect, not a second experience.
- Standardised eligibility persisted states to `allowed|not_allowed|unknown`; `explicitly_*` remains UX wording only.
- Fixed misleading T01 fixture typo: 58000/108000 is 53.7037%, not 48.33%.
- v1.4 numeric timezone fixture was itself incorrect against official OpenAPI: replaced it with official string UTC offsets and location objects; added unknown, invalid and allowed truth-table cases.
- Corrected SQL reference `company_name` nullability to preserve unknown source information; actual migration still untested.
- Initialised truthful machine-readable `module_status.json` (all specified; no invented implementation).
- Expanded document validator to examine extra fixtures, negative API cases, authoritative file order, module statuses and manifest integrity.
- Rebuilt derived human-readable exports and SHA-256 release manifest; historical v1.1/v1.2 materials remain separate and non-normative.

## Public provider documentation context checked 23 November 2026

- Himalayas docs https://himalayas.app/docs/remote-jobs-api and https://himalayas.app/terms describe required exact `applicationLink`, visible attribution and no downstream redistribution/Google Jobs/JobPosting; OpenAPI `pubDate` means publication in Unix milliseconds; `timezoneRestrictions` is string[] and `locationRestrictions` is object[].
- Current Jobicy documentation https://jobicy.com/jobs-rss-feed documents at most 100 latest JSON results with count/geo/industry/tag filters; it does not document cursor pagination or guarantee a universal 7-day window. Disappearance alone does not prove closure.
- These page reads DO NOT verify a complete live API traversal, real eligibility counts, contract suitability for *every* planned use, hosting operational limits or future terms. Recheck at source activation.

## Critical remaining release blockers / evidence owners

| Area | Evidence still required | Owner | Production-safe fallback |
|---|---|---|---|
| Hosting/Gate 0 | Hostinger actual PHP, DB, cron, SSL, backups and authorised repo snapshot | AI coding agent from real environment | No public deployment |
| Source feed/Gate 0 | 14 actual sampling days in priority roles, pagination, quotas, country/timezone fields, status verification | Agent + provider terms | Do not claim India-eligible daily supply; tools still work |
| Content/Gate 1 | Five original reviewed guides, policies and official-source dates | Agent prepares; trusted review needed on sensitive rules | Do not publish unverified legal guidance |
| Runtime/Gate 1 | Functional system tests, source license checks, security scans, A11y, real backup/restore, production smoke | Agent with real code/host | Not live |
| Employer trust/Gates 2B–3B | Real verified organisations, capacity for human review, tenant isolation, token tests and moderation | Authorised human trust reviewer + agent | Disable recruiter/API flags |
| Ads/revenue | Actual Google AdSense approval, lawful consent configuration, traffic and RPM | Publisher account owner | ADS_ENABLED=false; ₹0 assumed |

## Quality boundary

A green documentation validator is *not* functional website testing. The initial external checks were a reading of official webpages, not a complete live feed experiment or a legal opinion. No promise of 100% bug-free code or guaranteed revenue is justified.

## Source-of-truth correction added 2026-11-23 (v1.4.1)

The earlier **138/138 green contract checks did not validate the upstream API field contracts**. Current official Himalayas OpenAPI specifies `GET /jobs/api` offset/limit/totalCount; `pubDate`/`expiryDate` integer Unix ms; `locationRestrictions` country objects with `alpha2`; `timezoneRestrictions` string UTC offsets; only browse/search routes, no public per-job 410 checker. v1.4 had contradictory authoritative prose and numeric fixtures. This update corrects those declarations, includes explicit regression fixtures, and records the discovered existing GitHub PHP code. Do not deploy until repo-specific integration and actual private/host evidence are established.



---

# Included canonical file: `27_GITHUB_IMPLEMENTATION_RECONCILIATION.md`

# Existing GitHub code and canonical spec reconciliation — 2026-11-23

**Read-only discovery:** Connected GitHub repository https://github.com/mohdazizshaikh/overseasjob (`main`, PHP; current README v0.9.15) exists. It is not a blank project. Its module ledger reports local implemented and CI-tested modules but still blocks host/site cutover. GitHub latest main commit `c53e565fc45676c3e682d342f4a28751328ab801` (2026-11-23 15:22:55 UTC) was verified; the linked CI run [45204589587](https://github.com/mohdazizshaikh/overseasjob/actions/runs/45204589587) completed with success for that commit. Earlier failed attempts on other commits exist; a green CI run is NOT a production/site or source-permission certificate. No write to this repo or Hostinger was made while creating v1.4.1. Existing files must be retained, not replaced by an older docs ZIP.

## Official evidence links checked

- Himalayas OpenAPI: https://himalayas.app/docs/openapi.json — browse `GET /jobs/api` `offset`, `limit<=20`, `totalCount`; search `GET /jobs/api/search`; NO per-job documented status route; `pubDate` & `expiryDate` integer Unix ms; `locationRestrictions`: `Location[]` with `alpha2`; `timezoneRestrictions`: string[] UTC offsets; required `applicationLink` may be employer ATS URL.
- Himalayas docs: https://himalayas.app/docs/remote-jobs-api ; attribution and provider conditions must be rechecked at activation.
- Jobicy API: https://jobicy.com/jobs-rss-feed — latest jobs, at most 100, `count`, `geo`, `industry`, `tag`; no documented cursor or universal seven-day guarantee on current page; keep provider job URL, credit and no false closure on absence.

## Existing repo code reconciliation (read-only GitHub inspection)

| Area | Observed existing repo | New v1.4.1 contract | Recommended action |
|---|---|---|---|
| Existing product | `README.md` v0.9.15; `src/`, `public/`, `tests/`, `deploy/` and status ledger exist | Specification-only zip does not replace app | Preserve repo, compare contract as targeted changes |
| Himalayas pagination | `src/Jobs.php` and `scripts/sync_jobs.php` use offset/limit/totalCount; no cursor | Matches official OpenAPI | Keep; add source contract assertions |
| Himalayas pubDate | `src/Jobs.php` maps to source_published_at | Matches official OpenAPI | Keep; test Unix ms |
| Himalayas status | Repo documents no production public per-job status endpoint; offline legacy test helper exists | No fabricated status checker | Keep status checker disabled; remove misleading examples if safe |
| Himalayas timezone | `src/Jobs.php` accepts numeric offsets as normal and `tests/php_tests.php` calls numeric field current | Official JSON field is `string[]` | Update misleading documentation/fixtures; fail malformed numeric provider response closed; accept `UTC+5:30`, `UTC+05:30` after documented canonical parsing |
| Himalayas location | Existing code accepts strings and country objects for migration; some tests use string `IN` | Official JSON field is `Location[]` objects with alpha2 | Use object fixtures for current provider; treat malformed/missing unknown; legacy handling must not promote unsafe eligibility |
| Hostinger | README warns `index.html` vs `index.php` cutover and demands backup/restore | No blind live overwrite | Maintain cutover gate: real existing homepage and DB restoration, then deployment health |
| Provider activation | README says global/provider source flags and private rights attestation default OFF | No licensed live provider assumed | Keep OFF until real rights/source evidence |
| Full product | Ledger reports all 10 tools and module code; README references Chromium/CI | Docs ZIP was only specification | Independently run code/CI and review current latest commit before claiming production readiness |

## Priority safe next coding work

1. In existing GitHub repo, add official-OpenAPI-shape fixtures for `locationRestrictions` Location objects, timezone UTC strings, valid/malformed/missing arrays; require strict known evidence for IN. Preserve fallback to `unknown` for unsupported format. Old numeric fixtures should be historical only, never describe current JSON API.
2. Add regression assertions: only public browse and search routes; offset 0/20 limit<=20; integer milliseconds publication/expiry; top-level `updatedAt` not per-job source update; exact `applicationLink`; no per-job status requests. Use tests without hitting live providers.
3. Reconcile source docs and code release version using evidence; leave existing main untouched until tests pass on a branch/PR.
4. Verify latest GitHub CI and actual Hostinger resources through authorised account; restore backup of the **existing** theme/DB before any website cutover. No paid staging required if founder uses same hosting for testing, but never disrupt current site blindly.
5. Complete real 14 distinct days of permitted job-coverage samples, content review and source policy checks. Do not invent results; do not enable provider flags, recruiter/partner API, or ads prematurely.

**Evidence boundary:** Inspection of public README and source through the linked GitHub connector is not a local clone, complete CI rerun, source licensing approval, actual Hostinger inspection or production deployment. `module_status.json` in this ZIP remains documentation-only; do not overwrite the actual repository's ledger.
